---
name: ui-discover-record
description: 按模块和功能发现 UI 测试场景，使用已安装的 Playwright 测试 MCP 自动录制有证据的脚本草稿；只有源码时保存未录制的清单，不用于批准或正式回归执行。
---

`ui_discover_record` 提供 inventory/start/action/status/finish 五个操作，参数统一为 `{request: {operation, ...操作字段}}`，结构可用包的 `../../dist/cli.js schema inventory|recording` 查询。本流程只用于「还没有可复用资产、需要发现并录制」的模块；已有资产的执行、旧结果分析和查看不加载它。

三个高频调用的形状（字段名与 [启动说明](references/start.md) 及 `dist/cli.js schema` 一致）：

- inventory：`{request:{operation:'inventory',discovery:'source',coverage:'discovered',scope_ref,source_refs,drafts}}`
- action：`{request:{operation:'action',session_ref,operation_id,tool,input,intent}}`，`tool` 不含前缀、`input` 保留原工具结构（元素参数为 `target`）
- finish：`{request:{operation:'finish',session_ref,inventory_ref,initial_state,goal_reached,gaps,completion}}`

## 1. 预检现有资产

先读 `qa/ui/catalog.json`（缺失或损坏时用 CLI `store-index` 重建）和相关 manifest，只补缺失内容，不重复录制有效资产。

输入：本次要覆盖的模块/功能。产出：实际要新增的 feature/scenario 范围，以及可复用的旧资产清单。

## 2. 选输入分支

- **只有源码**：用 Pi 检索/读取工具读路由、页面、表单声明、已有测试与共享 fixture，记录文件摘要、符号、行号，按业务模块而非文件名组织 feature/scenario。落库为 `discovery=source`、`coverage=discovered`，可同时传 `drafts`（name/content）存有来源的脚本或方案草稿，候选定位器标未核验，动态路由/权限/定位器保留待核验项；**不启动录制、不写「已运行」**。
- **只有浏览器**：范围中明确当前角色、站点、允许操作和预算，只描述可访问状态；不把未发现当不存在。
- **两者都有**：分别保存来源与观察，核对源码和部署关系；不一致时标 gap，不混成已确认事实。

发现新页面或补探索变化功能时读 [按功能探索](references/function-discovery.md)：先概览，再逐功能完成必要状态并保存草稿，复用同一角色的录制会话和已核验定位；不要等遍历完整系统才产出第一份草稿。

## 3. 冻结范围与数据规则

录制前保存 scope、初始状态规则和数据规则：

- seed 用已有项目机制并绑定文件摘要，优先复用本包 UI-04 fixture 或项目等价机制；检查身份/初始状态，登记 recording 归属数据。
- 认证用私有 storageState，不在 `browser_type` 中输入密码/token。
- 合成输入预先登记为 `test_data`，或使用本 recording 的 UI-04 ready 数据记录中的业务键；业务键及清理方式记入 data rules。
- 没有可靠准备/清理方法时保留缺口，不自行登录、遍历提交或删除。

🔴 CHECKPOINT：scope、initial_state、data_rules、seed 四项未全部登记前不 start。

输入：模块范围与可用环境。产出：scope、initial_state、data_rules、seed 四份可引用登记。

## 4. 发现工具并 start

先探测实际可用的 MCP 工具，首期只使用 Playwright 1.62.1 的测试 MCP：`generator_setup_page`/`read_log`/`write_test`。调用 start 冻结 seed、后端前缀、浏览器项目、唯一草稿文件和预算，启动字段见 [启动说明](references/start.md)。

输入：第 3 步四份登记。产出：`session_ref`，及其后所有浏览器操作都经由 action、由 Pi 原生 executeTool 调用实际 MCP 的通道。

## 5. 用 setup 快照建初始清单

从 setup 返回的真实快照建立初始 inventory，不凭源码推测页面结构。

输入：setup 返回的真实快照。产出：初始 inventory（含可引用的 observation）。

## 6. 概览并逐功能推进

先概览入口、共享控件和可见功能，再按范围优先级一次推进一个功能。动作规则：

- 动作工具必须携带当前 schema 要求的 `intent`；元素参数是 `target`，支持当前快照 ref 或唯一 locator，临时 ref 只用于当下交互。
- 已发现 `browser_generate_locator` 时，可从真实元素生成 locator，经严格交互核验后在相同适用状态复用；生成本身不证明唯一或可操作。
- 元素找不到先更新 snapshot，不猜 ref、不强制点击；验证码或未授权步骤 🛑 停止并保留局部记录。
- 操作到新的功能状态时补充观察来源，需要时创建新 inventory ID，不改写旧清单。
- 每次 action 用稳定 `operation_id`：同一次请求重试使用原 ID、参数不可变；结果不明时只查 status 和数据归属，不重放写入。

输入：`session_ref` 与当前快照。产出：带 observation 的状态轨迹与逐功能 inventory。

## 7. 生成可复用草稿

达到目标后 `read_log` 保存原生动作日志，再 `write_test` 生成草稿：

- 草稿用项目现有配置/fixture 提供地址、角色和每次新数据，不保存录制输入常量、临时 ref、个人路径或凭据。
- 实际记录过的动作与推导补充的步骤分开说明。
- 断言预期来自需求、声明或明确标记的行为基线，点击成功不是业务断言。
- 写入目标只用本次新文件，不覆盖已有测试。

输入：原生动作日志。产出：草稿文件与草稿引用，供交接使用。

## 8. 收尾交接

- 结束或受阻时通过 action 调用 `browser_close`，让 seed 的 teardown 按归属清理；即使预算到达，清理动作仍可调用。
- `finish` 保存日志、草稿、最终 inventory、五项 completion 和 gaps；五项为初始状态可重建、数据可替换、稳定定位、断言有来源、清理归属明确。
- `finish.gaps` 只记当前录制目标尚未完成或不可核验的问题，非空即 partial；范围外未测功能留在 `inventory.unexplored`，不放入 gaps，也不能删除范围内真实缺口以通过门禁。
- 🛑 STOP：缺项即保存 partial，不声称获批。异常、取消、无进展和未探索范围均保留，不用原始日志覆盖失败历史。
- 完成后交给设计评估，不直接执行正式回归。

输入：日志、草稿、最终 inventory。产出：五项 completion 判定、gaps 与 partial/完整结论。

## 9. 失败分支索引

本表是正文门禁的归纳索引，不是新增规则；与正文冲突时以正文为准。

| 触发                 | 一线修复                                                            | 兜底                        |
| -------------------- | ------------------------------------------------------------------- | --------------------------- |
| 找不到目标元素       | 先更新 snapshot，用 ref 或唯一 locator 重定位，不猜 ref、不强制点击 | 保留局部记录，该点记入 gaps |
| action 回执不明      | 只查 status 与该操作的数据归属，不重放写入                          | 按未完成记入 gaps，不当成功 |
| 验证码或未授权       | 立即停止该步，保留局部记录                                          | 记 gap，缺项即 partial      |
| 无可靠数据准备或清理 | 保留缺口，不自行登录、提交、删除                                    | 该场景记 gap                |
| 源码与部署不一致     | 来源与观察分开登记并标 gap                                          | 不混成已确认事实            |
| 预算到点             | 仍调用 browser_close 按归属清理，再 finish                          | 缺项即 partial，不补造完整  |
| MCP 缺关键工具       | 只用已发现的工具，不编造参数或回执                                  | 记 gap，交设计评估          |
| 录制中断或无进展     | 保留异常、取消与未探索范围                                          | 不用原始日志覆盖失败历史    |
| finish 五项未齐      | 保存 partial，不声称获批                                            | 交设计评估，不进正式回归    |

## 10. 反例黑名单

这里只收不可逆或会污染证据的红线，逐条都能在第 2–9 步/节或 [按功能探索](references/function-discovery.md) 找到依据，不新增规则：

- 猜快照 ref、强制点击，或用 first/nth 掩盖未解释的多匹配。
- 把点击成功当业务断言，或用推导步骤冒充实际记录的动作。
- 在 `browser_type` 输入密码/token，或在草稿留下录制常量、临时 ref、个人路径、凭据。
- 覆盖已有测试，或写到本次 start 未声明的路径。
- 为过门禁删掉范围内真实缺口、把范围外未测写进 `finish.gaps`，或用原始日志覆盖失败历史。
- 编造 MCP 不支持的参数或回执。
