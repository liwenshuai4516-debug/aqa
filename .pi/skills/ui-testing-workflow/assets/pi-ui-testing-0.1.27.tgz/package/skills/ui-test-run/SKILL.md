---
name: ui-test-run
description: 使用获批 UI 资产启动正式 Playwright 测试批次、保存原生结果与证据、查询旧批次，或续跑/重跑（触发词：正式执行、跑一遍测试、启动批次、查询批次状态、续跑 resume、重跑失败 rerun-failed、全量重跑 rerun-all、plan-recovery）。用于执行已有测试；不生成或修改脚本，不以执行完成代替测试通过。
---

# 正式执行与批次查询

请求与返回的字段名取自 `ui_test_run` 工具入参及其实际返回（包 CLI `schema run-request` 给出 start 的完整结构）；只写必填子集，不自行命名。文件引用一律是 `{path,sha256}` 对象——`sha256` 为 64 位小写十六进制，不能只写路径字符串或用资产名代替。

## 1. 读就绪证明

入：资产、设计评估、诊断状态。出：可用的 `asset_ref`/`review_ref` 或「未就绪」。
没有运行就绪证明时先按 ui-design-review 完成诊断，不手写批准或跳过门禁。

## 2. 登记执行任务

入：上一步的可用引用。出：已登记的执行 task。
🔴 CHECKPOINT —— 三条同时成立才继续：`scope_ref` 与资产一致、`asset_refs` 冻结选定修订、不覆盖已结束任务。经既有产物存储入口登记，入参 `mode`、落库 task 字段 `intent` 都取 `execute`。

## 3. 组 start 请求

入：task、四个引用、超时预算。出：一条 `ui_test_run` start 请求。
`{request:{operation:"start",input:{task_id,request_id,asset_ref,review_ref,environment_ref,config_ref,timeout_ms,parent_run_ref?}}}`。🔴 CHECKPOINT —— 以下五条全过才发 start，缺一条就回上一步补：

- `timeout_ms` 为 1000–600000 整数毫秒，覆盖整个批次。
- `config_ref` 必须属于获批修订（在该资产 `files[]` 内且摘要一致）。
- `environment_ref` 指向当前环境，`environment_id`、角色、站点须与获批范围一致；认证用私有环境变量引用。
- `parent_run_ref` 只有续跑/重跑才给，普通执行带上即「伪装子集」。
- 运行前会重新预检，不能使用录制末态作为初始状态；预检结果的 `check` 标明卡在哪一阶段（见第 10 步）。

## 4. 执行形态

入：已受理的 start。出：原生批次与启动意图。
首期单 chromium 项目、串行、零自动重试；Playwright 原生 fixture/context 负责每例隔离与归属数据清理。工具先登记冻结计划和启动意图，再启动原生 CLI。

## 5. 读回证据

入：返回的 `run_ref`。出：证据清单。
读 `run_ref`、执行摘要、原生 report、attempt、截图/trace、数据生命周期证据。

## 6. 判读结论

入：证据清单。出：可陈述的批次结论与未完成项。
`completed` 表示执行及证据收集完成；`exit_code=1` 可以是产品断言失败，不能报告为全部通过。报告缺失、实例遗漏、未知副作用或清理残留如实保留。

## 7. 查询旧批次

入：`task_id` + `request_id`。出：原批次或「未找到」。
新执行用新 `request_id`；查询或确认同一次启动用原 ID。`{request:{operation:"status",task_id,request_id}}` 查询旧状态，相同输入的同请求只读原批次、不重放浏览器。取消、中断、未知或只有 pending 的旧批次先核对进程与业务数据，不换 ID 绕过阻断。

## 8. 续跑/重跑

入：父批次引用 + intent。出：冻结的选择集合与新批次，或阻断。
先调 `plan-recovery`，形状 `{request:{operation:"plan-recovery",parent_run_ref,intent}}`——`parent_run_ref` 与 `intent` 在顶层，**不套 `input`**；`intent` 取 `resume`/`rerun-failed`/`rerun-all` 之一。它只读父批次、不启动浏览器：resume 只选已确认未启动的实例，rerun-failed 只选 failed/flaky，rerun-all 选当前同一获批资产完整集合。
返回 `parent_run_ref`/`parent_run_id`/`intent`/`selected[]`/`excluded[]`/`blockers[]`/`resume_unit`/`note`。核对 `selected` 恰为本次意图集合，`excluded` 列出被排除实例并注明保留父批次原结果。🔴 STOP —— `blockers` 非空或 `selected` 为空即停止，不换任务 ID 绕过未知业务写入；父批次中断/活跃或证据不完整时保留待核对，不能只靠 PID 消失清除阻断。
再用工作流相同 mode 和 `run_ref`=父批次创建任务，start 时同时传 `parent_run_ref`；冻结 selection.json、parent_run_id 与新 run，原生 Playwright grep 选择完整 case/业务链，从声明初态新建 context/数据，不从点击中途恢复。保持同一资产修订，跨部署版本单独报告。

## 9. 移交与脚本修订

入：新批次证据。出：交结果分析的原始结果。
统计与失败归因交结果分析阶段；无该能力时只交付原始结果和未完成项。脚本修复须新建资产修订并重新评估，不能在失败批次中改脚本或预期值使其变绿；失败子集通过不替代父批次原失败或原全量覆盖。

## 10. 失败分支索引

只归纳前九步与工具错误类别的对应，不新增规则；冲突以对应步骤为准。

- **预检 `status=blocked`**：读 `check` 看卡在哪一阶段（`auth-reference`/`browser`/`site`/`identity`/`initial-state`），先修该阶段的认证、可达性或初态；修不好停在 blocked 并保留 preflight.json。
- **`invalid-input`**：请求不符合 schema，按第 3 步重填字段与嵌套；不要猜加字段。
- **`precondition`**（配置不属修订、环境与范围不符、任务 intent/scope 不一致、父批次资产不同）：修对应前置；**不要**换 task_id / request_id 重试。
- **同一 `request_id` 改输入**：工具报「同一执行请求不能改变输入」，新执行换新 ID，不是改输入重发。
- **`plan-recovery` blockers 或 selected 为空**：停，先核对进程与业务数据，不换任务 ID、不按点击序号恢复。
- **摘要 `collection_problems` 非空，或 status 落在 unknown/blocked**：保留原生记录，按证据不足交付，不推断通过。
- **status=cancelled**：保留批次与证据，不自动重放；下次执行重新走第 1 步。
