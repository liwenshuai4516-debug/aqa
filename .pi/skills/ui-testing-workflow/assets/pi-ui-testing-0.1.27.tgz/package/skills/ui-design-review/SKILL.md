---
name: ui-design-review
description: 对 UI 候选调用独立只读 Agent，按 D1–D10 审查来源、脚本和断言；获批后做正反对照诊断、运行登记或查询旧诊断。不接受生成者自报批准，不执行正式回归。触发词：设计评审、D1–D10 评审、诊断计划、运行就绪、复用旧诊断、状态查询、评审预算。
---

# 设计评审：八步与失败索引

本阶段的价值落在三样产物上：经独立评估的设计结论、并入候选的诊断计划、受控运行证明。approved 只覆盖当前修订的设计，不等于运行就绪，也不等于正式回归可以开跑。

下文工具名、operation 名与字段名，以 `ui_design_review` / `ui_design_diagnose` 的入参和 [rules.md](references/rules.md) 末尾的 JSON 输出契约为准（decision 取 approved/revise/blocked，issue 带 `fix_condition`，improvement 取 first/improved/none），不自行命名。

## 1. 判定本批要做到哪一步

输入：用户诉求与 task 当前 stage。产出：本批目标一句话，以及第一步该走评审、复用还是查状态。

五类诉求不必一次全做：无设计批准不谈运行登记，无运行需求不备计划，只查历史走状态查询。

预算先摆明：每批最多三次评估调用，异常也保留且消耗调用预算。

## 2. 准入：静态检查与 scope 对齐

输入：task_ref、asset_ref。产出：静态检查结论、scope 对齐判定与「可提交 / 先补检查」。

- 🔴 门禁：先完成静态检查、scope 与候选一致，才提交评审；静态阻断不会被模型给出的 approved 覆盖。
- task 的 scope 必须匹配候选；原始证据通过真实文件摘要取得，不接受聊天里的转述。
- 需要运行阶段时先做第 3 步：诊断计划必须与候选同批受审，获批后不能再换入配置、环境或变异来源。

## 3. 需要运行证据时：先备诊断计划

输入：候选与当前目标环境。产出：并入候选 files 的 spec 文件。

调用 `ui_design_diagnose` 的 `{request:{operation:"schema"}}` 查询结构，不需要通过 shell 读取安装目录或提升权限：environment_ref 是当前目标；config_ref 是原生 Playwright 配置；probes 指定隔离错误副本的环境、变异来源和 assertion_ids；需要已知正常副本做正对照时填写 control_environment_ref。每条断言至少有一个合理错误结果探针，脚本和预期值保持不变。

spec 的必填项是 `environment_ref`、`config_ref`、`timeout_ms`（1000–120000）与 `probes[]`（1–30 条，每条含 `id`、`environment_ref`、`config_ref`、`mutation_refs`、`description`、`assertion_ids`）；`control_environment_ref` 可选。顶层两个 ref 指被测目标，探针里的同名 ref 指该探针的隔离错误副本；`assertion_ids` 是探针覆盖的断言列表。这是 schema 的必填子集，完整字段以 `schema` 输出为准。

control_environment_ref 不能替代目标环境的身份/初态检查，也不代表当前产品通过测试。所有配置、环境和变异来源进入修订与独立审查。

## 4. 提交独立评估

输入：task_ref、asset_ref、本批评审用的 request_id。产出：review_ref 与 decision。

调用 `ui_design_review`，参数是顶层的 `{task_ref, asset_ref, request_id}`，不包在 `request` 里。工具会建立全新 Agent 上下文，工具集合为空，使用当前选定模型及 Pi 原生模型注册表认证；不传生成者的聊天/摘要。评估输出及引用由工具校验并登记，不能调用普通 write/store-put 伪造执行授权。

评估正文约束维护在 [rules.md](references/rules.md)，由工具实际读取作为 reviewer 的 system prompt。不要复制另一份规则，也不要让生成者输出 reviewer 结论。工具提供原文片段 anchors 供评估者引用，程序还原真实引用并校验；也兼容精确原文引用，错引用、不存在片段或引文都不能登记批准。规则版本同时绑定提示词和实际输出 schema。

评估输出无效时，错误返回已保存的输入、静态报告及原始响应引用，不能抹掉失败后假称已通过。独立上下文可降低共同偏差，不能代替证据校验。

## 5. 读 decision 并决定下一步

输入：decision、issues、improvement。产出：批准结论，或带 fix_condition 的修订清单。

每条 issue 带 `id`、`rule`（D1–D10）、`case_id` 或 `assertion_id`、`reason`、`evidence_refs`、`fix_condition`、`blocking`；`checks[]` 固定十条，每条给 `rule`、`verdict`（pass/fail/not-applicable，只有 D7 可 not-applicable）、`reason` 与 `evidence`。`blocking=true` 的 issue 未消除就不能批准，平均分不能替代。

- approved：仅表示当前修订的设计批准。源码-only 仍无运行就绪证明；任何脚本/来源/helper/fixture/config/依赖版本变化都要重新校验和必要重审。
- revise：按 issues 的规则、来源和验收条件重新生成受影响的 case/断言/脚本，保存新修订，再以新 request_id 重评；只有对同一次网络请求重试才使用旧 request_id。
- blocked：缺的是无法自行补齐的事实——保持未批准，回退补来源，不改写结论换取通过。
- 重复问题无改善、缺事实、超时或取消时保持未批准。

## 6. 设计获批后做运行登记

输入：asset_ref、review_ref、spec_ref 与本批诊断用的 request_id。产出：非正式诊断证据与 runtime_ready。

已有旧诊断时先试复用（见下节）；复用不成立、或候选已变更时，才调用 `ui_design_diagnose` 的 `{request:{operation:"diagnose",asset_ref,review_ref,spec_ref,request_id}}`。🔴 门禁：没有可信批准、或计划未随候选受审，不跑 diagnose。工具先检查可信批准，再用原生 Playwright 执行正反对照、保存非正式诊断证据，并登记 runtime_ready。没有合理错误副本时保留「设计通过、运行未就绪」，不能放宽断言或伪造证明。

## 7. 查状态与复用旧诊断

输入：request_id，或旧诊断的 asset_ref/review_ref/spec_ref。产出：当前状态，或可复用的 summary_ref。

两者都不靠重跑来猜：复用用来确认现行证明还能不能沿用，状态查询用来确认某个已存请求到底跑到哪。

- 状态：`ui_design_diagnose` 的 `{request:{operation:"status",request_id}}` 只查已存请求，不触发浏览器；相同请求去重。
- 复用：`ui_design_diagnose` 的 `{request:{operation:"reuse",asset_ref,review_ref,spec_ref}}` 只重验现行权威门禁和精确计划摘要，返回 reused=true 与原 summary_ref；不启动浏览器、不产生新的诊断请求，也不续授设计批准。
- 资产、脚本/helper、规则、依赖、配置、登记环境的部署/角色/数据条件或探针来源变更，均不得只凭脚本摘要复用。实际目标的变更影响未知时先核对，不能把登记声明当成当前站点一致的证明；真实身份/数据与环境仍每批预检。
- 重新诊断会使旧运行证明失效；规则、脚本、依赖或证据改变也会拒绝旧证明。

## 8. 预算续授与交接

输入：尝试记录与门禁结论。产出：「未批准 + 失效原因清单」，或续授后可重评的状态说明。

- 预算耗尽后，仅受信任宿主可在用户明确追加授权后调用 `DesignReviewService.renewBudget`，一次追加 1–3 轮；该接口不是模型工具，不根据普通候选文件增额。宿主限制费用并登记授权 ID，私有登记保留原任务、scope 与全部尝试；重复授权幂等、pending 结果不明时拒绝。续授不产生设计批准，不跳过静态检查或独立评审。
- 已开始但结果不明、取消或进程异常时禁止换 ID 重放，先核对原进程与数据；门禁拒绝时保留失效原因，准备受影响修订或诊断，不换请求 ID 逃避未决执行。
- 运行登记只说明这份脚本完成受控设计验证；正式执行仍须新的当前环境/认证/数据预检、新 context 和新批次，不能用聊天中的「通过」替代独立门禁。模块受阻时保留原清单和范围，不静默缩小分母。
- 一个探针可覆盖多条有实际错误观察的断言，原诊断覆盖校验不放宽。

## 9. 失败分支索引

每条都是正文已有约束的归纳，冲突时以正文为准；前者为一线修复，后者为兜底。

- 静态检查有阻断 → 修脚本与断言后重跑检查 → 不出评审请求，不用模型 approved 绕过。
- 评估输出无效（非 JSON、缺项、引文不存在）→ 用保留的 input/static/raw 定位 → 修候选重评，不假称通过。
- 缺无法补齐的事实 → 判 blocked 并回退补来源 → 保持未批准，不改写结论换通过。
- 重复问题无改善 → improvement 记 none 且不批准 → 回退补事实或停手，不删 case、不削弱断言。
- 预算耗尽 → 不自动批准，先结清未决尝试 → 宿主明确追加授权后才有下一轮。
- 结果不明或进程异常 → 先核对原进程与数据 → 禁换 ID 重放。
- 无合理错误副本 → 补一份隔离错误副本的探针 → 仍没有就保留「设计通过、运行未就绪」，不放宽断言。
- 资产/规则/依赖/配置/环境/探针变更 → 判复用失效并保留原因 → 准备受影响修订或诊断。
