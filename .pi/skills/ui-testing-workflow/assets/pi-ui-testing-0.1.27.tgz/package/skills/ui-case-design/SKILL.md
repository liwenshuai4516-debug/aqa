---
name: ui-case-design
description: 从已登记的 UI 功能清单、需求/声明/基线及录制证据生成带来源的 case、断言和 Playwright 候选修订，做静态检查；不批准设计或正式执行。
---

# UI 用例与断言设计

只产出带来源的 case、断言与候选修订；不做设计批准，也不执行测试。

## 1. 读来源，定预期性质

输入：scope、inventory、相关录制、真实来源。产出：每条候选预期的 `source_id` 与 `oracle_type`。

先读上述来源，复用项目已有 fixture/定位器/断言。录制看到的值不能自动当预期：`requirement` 是已确认需求，`declaration` 是代码/HTML 明确声明，`baseline` 是明确标记的当前行为。未知规则留 gap，不补造业务限制。

## 2. 拆 case 与断言

输入：第 1 步的来源清单。产出：cases 草案与每个 case 的 binding。

`cases` 先登记 `sources[]`（`source_id`、`oracle_type`、`ref`、`statement`）；case 用 `module_id`/`feature_id`/`scenario_id` 对齐清单，并给 `priority`（P0/P1/P2）、`cleanup`、`data_row_id`、`browser_project`；断言给 `assertion_id`、`source_id`（引 `sources[]` 中一条）、`oracle_type`、`target`、`comparison`、`expected`、`observation`、`evidence_required`。以上是 schema 的必填子集，完整字段仍以查询结果为准。

每个 case 恰好对应一个 binding：`case_id`、`script_ref`、`test_title`、`assertion_ids`。脚本用静态 test 标题对应 `test_title`，每条断言使用唯一 `test.step('assertion_id 描述', async () => { await expect(...) })`。断言必须验证独立预期下的具体业务对象和时机，不能是常量、实际值与预期同源或只验证点击/提示成功。

## 3. save-file 存不可变文件

输入：脚本、fixture/helper、配置。产出：`FileRef`。

使用 `ui_case_design` 的 `{request:{operation:'save-file',asset_id,revision,name,content}}`，保存当前 asset_id/revision 内不可变的脚本/fixture/config 并返回 FileRef。操作字段均放入 `request`；字段名取自包 CLI 的 `cases`/`asset` schema，不自行命名。

## 4. save-cases 登记用例

输入：第 2 步的 cases 与第 3 步的 `FileRef`（binding 的 `script_ref` 依赖它，故 save-file 先于 save-cases）。产出：cases 产物与其引用。

`{request:{operation:'save-cases',cases}}`。`cases`/`asset` 的完整字段由包 CLI 查 schema，字段名以查询结果为准。

## 5. candidate 登记资产并跑静态检查

输入：asset（含 bindings、dependencies、readiness、files）。产出：静态检查 issues 与 `ready_for_review`。

🔴 门禁：`inventory_ref`、`cases_ref`、`bindings`、`readiness` 未齐不提交 candidate。`{request:{operation:'candidate',asset}}` 登记 asset 并运行 TypeScript 静态检查；`asset.content_sha256` 可传 64 个零占位，candidate 按实际引用重算，不信任生成者摘要。

把 `inventory_ref`、`cases_ref`、录制引用、脚本、本地 helper/fixture、配置和数据规则纳入资产依赖；依赖包锁定实际版本。保留选定主链及未探索范围，不能靠删 case 或断言通过检查。源码-only 使用 `readiness=design-only`，未核验定位器保留缺口；`runtime-verified` 不能自填为执行授权，仍需要受控运行证据。

项目有 TypeScript 配置时，将实际使用的配置及本地 `extends` 一并纳入 `files`；可用 `compiler_config_ref` 指定独立的测试编译配置，诊断 runner 同步使用它。继承包配置时锁定对应包版本。

## 6. 处理静态阻断

输入：第 5 步的 issues。产出：新 case ID 或新资产 revision。

收到静态阻断先修订，使用新 case ID 或资产 revision，不覆盖旧文件。

## 7. 需要运行验证时先备诊断计划

输入：需要受控运行证据的候选。产出：正反对照计划。

本步在交设计评审**之前**完成：调用 `ui_design_diagnose` 的 `{request:{operation:'schema'}}` 查诊断计划结构，保存正反对照计划、环境/config 与变异来源；复用已有受控响应或测试副本，不改业务服务或断言预期来制造「检错成功」。

## 8. 交设计评审

输入：无阻断的候选。产出：评审结论与下一轮修订依据。

结构/编译通过后交给 `/skill:ui-design-review`；独立评估退回后依据明确问题修订并重评。最多三轮、无改善或缺事实时停止，不能更换任务 ID 来规避同一次工作流预算。未批准候选不得作为正式执行输入。

## 9. 失败分支索引

本节为正文约束的归纳索引，非新规则，冲突以正文为准。

- 缺 `inventory_ref` 或 `bindings` → 在候选里补齐 → 补齐前不进评审。
- 清单场景没有用例 → 按清单补 case → 主链缺口留 gap，不删 case。
- `assertion_ids` 与断言不一致、binding 重复或 `script_ref` 不在 `files` → 一 case 一 binding，修脚本引用 → 用新 revision，不覆盖旧文件。
- TS 编译或配置/依赖未入摘要 → 修脚本，tsconfig 与本地 `extends` 入 `files`，包版本入 `dependencies` → 新 revision 重跑 candidate，仍缺即摘要不全。
