---
name: ui-result-analysis
description: 从已有 UI 正式批次计算统计、按原始证据分析失败并生成报告候选（触发词：结果分析、analyze-task、read-trace、save-analysis）。用于分析旧 run，不启动浏览器，不修改原始执行结果；候选须独立结果评估后交付。
---

入参字段名取自 `ui_result_analysis` 工具入参与 analysis 契约，只写必填子集，不自行命名。

## 0. 请求形状

`parse(run_ref,result_id)`、`analyze-task(task_id,findings?)`、`read-trace(results_ref,trace_ref)`、`save-analysis(analysis)`、`draft-report(results_ref,analysis_ref,report_id)` 每个请求带 `request.operation`（值即名称），参数都在 `request` 顶层，**没有 `input` 包裹**。

文件引用一律 `{path,sha256}`，sha256 为 64 位小写十六进制。`analysis` 传完整信封：`{schema_version:"1.0",id,kind:"analysis",created_at,data:{run_ref,results_ref,findings}}`。

## 1. 选入口

入：task_id，或 run_ref + result_id。出：一条 analyze-task 或 parse 请求。

已有工作流优先调 `analyze-task`，传 task_id 与可选 findings：程序取该任务唯一已结束 run 的引用，对账并确定性交接，不复制聊天里的 run_ref/task_ref。view、取消/阻塞任务和中断/未知 run 不进入此入口；execute 已结束时先交接执行；analyze 模式只分析选定旧 run。无任务上下文时退回 `parse`，传 run_ref、result_id。

## 2. 对账统计

入：results_ref、reconciliation_ref、原始报告与步骤。出：逐实例事实与统计口径。

结果由冻结计划与原生 Playwright 报告逐实例对账，覆盖互斥终态、全部 attempt、证据缺口、功能/模块/优先级、oracle 维度。稳定通过率分母为 passed+failed+flaky，分母为零时不适用；不把重试算作新用例，不把 expected-failure 或未到达关键断言的原生 passed 当业务通过。

## 3. 分组

入：全部非 passed 实例。出：groups 与待分析清单。

存在非 passed 实例时先返回 groups，保持 analyze 阶段。分组仅依据终态、证据状态及全部 attempt 的原始错误签名，不证明相同根因；相同签名仍须逐实例独立结论。

## 4. 逐实例取证

入：单实例的 attempts、证据、cleanup、缺口。出：一条 finding。

逐实例检查全部 attempts、证据、cleanup 与缺口，说明数据残留、跳过、取消、未执行、预期失败、首败后成功；首败后通过仍为 flaky，取消/缺证据/数据残留均须保留。每个非 passed 实例生成一条 finding，8 个字段缺一不可：`instance_id`、`classification`（product/script/data/environment/flaky/insufficient-evidence）、`certainty`（confirmed/supported/unknown）、`facts[]`（观察事实）、`hypotheses[]`（候选解释）、`supporting_refs[]`（支持证据）、`alternatives[]`（替代解释/缺口）、`next_action`（下一验证动作）。

`facts`、`next_action`、`supporting_refs` 任一为空即判 insufficient-evidence。supporting_refs 只能取自本批次 results、run 的 output_refs、asset、cases、scope 与 design-review；路径含 `/output/` 时必须是该实例 attempts 里的 evidence_refs，否则判 insufficient-evidence。`certainty=unknown` 时 `alternatives` 必须非空，否则判 invalid-input。原生失败只能证明观察与预期不符；没有服务端依据时，不从超时或 500 推断数据库、网络或具体代码根因。unknown 仍可交付真实完整的失败报告。

## 5. 按需读 trace

入：results_ref 与当前实例 attempt 的原始 trace_ref。出：可引用的原始事件。

需要引用 trace 内部动作、返回值或清理事件时，先调 `read-trace`。trace_ref 路径必须以 `/trace.zip` 结尾且属于本批次已登记实例的 attempt。工具复用 Playwright 1.62.1 的 ZIP 库（版本不符报 incompatible-version），校验归属与摘要，只读 *.trace 的 before/after/log/event/console 原始事件；只读预算 zip ≤32MB、解压事件合计 ≤4MB、返回 JSON ≤512KB，超限报 insufficient-evidence 不截断；不包含快照、网络和资源正文，不证明服务端根因。supporting_refs 引用原始 trace_ref，评估者从同一归档重读。不要用 shell 生成的摘录或仅凭 zip 存在声称看过内容；超预算或损坏时保留缺口，不伪造清理成功。

## 6. 登记 analysis

入：覆盖全部非 passed 实例的 findings。出：analysis_ref。

🔴 CHECKPOINT —— 三条同时成立才登记：`run_ref`/`results_ref` 与当前批次一致、findings 覆盖全部非 passed 实例、每条都有 facts/next_action/supporting_refs 且 refs 在白名单内。以 `save-analysis` 登记 analysis 产物。supporting_refs 仅接受当前 run 的证据与该资产原始来源，不混入其他批次截图；只链接有权查看的证据，不把凭据写入分析。引用存在不代表语义已证实，后续 reviewer 仍须核验解释。

## 7. 生成报告候选

入：results_ref、analysis_ref、report_id。出：report_ref 与候选正文。

🔴 CHECKPOINT —— 发 `draft-report` 前确认 analysis_ref 与 results_ref 同批次，否则回第 6 步。用 `draft-report` 生成候选，返回 `{report_ref,completeness,review_status}`，其中 `review_status` 初始为 `not-reviewed`：程序产出范围、版本、统计、分析、限制，不能改数字、删失败或宣告全产品质量。证据缺失时重新解析为新结果 ID，生成明确 partial 的阶段报告；不覆盖原始 run 或旧结果。

## 8. 独立评审与分流

入：报告候选。出：评审结论与分流建议。

🔴 STOP —— `review_status` 仍为 `not-reviewed` 时不得称已交付、已通过或已提缺陷。再调用 `ui_result_review`，入参 `{request:{operation:"review",report_ref,request_id}}`，完成独立评估；完整报告仍须独立结果评审，不把候选交接当最终批准。处理分流：产品问题仅形成有依据的缺陷草稿；脚本问题新建修订回到设计评估；环境/数据恢复后新批次执行；证据不足先定向补证据。建议动作不表示已经修复、已经回归或已向外部系统提交缺陷。

## 9. 重复调用与状态刷新

入：同一 task_id 或同一结论。出：原候选，或显式新修订。

analyze-task 返回 `{workflow,results_ref,summary{counts,complete,stable_pass_rate},groups[{group_id,status,instances,details,interpretation}],report_ref?,replayed}`；`groups` 只在未给 findings 且存在非 passed 时出现，那一次不生成 analysis 与报告。重复调用返回原候选，不生成新批次；不同结论须显式新修订，不覆盖原分析。checkAnalysis 仍拒绝遗漏或跨实例附件，被拒则补齐后再次调用同一 analyze-task；成功批次自动存空 findings 的分析与完整报告候选，返回简洁 summary。输出携带 workflow 状态，必要时用 `ui_test_workflow status` 按任务ID刷新看板。旧 parse/read-trace/save-analysis/draft-report 路径继续支持。

## 10. 失败分支

工具失败都返回 `{status:"blocked", errors:[{category,message}]}`，按 category 分派，不硬试参数：

- `invalid-input`：实例重复/不在冻结计划、`unknown` 缺 `alternatives`、`report_id` 不合法 → 改对应字段重发，不猜加字段。
- `precondition`：统计或对账与原生报告不符 → 重新 `parse` 成新 result_id，不手改数字。
- `precondition`：task 为 view、run 未 finished、任务不在 running 的 execute/analyze → 停，核对状态再续跑。
- `precondition`：已完成 analyze 且 findings 与原分析不同 → 显式新修订，不覆盖原分析。
- `insufficient-evidence`：漏非 passed 实例、refs 为空或跨批次、trace 超预算 → 补本批次证据或标缺口。
- `incompatible-version`：Playwright 非 1.62.1 → 不读 trace，按缺口交付。
- `cancelled`：请求被取消 → 保留旧产物重跑，不当作部分成功。
