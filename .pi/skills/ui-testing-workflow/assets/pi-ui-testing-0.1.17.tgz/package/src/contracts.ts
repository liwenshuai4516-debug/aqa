import { Type, type Static } from 'typebox';

const id = Type.String({ pattern: '^[a-zA-Z0-9][a-zA-Z0-9._-]{0,95}$' });
const digest = Type.String({ pattern: '^[a-f0-9]{64}$' });
const strings = Type.Array(Type.String());
const enumOf = <T extends string>(values: T[]) => Type.Enum(values);
const object = <T extends Record<string, import('typebox').TSchema>>(properties: T) =>
  Type.Object(properties, { additionalProperties: false });
export const fileRefSchema = object({ path: Type.String({ minLength: 1 }), sha256: digest });
export type FileRef = Static<typeof fileRefSchema>;
const refs = Type.Array(fileRefSchema);
const oracle = enumOf(['requirement', 'declaration', 'baseline']);
const source = object({ source_id: id, oracle_type: oracle, ref: fileRefSchema, statement: Type.String({ minLength: 1 }) });
const issue = object({ id, rule: Type.String({ pattern: '^(D(?:10|[1-9])|R[1-6])$' }),
  case_id: Type.Optional(id), assertion_id: Type.Optional(id), reason: Type.String({ minLength: 1 }),
  evidence_refs: refs, fix_condition: Type.String({ minLength: 1 }), blocking: Type.Boolean() });
const reviewer = object({ context_id: id, model_provider: Type.String(), model_id: Type.String(),
  isolation: enumOf(['separate-agent', 'separate-session']) });
export const assessmentCheckSchema = object({ rule: Type.String({ pattern: '^D(?:10|[1-9])$' }),
  verdict: enumOf(['pass', 'fail', 'not-applicable']), reason: Type.String({ minLength: 1 }),
  evidence: Type.Array(object({ ref: fileRefSchema, quote: Type.String({ minLength: 1 }) }), { minItems: 1 }) });
export const resultCheckSchema = object({ ...assessmentCheckSchema.properties,
  rule: Type.String({ pattern: '^R[1-6]$' }) });
const assessment = {
  subject_ref: fileRefSchema, subject_sha256: digest, round: Type.Integer({ minimum: 1 }),
  decision: enumOf(['approved', 'revise', 'blocked']), rules_version: Type.String({ minLength: 1 }),
  reviewer, checked_rules: Type.Array(Type.String({ pattern: '^(D(?:10|[1-9])|R[1-6])$' })), issues: Type.Array(issue), raw_ref: fileRefSchema,
  checks: Type.Optional(Type.Array(assessmentCheckSchema)), improvement: Type.Optional(enumOf(['first', 'improved', 'none'])),
  previous_review_ref: Type.Optional(fileRefSchema), static_ref: Type.Optional(fileRefSchema), input_ref: Type.Optional(fileRefSchema),
};
const assertion = object({ assertion_id: id, step_id: id, source_id: id, oracle_type: oracle,
  target: Type.String({ minLength: 1 }), comparison: Type.String({ minLength: 1 }), expected: Type.Unknown(),
  observation: Type.String({ minLength: 1 }), evidence_required: Type.Boolean() });
const testcase = object({ case_id: id, module_id: id, feature_id: id, scenario_id: id,
  title: Type.String({ minLength: 1 }), priority: enumOf(['P0', 'P1', 'P2']), preconditions: strings,
  steps: Type.Array(object({ step_id: id, action: Type.String({ minLength: 1 }), assertion_ids: Type.Array(id) }), { minItems: 1 }),
  assertions: Type.Array(assertion, { minItems: 1 }), cleanup: Type.String({ minLength: 1 }),
  data_row_id: id, browser_project: id });
const instance = object({ instance_id: id, case_id: id, revision: id, data_row_id: id, browser_project: id });
export const finalStates = ['passed', 'failed', 'blocked', 'skipped', 'cancelled', 'not-run', 'flaky', 'unknown'] as const;
export const stages = ['discover-record', 'case-design', 'design-review', 'execute', 'analyze', 'result-review'] as const;
export const workflowModes = ['new', 'record', 'execute', 'analyze', 'view', 'resume', 'rerun-failed', 'rerun-all'] as const;
const bodies = {
  scope: object({ project_id: id, environment_id: id, role: Type.String({ minLength: 1 }), goal: Type.String({ minLength: 1 }),
    base_url: Type.Optional(Type.String()), allowed_actions: strings, sources: Type.Array(source),
    budget: object({ max_review_rounds: Type.Integer({ minimum: 1, maximum: 3 }), max_tool_calls: Type.Integer({ minimum: 1 }) }) }),
  inventory: object({ scope_ref: fileRefSchema, features: Type.Array(object({ module_id: id, feature_id: id,
    name: Type.String(), entry: Type.String(), role: Type.String({ minLength: 1 }), actions: strings,
    scenarios: Type.Array(object({ scenario_id: id, title: Type.String({ minLength: 1 }) })),
    coverage: enumOf(['discovered', 'explored', 'blocked']), source_refs: refs,
    source_locations: Type.Array(object({ ref: fileRefSchema, symbol: Type.String(), line: Type.Integer({ minimum: 1 }) })),
    discovery: enumOf(['source', 'browser', 'both', 'unconfirmed']),
    priority: enumOf(['P0', 'P1', 'P2']), states: strings, gaps: strings })), unexplored: strings,
    draft_refs: Type.Optional(refs) }),
  recording: object({ scope_ref: fileRefSchema, inventory_ref: fileRefSchema, initial_state: Type.String({ minLength: 1 }),
    status: enumOf(['complete', 'partial']), initial_state_ref: fileRefSchema, data_rules_ref: fileRefSchema,
    log_ref: fileRefSchema, script_refs: refs, steps: Type.Array(object({ step_id: id, intent: Type.String(),
      tool: Type.String(), observation_ref: fileRefSchema })), data_refs: refs,
    completion: object({ initial_state_rebuildable: Type.Boolean(), replaceable_data: Type.Boolean(),
      stable_locators: Type.Boolean(), assertion_sources: Type.Boolean(), cleanup_owned: Type.Boolean() }), gaps: strings }),
  cases: object({ scope_ref: fileRefSchema, sources: Type.Array(source), cases: Type.Array(testcase, { minItems: 1 }),
    data_rules_ref: fileRefSchema, gaps: strings }),
  asset: object({ revision: id, module_ids: Type.Array(id, { minItems: 1 }), scope_ref: fileRefSchema,
    cases_ref: fileRefSchema, recording_refs: refs, files: Type.Array(fileRefSchema, { minItems: 1 }),
    inventory_ref: Type.Optional(fileRefSchema),
    compiler_config_ref: Type.Optional(fileRefSchema),
    bindings: Type.Optional(Type.Array(object({ case_id: id, script_ref: fileRefSchema,
      test_title: Type.String({ minLength: 1 }), assertion_ids: Type.Array(id, { minItems: 1 }) }))),
    dependencies: Type.Array(object({ name: Type.String({ minLength: 1 }), version: Type.String({ minLength: 1 }) })),
    readiness: enumOf(['design-only', 'runtime-verified']), content_sha256: digest, gaps: strings }),
  'design-review': object(assessment),
  task: object({ intent: enumOf(['record', 'execute', 'analyze', 'view', 'resume', 'rerun-failed', 'rerun-all']),
    workflow: Type.Optional(object({ mode: enumOf([...workflowModes]), source_run_ref: Type.Optional(fileRefSchema),
      discovery: Type.Optional(enumOf(['source', 'browser', 'both'])) })),
    scope_ref: fileRefSchema, state: enumOf(['pending', 'running', 'blocked', 'completed', 'cancelled']),
    stage: enumOf([...stages]), completed_stages: Type.Array(enumOf([...stages])), input_sha256: digest,
    asset_refs: refs, run_ids: Type.Array(id), output_refs: refs, blockers: strings }),
  run: object({ task_id: id, request_id: id, parent_run_id: Type.Optional(id), asset_ref: fileRefSchema,
    environment_id: id, deployment_version: Type.String(), role: Type.String(),
    plan: Type.Array(instance, { minItems: 1 }), state: enumOf(['pending', 'running', 'finished', 'interrupted', 'unknown']),
    command: strings, process_token: id, pid: Type.Optional(Type.Integer({ minimum: 1 })),
    exit_code: Type.Optional(Type.Union([Type.Integer(), Type.Null()])), output_refs: refs }),
  results: object({ run_ref: fileRefSchema, raw_ref: fileRefSchema, planned_count: Type.Integer({ minimum: 0 }),
    raw_kind: Type.Optional(enumOf(['native-report', 'execution-summary', 'run-manifest'])),
    reconciliation_ref: Type.Optional(fileRefSchema),
    instances: Type.Array(object({ instance_id: id, status: enumOf([...finalStates]),
      evidence_state: enumOf(['complete', 'missing']), attempts: Type.Array(object({ attempt: Type.Integer({ minimum: 0 }),
        native_status: Type.String(), evidence_refs: refs, errors: strings })) })),
    counts: object(Object.fromEntries(finalStates.map(s => [s, Type.Integer({ minimum: 0 })]))) }),
  analysis: object({ run_ref: fileRefSchema, results_ref: fileRefSchema, findings: Type.Array(object({ instance_id: id,
    classification: enumOf(['product', 'script', 'data', 'environment', 'flaky', 'insufficient-evidence']),
    certainty: enumOf(['confirmed', 'supported', 'unknown']), facts: strings, hypotheses: strings,
    supporting_refs: refs, alternatives: strings, next_action: Type.String() })) }),
  'result-review': object({ ...assessment, checks: Type.Optional(Type.Array(resultCheckSchema)) }),
  report: object({ run_ref: fileRefSchema, results_ref: fileRefSchema, analysis_ref: fileRefSchema,
    content_ref: fileRefSchema, follow_up_ref: Type.Optional(fileRefSchema), completeness: enumOf(['complete', 'partial']), limitations: strings }),
};

// schema 是交接契约，不定义浏览器 DSL；真实步骤仍由 Playwright Test 执行。
function envelope<K extends keyof typeof bodies>(kind: K) {
  return object({ schema_version: Type.Literal('1.0'), id, kind: Type.Literal(kind),
    created_at: Type.String({ minLength: 20 }), data: bodies[kind] });
}
export const schemas = {
  scope: envelope('scope'), inventory: envelope('inventory'), recording: envelope('recording'), cases: envelope('cases'),
  asset: envelope('asset'), 'design-review': envelope('design-review'), task: envelope('task'), run: envelope('run'),
  results: envelope('results'), analysis: envelope('analysis'), 'result-review': envelope('result-review'), report: envelope('report'),
};
export type ArtifactKind = keyof typeof schemas;
export type Artifact<K extends ArtifactKind = ArtifactKind> = Static<(typeof schemas)[K]>;
export const errorCategories = ['invalid-input', 'incompatible-version', 'missing-capability', 'precondition',
  'review-rejected', 'runner-error', 'insufficient-evidence', 'cancelled'] as const;
export type ErrorCategory = typeof errorCategories[number];
export const capabilityResultSchema = object({ schema_version: Type.Literal('1.0'),
  capability_id: Type.String({ minLength: 1 }), capability_version: Type.String({ minLength: 1 }),
  status: enumOf(['completed', 'blocked', 'failed', 'cancelled']), artifact_refs: refs,
  errors: Type.Array(object({ category: enumOf([...errorCategories]), message: Type.String({ minLength: 1 }),
    recoverable: Type.Boolean(), recovery_stage: Type.Optional(Type.String()) })) });
export type CapabilityResult = Static<typeof capabilityResultSchema>;
export const capabilities = [{ capability_id: 'ui-validate-artifact', capability_version: '0.1.0',
  input_schema_version: '1.0', output_schema_version: '1.0',
  tool: 'ui_validate_artifact', side_effects: 'none', safe_to_repeat: true,
  requires: { pi: '1.2.0', schema: '1.0' }, errors: ['invalid-input', 'incompatible-version', 'precondition'],
}, { capability_id: 'ui-discover-record', capability_version: '0.1.0',
  input_schema_version: '1.0', output_schema_version: '1.0', tool: 'ui_discover_record',
  side_effects: 'project-files-and-browser-actions', safe_to_repeat: false,
  requires: { pi: '1.2.0', schema: '1.0', playwright: '1.62.1' },
  errors: ['invalid-input', 'missing-capability', 'precondition', 'cancelled'],
}, { capability_id: 'ui-case-design', capability_version: '0.1.0',
  input_schema_version: '1.0', output_schema_version: '1.0', tool: 'ui_case_design',
  side_effects: 'project-files', safe_to_repeat: true, requires: { pi: '1.2.0', schema: '1.0', typescript: '5.9.3' },
  errors: ['invalid-input', 'precondition', 'incompatible-version'],
}, { capability_id: 'ui-design-review', capability_version: '0.1.0',
  input_schema_version: '1.0', output_schema_version: '1.0', tool: 'ui_design_review',
  side_effects: 'model-call-and-review-records', safe_to_repeat: false, requires: { pi: '1.2.0', schema: '1.0' },
  errors: ['invalid-input', 'precondition', 'review-rejected', 'cancelled'],
}, { capability_id: 'ui-design-diagnose', capability_version: '0.1.0',
  input_schema_version: '1.0', output_schema_version: '1.0', tool: 'ui_design_diagnose',
  side_effects: 'browser-actions-and-native-runner', safe_to_repeat: false,
  requires: { pi: '1.2.0', schema: '1.0', playwright: '1.62.1' },
  errors: ['invalid-input', 'precondition', 'review-rejected', 'missing-capability', 'cancelled'],
}, { capability_id: 'ui-test-run', capability_version: '0.1.0',
  input_schema_version: '1.0', output_schema_version: '1.0', tool: 'ui_test_run',
  side_effects: 'formal-browser-actions-and-native-runner', safe_to_repeat: false,
  requires: { pi: '1.2.0', schema: '1.0', playwright: '1.62.1' },
  errors: ['invalid-input', 'precondition', 'review-rejected', 'missing-capability', 'incompatible-version', 'runner-error', 'cancelled'],
}, { capability_id: 'ui-result-analysis', capability_version: '0.1.0',
  input_schema_version: '1.0', output_schema_version: '1.0', tool: 'ui_result_analysis',
  side_effects: 'read-evidence-and-write-analysis-artifacts', safe_to_repeat: true,
  requires: { pi: '1.2.0', schema: '1.0', playwright: '1.62.1' }, errors: ['invalid-input', 'precondition', 'insufficient-evidence'],
}, { capability_id: 'ui-result-review', capability_version: '0.1.0',
  input_schema_version: '1.0', output_schema_version: '1.0', tool: 'ui_result_review',
  side_effects: 'model-call-and-report-records', safe_to_repeat: false,
  requires: { pi: '1.2.0', schema: '1.0' }, errors: ['invalid-input', 'precondition', 'review-rejected', 'insufficient-evidence', 'cancelled'],
}, { capability_id: 'ui-test-workflow', capability_version: '0.1.0',
  input_schema_version: '1.0', output_schema_version: '1.0', tool: 'ui_test_workflow',
  side_effects: 'task-index-and-report-delivery-records', safe_to_repeat: true,
  requires: { pi: '1.2.0', schema: '1.0' }, errors: ['invalid-input', 'precondition', 'missing-capability', 'incompatible-version', 'review-rejected', 'cancelled'],
}];
