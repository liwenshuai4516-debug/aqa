from pathlib import Path
import json,hashlib,shutil,tarfile,io,os
repo=Path.cwd();out=repo/'tests/scratch/ui-pms-anonymous-diagnostics/1792990404494';result=json.loads((out/'result.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest();files={};refs=0
assert result['candidate']['output']['issues']==[] and result['candidate']['output']['design_approved'] is False
assert all(r['status']=='completed' for r in result['environmentPreflight'].values())
assert result['modelCalls']==result['candidateReplays']==result['formalRuns']==0
(out/'.cleanup-keep').write_text('Unreviewed native PMS anonymous diagnostic handoff; retain until plan completion.\n')
# Static source evidence only. These observations do not claim privacy repair or exploit reproduction.
auditdir=out/'privacy-audit';auditdir.mkdir()
paths={
 'sdk-tools.js':'node_modules/@earendil-works/pi-coding-agent/dist/extensions/mcp/tools.js',
 'sdk-mcp-options.d.ts':'node_modules/@earendil-works/pi-coding-agent/dist/extensions/mcp/index.d.ts',
 'playwright-test-browser-backend.js':'tools/e2e/node_modules/playwright/lib/mcp/test/browserBackend.js',
 'stdio.js':'node_modules/@earendil-works/pi-mcp/dist/transports/stdio.js',
 'host-mcp-extension.mjs':'.pi/skills/ui-testing-workflow/assets/mcp-extension.mjs',
}
sources=[]
for target,source in paths.items():
 p=repo/source;b=p.read_bytes();(auditdir/target).write_bytes(b);sources.append({'origin':source,'snapshot':str((auditdir/target).relative_to(out)),'sha256':sha(b),'bytes':len(b)})
p=repo/'tools/e2e/node_modules/playwright-core/lib/coreBundle.js';lines=p.read_text().splitlines();excerpt='\n'.join(lines[65079:65110])+'\n';(auditdir/'output-directory-excerpt.txt').write_text(excerpt)
audit={'classification':'static source audit; no private recording attempt or repair this turn','sources':sources,'coreBundle':{'origin':str(p.relative_to(repo)),'sha256':sha(p.read_bytes()),'first_line':65080,'last_line':65110,'excerpt_sha256':sha(excerpt.encode())},'facts':['MCP tools call convertMcpResult before returning; limitMcpContent may save unredacted full output to a temporary file','Model content and structuredContent retain separate forms; filtering only top-level text is insufficient','StdioTransport emits parsed incoming messages through onMessage; McpExtensionOptions exposes createTransport','Playwright test browser backend builds fixed capabilities-only config and returns snapshots/errors; no outputDir option is forwarded there','Core outputDir defaults to clientInfo.cwd/.playwright-mcp unless config.outputDir is supplied'],'next_required':['Intercept/sanitize sensitive protocol messages before SDK conversion and auxiliary temp writes','Keep raw Playwright output files/media outside the public workspace, while preserving private originals and explicit public evidence gaps','Verify nested content/structuredContent/progress/error/media/resources, referenced files, cancellation and reconnection through real SDK/MCP and Electron','Do not enable generic authenticated recording until these boundaries are verified'],'unchanged':'Current private recording remains unsupported; no SDK/Playwright installation files edited'}
(auditdir/'audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')
def walk(v):
 global refs
 if isinstance(v,dict):
  if isinstance(v.get('path'),str) and isinstance(v.get('sha256'),str):
   p=Path(v['path']);assert not p.is_absolute() and '..' not in p.parts
   f=out/p;assert sha(f.read_bytes())==v['sha256'],str(f);refs+=1
  for value in v.values():walk(value)
 elif isinstance(v,list):
  for value in v:walk(value)
for f in (out/'qa').rglob('*.json'):walk(json.loads(f.read_text()))
asset=json.loads((out/result['assetRef']['path']).read_text());old=json.loads((out/result['previousAssetRef']['path']).read_text());assert asset['data']['bindings'][0]['script_ref']['sha256']==old['data']['bindings'][0]['script_ref']['sha256']
# Persist only the declared public handoff, never dependencies or private authority/configuration.
project='e2f5d42d-2781-4e68-a452-4c87c7d1d346';docdir=Path.home()/'Library/Application Support/Pi Agent Desktop/data/data-space/project-documents'/project
store=docdir.parent.parent/'store.json';before=sha(store.read_bytes())
snapshot=docdir/('anonymous-diagnostics-'+result['assetRef']['sha256'][:12]);snapshot.mkdir(mode=0o700)
for name in ['qa','tests','playwright.config.mjs','.playwright-mcp','result.json','candidate-response.json','diagnostic-schema.json']:
 p=out/name
 if p.is_dir():shutil.copytree(p,snapshot/name)
 else:shutil.copyfile(p,snapshot/name)
text=f'''# 经营合同匿名跳转：诊断输入 v2（未评审、未执行）

项目/环境沿用项目管理系统 Electron 所选数据空间。资产：{result['assetRef']['path']}；摘要：{result['assetRef']['sha256']}。

唯一行为基线：匿名访问 /pms/OperationContract 后，页面 URL 应保持当前环境 origin，pathname 为 /login。不是已确认产品需求；正向正式测试未执行。

v2 与 v1 的候选脚本及断言逐字节相同，SHA-256：{result['unchangedScriptSha256']}。v2 仅增加审查前冻结的诊断计划、环境/config、错误服务源码和来源回执。

错误副本是 http://127.0.0.1:18982 的独立本地合成服务：保留匿名登录标记，但刻意不在经营合同入口跳转。未来对同一脚本、同一期望运行时，A-anonymous-redirect 应失败。服务不读取真实PMS数据；当前已关闭。

真实站点公开应用包与原基线摘要一致。原生环境预检已分别核对真实站点及错误副本的匿名页面标记；这不等于已运行正反诊断，也不产生 runtime_ready。真实站点预检没有提供请求方法计数，不声明目标请求为零。

诊断计划：{result['specRef']['path']}；摘要：{result['specRef']['sha256']}。

状态：原生静态检查无阻断、1场景/1断言；设计未批准，付费评审授权仍待答复；候选回放0、正反诊断0、正式执行0、模型调用0。没有把已有3条草稿升级为已录制或已通过。

恢复：审查最新v2全部原始来源和诊断输入；取得独立批准后，从冻结negative-server.mjs启动错误副本，确认端口属于本轮进程，再按原生ui_design_diagnose执行；终止自有服务并留证。不得复用陌生监听服务，不得更换断言预期以通过。

公开快照在本目录 {snapshot.name}/ 保留；原v1文档与产物保留。通用私密录制、业务角色/数据、Electron Agent全链和整计划仍未完成。
'''
doc=docdir/'OperationContract-anonymous-diagnostic-inputs-2026-10-26.md'
with doc.open('x') as f:f.write(text)
persisted=[]
for p in snapshot.rglob('*'):
 if p.is_file():
  os.chmod(p,0o600);rel=p.relative_to(snapshot);assert p.read_bytes()==(out/rel).read_bytes();persisted.append({'path':str(rel),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size})
 elif p.is_dir():os.chmod(p,0o700)
os.chmod(doc,0o600);assert doc.read_text()==text;assert sha(store.read_bytes())==before
receipt={'document':{'path':str(doc),'sha256':sha(doc.read_bytes()),'bytes':doc.stat().st_size},'snapshot':{'path':str(snapshot),'files':persisted},'storeUnchanged':True,'storeSha256':before,'application_document_index':'unsupported','new_case_imports':0}
(out/'data-space-documents.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
def add(p):
 assert not p.is_symlink();name=str(p.relative_to(repo));assert not set(name.split('/'))&{'node_modules','agent','auth.json','models.json','private-reviews','private-evidence'};files[name]=p.read_bytes()
def tree(p):
 for f in sorted(p.rglob('*')):
  if f.is_file() and not f.is_symlink():add(f)
tree(out)
failed=[]
for run in ['1792990292894','1792990345137']:
 p=repo/'tests/scratch/ui-pms-anonymous-diagnostics'/run;tree(p);failed.append(str(p.relative_to(repo)))
for p in (repo/'tests/scratch/ui-optimization-u00').glob('pms-anonymous-diagnostic*.log'):add(p)
for name in ['prepare-pms-anonymous-diagnostics.mjs','archive-pms-anonymous-diagnostics.py','u02-recording-audit-clean.log']:add(repo/'tests/scratch/ui-optimization-u00'/name)
ledger=repo/'tests/scratch/ui-optimization-u00/u05-authorized-review-budget.json';prior=json.loads((repo/'docs/ui-testing-evidence/optimization-pms-anonymous-recording.json').read_text());assert sha(ledger.read_bytes())==prior['modelReviewLedgerSha256']
archive=repo/'docs/ui-testing-evidence/optimization-pms-anonymous-diagnostics.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for n,b in sorted(files.items()):m=tarfile.TarInfo(n);m.size=len(b);m.mtime=0;t.addfile(m,io.BytesIO(b))
with tarfile.open(archive) as t:
 assert set(t.getnames())==set(files)
 for m in t:assert t.extractfile(m).read()==files[m.name]
index={'date':'2026-10-26','status':'V2_DIAGNOSTIC_INPUTS_AND_ENVIRONMENT_PREFLIGHT_READY_REVIEW_PENDING','plan_complete':False,'modelCalls':0,'candidateReplays':0,'formalRuns':0,'modelReviewLedgerSha256':sha(ledger.read_bytes()),'ledger_unchanged':True,'result':result,'public_refs_verified':refs,'durable_project_documents':receipt,'failed_preparations':failed,'failure_causes':['v2 selected both old and copied candidate scripts, causing duplicate static test mapping; old artifact preserved and only v2 binding selected','Two new configs omitted utf8 when parsing readFileSync; native static compiler rejected Buffer as string, corrected configs only'],'privacy_audit':audit,'approval':'Same anonymous one-case scope; prior question pending. No model call or paid budget renewal performed. Latest v2 must be reviewed including frozen diagnostics.','limits':['No diagnostic or formal run occurred; environment preflight only','Real target preflight request methods not counted; no zero-request claim','Negative service was closed; restart exact immutable source before future approved diagnostics','No private recording repair or real authenticated business test','No Electron Agent discovery-to-delivery acceptance'],'archive':{'path':str(archive.relative_to(repo)),'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'files':len(files),'roundtrip_verified':True},'files':[{'path':n,'sha256':sha(b),'bytes':len(b)}for n,b in sorted(files.items())]}
(repo/'docs/ui-testing-evidence/optimization-pms-anonymous-diagnostics.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'files':len(files),'refs':refs,'bytes':archive.stat().st_size,'persistent_files':len(persisted)},ensure_ascii=False))
