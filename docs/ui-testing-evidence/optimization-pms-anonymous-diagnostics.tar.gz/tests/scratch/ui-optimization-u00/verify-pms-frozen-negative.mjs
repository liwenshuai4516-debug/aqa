/** Verify the exact frozen service, without executing the candidate or diagnostic runner. */
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {once} from 'node:events';
import {readFile,writeFile,cp} from 'node:fs/promises';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {preflightEnvironment,sha256} from 'pi-ui-testing';
const root=join(process.cwd(),'tests/scratch/ui-pms-anonymous-diagnostics/1792990404494'),base='qa/ui/assets/pms-anonymous-redirect/revisions/v2';
const spec=JSON.parse(await readFile(join(root,base,'diagnostic-plan.json'))),mutation=spec.probes[0].mutation_refs.find(r=>r.path.endsWith('negative-server.mjs'));
assert.equal(sha256(await readFile(join(root,mutation.path))),mutation.sha256);
const environment=JSON.parse(await readFile(join(root,base,'negative-environment.json')));
const child=spawn(process.execPath,['--input-type=module','-e',`await import(${JSON.stringify(pathToFileURL(join(root,mutation.path)).href)});await new Promise(setImmediate);console.log('SOURCE_READY');`],{stdio:['ignore','pipe','pipe']});
let stderr='',stdout='',ready=false,closed=false,preflight,response;
child.stderr.on('data',b=>{stderr+=b});
const exit=once(child,'exit');
try{
 await new Promise((ok,no)=>{
  const timer=setTimeout(()=>no(Error('Frozen service startup timeout')),10000);
  child.once('error',e=>{clearTimeout(timer);no(e)});
  child.once('exit',()=>{clearTimeout(timer);if(!ready)no(Error('Frozen service exited before ready: '+stderr))});
  child.stdout.on('data',b=>{stdout+=b;if(stdout.includes('SOURCE_READY')){ready=true;clearTimeout(timer);ok();}});
 });
 assert.equal(child.exitCode,null);
 const actual=await fetch(environment.base_url+'/pms/OperationContract',{redirect:'manual',signal:AbortSignal.timeout(5000)}),html=await actual.text();
 assert.equal(actual.status,200);assert.equal(actual.headers.get('location'),null);assert.ok(html.includes('密码认证')&&html.includes('登 录'));
 response={status:actual.status,location:actual.headers.get('location'),bodySha256:sha256(html),pathname:new URL(actual.url).pathname,baselineFaultObserved:'protected path returns 200 without redirect; candidate not executed'};
 preflight=await preflightEnvironment(root,environment,30000);assert.equal(preflight.status,'completed');
}finally{
 if(child.exitCode===null)child.kill('SIGTERM');
 const [code,signal]=await exit;closed=true;
 assert.equal(code,0,'Owned frozen service did not close normally: '+stderr);assert.equal(signal,null);
}
const result={status:'EXACT_FROZEN_SOURCE_PREFLIGHT_VERIFIED',mutationRef:mutation,preflight,response,ownedServiceReady:ready,ownedServiceClosed:closed,modelCalls:0,candidateReplays:0,formalRuns:0,network:'Local frozen service only; no new real target requests'};
await cp(new URL(import.meta.url),join(root,'verify-frozen-negative.mjs'));await writeFile(join(root,'exact-negative-preflight.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));
