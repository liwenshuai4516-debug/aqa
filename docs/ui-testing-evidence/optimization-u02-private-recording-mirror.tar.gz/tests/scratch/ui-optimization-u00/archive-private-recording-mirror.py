from pathlib import Path
import json,hashlib,tarfile,io,os,shutil
repo=Path.cwd();root=repo/'tests/scratch/ui-private-recording-handoff';sha=lambda b:hashlib.sha256(b).hexdigest()
ids={'complete':'1792994031404','stale':'1792994035932','existing':'1792993937332','symlink':'1792993982916'}
results={name:json.loads((root/id/'result.json').read_text()) for name,id in ids.items()}
assert results['complete']['recordingStatus']=='complete' and results['complete']['finishGaps']==[] and results['complete']['publicScriptEqualsNative']
for name,r in results.items():
 assert r['modelCalls']==r['formalRuns']==r['businessWrites']==0 and r['ownedRawOutputsRemoved']
 assert all(not t['containsSyntheticSecret'] and t['mediaBlocks']==0 for t in r['tools'])
 if name!='complete':assert r['recordingStatus']=='partial' and r['finishGaps'] and r['nativeDraftPublication']=='not-published-failure-preserved'
assert results['stale']['staleSnapshotBlockedBeforeNativeWrite'] and results['existing']['existingOutputPreserved'] and results['symlink']['symlinkOutsideWritePrevented']
ledger=repo/'tests/scratch/ui-optimization-u00/u05-authorized-review-budget.json';assert sha(ledger.read_bytes())==json.loads((repo/'docs/ui-testing-evidence/optimization-u02-private-recording-boundary.json').read_text())['modelReviewLedgerSha256']
verified=0
for directory in root.iterdir():
 if not directory.is_dir():continue
 (directory/'.cleanup-keep').write_text('Retain synthetic native mirror recording and partial failures; no private raw payloads.\n')
 # Restore original relative layout of the directly saved seed copy for public FileRef verification.
 if (directory/'seed.spec.ts').exists():
  (directory/'tests').mkdir(exist_ok=True);(directory/'tests/seed.spec.ts').write_bytes((directory/'seed.spec.ts').read_bytes())
 def walk(v):
  global verified
  if isinstance(v,dict):
   if isinstance(v.get('path'),str) and isinstance(v.get('sha256'),str):
    p=Path(v['path']);assert not p.is_absolute() and '..' not in p.parts
    assert sha((directory/p).read_bytes())==v['sha256'],str(directory/p);verified+=1
   for x in v.values():walk(x)
  elif isinstance(v,list):
   for x in v:walk(x)
 for p in (directory/'qa').rglob('*.json'):walk(json.loads(p.read_text()))
 if (directory/'seed.spec.ts').exists() and 'inputHashes' in json.loads((directory/'result.json').read_text()).get('snapshot',{}):
  expected=json.loads((directory/'result.json').read_text())['snapshot']['inputHashes'];assert sha((directory/'seed.spec.ts').read_bytes())==expected['tests/seed.spec.ts'];assert sha((directory/'playwright.config.mjs').read_bytes())==expected['playwright.config.mjs']
text='''# UI 私密录制：私有副本与原生草稿交接（隔离原型）

日期：2026-10-26。为项目管理系统后续验收补工程证据，全部访问本机合成页面；没有真实PMS登录/业务请求、模型调用或正式测试。

上一原型直接迁移MCP roots造成原生writer与原项目testDir不匹配。本轮将已知合成项目的package/config/seed逐字节复制到工作区外私有副本，共享原node_modules链接，不改Playwright或SDK。MCP仍使用同一1.62.1 CLI，读取副本配置，原生writer在副本tests目录内正常工作。最终版本将两侧配置/seed与创建时冻结的SHA-256分别比对，避免两份同时被改后仅彼此相等。

公开发布只接受本次声明的相对草稿路径；调用前拒绝已有公开目标、秘密输入和符号链接，原生成功响应后核对原生文件为普通文件、代码与请求逐字节相同且不含已知秘密/私有路径，再用独占wx写入公开工作区。未静默脱敏草稿代码，没有放宽原生writer边界。并发竞争、取消后晚响应等尚未测试。

最终正常轮通过实际ui_discover_record inventory/start/action/finish，经SDK嵌套调用原MCP，完成setup、snapshot、read_log、write_test、close共5步。原生finish返回complete、gaps=[]，1份草稿与原生生成文件字节一致。全部公开响应/工作区与SDK长输出检查没有已知合成秘密；公开媒体块0。原始协议仍在私有副本中含合成原文，公开日志是减少内容后的证据，不是完整原始捕获。

三个反例均保留原生partial：
- 私有副本seed被改：摘要不符，在原生writer执行前阻断，公开/私有草稿均未生成；仍关闭context并finish，保留snapshot-changed/missing-script/tool-error等缺口。
- 公开草稿已存在：原生RecordingService阻断，旧字节保留，私有writer未调用；finish partial、没有script_refs。
- 草稿父目录为指向区外的符号链接：适配层阻断，没有向链接目标写入；finish partial、没有script_refs。

一次准备验证脚本误将预期blocked当作completed而失败，保留当时摘要和源码；后来修正测试期望，不更改原生阻断结果。较早一轮partial结果的nativeDraftPublication摘要字段错误沿用了complete措辞，原生manifest实际始终partial；历史保留，最终复验字段已更正为not-published-failure-preserved。

限制：仅复制已知fixture的3份输入，不是通用项目依赖闭包方案；尚未解决任意项目配置/导入/fixture、副本路径与受管auth workspace绑定、JSON存储/新增凭据、进度/错误/文件链接、取消/断连/重连、实际Electron登记与验收。原型未进入产品；真实数据空间prepare-private仍不支持record，未修改个人安装。

结束后自有会话/MCP/浏览器/本机服务和仅本轮原始合成payload全部清理，公开源码、摘要及原生complete/partial证据保留。正常录制complete不代表设计批准、正式执行、真实业务权限或整计划完成。

公开快照：private-recording-mirror-1792994031404/，包含正常及3个反例各自的原生QA证据和源码；文件保存不代表应用文档索引可见或正式用例/结果入库。
'''
docdir=Path.home()/'Library/Application Support/Pi Agent Desktop/data/data-space/project-documents/e2f5d42d-2781-4e68-a452-4c87c7d1d346';store=docdir.parent.parent/'store.json';before=store.read_bytes();snapshot=docdir/'private-recording-mirror-1792994031404';snapshot.mkdir(mode=0o700)
for name,id in ids.items():shutil.copytree(root/id,snapshot/name)
persisted=[]
for p in snapshot.rglob('*'):
 if p.is_dir():os.chmod(p,0o700)
 elif p.is_file():
  assert not p.is_symlink();os.chmod(p,0o600);rel=p.relative_to(snapshot);name,*parts=rel.parts;assert p.read_bytes()==(root/ids[name]/Path(*parts)).read_bytes();persisted.append({'path':str(rel),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size})
doc=docdir/'OperationContract-private-recording-mirror-2026-10-26.md'
with doc.open('x') as f:f.write(text)
os.chmod(doc,0o600);assert doc.read_text()==text and store.read_bytes()==before
receipt={'document':{'path':str(doc),'sha256':sha(doc.read_bytes()),'bytes':doc.stat().st_size},'snapshot':{'path':str(snapshot),'files':persisted},'storeUnchangedDuringDocumentSave':True,'application_document_index':'unsupported'}
(root/ids['complete']/'data-space-documents.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
files={}
for base in [root,repo/'tests/scratch/ui-private-recording-mirror/1792993460323']:
 for p in sorted(base.rglob('*')):
  if p.is_file():assert not p.is_symlink();files[str(p.relative_to(repo))]=p.read_bytes()
for p in (repo/'tests/scratch/ui-optimization-u00').glob('private-recording-handoff*.log'):files[str(p.relative_to(repo))]=p.read_bytes()
for name in ['private-recording-mirror.log','probe-private-recording-handoff.mjs','private-recording-mirror-prototype.mjs','archive-private-recording-mirror.py']:
 p=repo/'tests/scratch/ui-optimization-u00'/name;files[str(p.relative_to(repo))]=p.read_bytes()
archive=repo/'docs/ui-testing-evidence/optimization-u02-private-recording-mirror.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for n,b in sorted(files.items()):
  m=tarfile.TarInfo(n);m.size=len(b);m.mtime=0;t.addfile(m,io.BytesIO(b))
with tarfile.open(archive) as t:
 assert set(t.getnames())==set(files)
 for m in t:assert t.extractfile(m).read()==files[m.name]
index={'date':'2026-10-26','status':'PRIVATE_MIRROR_NATIVE_RECORDING_COMPLETE_THREE_CONTROLS_PARTIAL_PRODUCT_UNCHANGED','plan_complete':False,'product_private_recording':'unsupported','modelCalls':0,'formalRuns':0,'modelReviewLedgerSha256':sha(ledger.read_bytes()),'ledger_unchanged':True,'current_runs':{n:{'directory':str((root/id).relative_to(repo)),'result':results[n]}for n,id in ids.items()},'public_refs_verified':verified,'historical_harness_failure':'1792993794230 expected completed for native blocked response; only summary/source retained there, no full public QA closure; final stale run preserves native partial closure','historical_summary_correction':'1792993847702 nativeDraftPublication summary wrongly said complete; manifest partial with zero scripts preserved; final stale run has correct summary','durable_project_documents':receipt,'limits':['Prototype only; no product/installed SDK/Playwright/personal configuration changes','Three known fixture source files only; no generic import/fixture closure','No managed-auth mirror workspace binding or real PMS/Electron privacy acceptance','No publication-race/cancellation-late-response/reconnect proof','No generic secrets/rotating credentials/JSON storage/protocol coverage','Raw synthetic payloads removed; public native raw-log.json is already reduced evidence'],'archive':{'path':str(archive.relative_to(repo)),'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'files':len(files),'roundtrip_verified':True},'files':[{'path':n,'sha256':sha(b),'bytes':len(b)}for n,b in sorted(files.items())]}
(repo/'docs/ui-testing-evidence/optimization-u02-private-recording-mirror.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'files':len(files),'bytes':archive.stat().st_size,'persistent_files':len(persisted),'refs':verified,'ledger_unchanged':True}))
