/** Private synthetic experiment only. Not registered in the product; exact source snapshot and exclusive draft publication experiment. */
import {appendFileSync,readFileSync,writeFileSync,lstatSync,existsSync} from 'node:fs';
import {pathToFileURL} from 'node:url';
import {join,dirname,isAbsolute,relative} from 'node:path';
import {createHash} from 'node:crypto';
import {StdioTransport} from '@earendil-works/pi-mcp';
import {createMcpExtension} from '@earendil-works/pi-coding-agent';
import {validateRecordingSeed} from '../../../.pi/skills/ui-testing-workflow/assets/recording-preflight.mjs';
import {resolvePlaywrightRuntime} from '../../../.pi/skills/ui-testing-workflow/assets/playwright-runtime.mjs';
export function probeExtension({rawRoot,statePath,workspace,outputFile,inputFiles}){
 const state=JSON.parse(readFileSync(statePath,'utf8'));
 const values=[rawRoot,statePath,...state.cookies.map(c=>c.value)];
 const secrets=[...new Set(values.flatMap(v=>[v,encodeURI(v),encodeURIComponent(v),JSON.stringify(v).slice(1,-1),Buffer.from(v).toString('base64'),Buffer.from(v).toString('base64url')]))].sort((a,b)=>b.length-a.length);
 const text=value=>secrets.reduce((s,v)=>s.split(v).join('[PRIVATE]'),value);
 const sanitize=value=>{
  if(typeof value==='string')return text(value);
  if(Array.isArray(value))return value.map(sanitize);
  if(value&&typeof value==='object'){
   if(['image','audio','resource_link'].includes(value.type)||value.type==='resource'&&value.resource?.blob)return{type:'text',text:'[Private media/resource withheld; reduced evidence only]'};
   return Object.fromEntries(Object.entries(value).map(([k,v])=>[text(k),sanitize(v)]));
  }
  return value;
 };
 const mcp=createMcpExtension({
  loadConfig:ctx=>{const runtime=resolvePlaywrightRuntime(rawRoot);return{servers:[{name:'ui-playwright-test',scope:'extension',source:import.meta.url,config:{command:process.execPath,args:[runtime.cli,'run-test-mcp-server','--headless','-c',runtime.config],cwd:rawRoot,exposure:'direct',timeout:45}}],errors:[]};},
  createTransport:entry=>{
   const pending=new Map();
   const safePath=(root,path)=>{if(isAbsolute(path)||relative(root,join(root,path)).startsWith('..'))throw Error('Private publication path rejected');let p=root;for(const part of path.split('/')){p=join(p,part);if(existsSync(p)&&lstatSync(p).isSymbolicLink())throw Error('Private publication symlink rejected');}return p;};
   const unchanged=()=>inputFiles.every(name=>readFileSync(join(workspace,name)).equals(readFileSync(join(rawRoot,name))));
   const inner=new StdioTransport({command:entry.config.command,args:entry.config.args,cwd:entry.config.cwd,stderr:'pipe'});
   return{
    start:()=>inner.start(),close:()=>inner.close(),
    send:async message=>{
     if(message.method==='tools/call'){
      if(message.params.name!=='browser_close'&&!unchanged())throw Error('Recording snapshot changed; no action dispatched');
      if(message.params.name==='generator_write_test'){
       const args=message.params.arguments;
       if(args.fileName!==outputFile||text(args.code)!==args.code)throw Error('Draft publication input rejected');
       const target=safePath(workspace,outputFile);if(existsSync(target))throw Error('Existing public draft preserved');
       safePath(rawRoot,outputFile);pending.set(message.id,{code:args.code});
      }
     }
     return inner.send(message.result?.roots?{...message,result:{...message.result,roots:[{uri:pathToFileURL(rawRoot).href,name:'private-recording'}]}}:message);
    },
    onMessage:listener=>inner.onMessage(message=>{appendFileSync(join(rawRoot,'protocol.ndjson'),JSON.stringify(message)+'\n',{mode:0o600});const draft=pending.get(message.id);pending.delete(message.id);
     if(draft&&message.result&&!message.result.isError){
      try{
       const source=safePath(rawRoot,outputFile),target=safePath(workspace,outputFile),bytes=readFileSync(source);
       if(!lstatSync(source).isFile()||bytes.toString()!==draft.code||text(bytes.toString())!==bytes.toString())throw Error('Draft bytes changed or contain private values');
       writeFileSync(target,bytes,{mode:0o600,flag:'wx'});
       message={...message,result:{...message.result,content:[...message.result.content,{type:'text',text:'Public draft copied byte-for-byte from native writer; sha256='+createHash('sha256').update(bytes).digest('hex')}]}};
      }catch{message={...message,result:{content:[{type:'text',text:'Private native draft retained; public publication blocked without overwrite'}],isError:true}};}
     }
     listener(sanitize(message));}),
    onError:listener=>inner.onError(error=>listener(new Error(text(error.message)))),
    onClose:listener=>inner.onClose(listener),
    get stderr(){return text(inner.stderr);}
   };
  }
 });
 return async pi=>{
  pi.on('tool_call',async(event,ctx)=>{if(event.toolName!=='mcp__ui_playwright_test__generator_setup_page')return;try{await validateRecordingSeed(ctx.cwd,event.input);}catch(error){return{block:true,reason:error.message};}});
  return mcp(pi);
 };
}
