from pathlib import Path
import hashlib,json,tarfile,io,os,shutil
repo=Path.cwd();root=repo/'tests/scratch/ui-recording-adapter';logs=repo/'tests/scratch/ui-optimization-u00'
sha=lambda b:hashlib.sha256(b).hexdigest()
names=['adapter-normal.log','adapter-cancel.log','adapter-renew.log','adapter-disconnect.log']
records={n:json.loads((logs/n).read_text()) for n in names}
late=records['adapter-disconnect.log'];normal=records['adapter-normal.log']
assert late['physicalCloseObserved'] and late['disconnectedSnapshotRejected'] and late['newConnectionInitialized'] and late['oldSnapshotRejectedBeforeNewConnectionBrowserDispatch']
assert normal['recordingStatus']=='complete' and normal['publicScriptEqualsNative'] and normal['finishGaps']==[]
for name,r in records.items():
 assert r['modelCalls']==r['formalRuns']==r['businessWrites']==0 and r['ownedRawOutputsRemoved']
 assert all(not t['containsSyntheticSecret'] and t['mediaBlocks']==0 for t in r['tools'])
 if name!='adapter-normal.log':
  assert not r['publicDraftExists'] and r['privateNativeDraftExists'] and r['recordingStatus']=='partial'
assert 'browser-cleanup-not-confirmed' in late['finishGaps']
verified=0
for d in root.iterdir():
 if not d.is_dir():continue
 (d/'.cleanup-keep').write_text('Retain physical disconnect evidence and harness preparation failures.\n')
 if (d/'seed.spec.ts').exists():
  (d/'tests').mkdir(exist_ok=True);(d/'tests/seed.spec.ts').write_bytes((d/'seed.spec.ts').read_bytes());(d/'package.json').write_bytes(b'{"type":"module"}')
 def walk(v):
  global verified
  if isinstance(v,dict):
   if isinstance(v.get('path'),str) and isinstance(v.get('sha256'),str):
    p=Path(v['path']);assert not p.is_absolute() and '..' not in p.parts
    assert sha((d/p).read_bytes())==v['sha256'],str(d/p);verified+=1
   for x in v.values():walk(x)
  elif isinstance(v,list):
   for x in v:walk(x)
 for p in (d/'qa').rglob('*.json'):walk(json.loads(p.read_text()))
 if (d/'seed.spec.ts').exists():walk(json.loads((d/'result.json').read_text()))
ledger_names=['u05-authorized-review-budget.json','pms-anonymous-authorized-review-budget.json']
ledgers={n:sha((logs/n).read_bytes()) for n in ledger_names}
assert ledgers==json.loads((repo/'docs/ui-testing-evidence/optimization-u02-recording-disconnect.json').read_text())['ledgerSha256']
text=(logs/'recording-adapter-document.md').read_text()
docdir=Path.home()/'Library/Application Support/Pi Agent Desktop/data/data-space/project-documents/e2f5d42d-2781-4e68-a452-4c87c7d1d346'
store=docdir.parent.parent/'store.json';before=store.read_bytes();snap=docdir/('recording-adapter-'+Path(late['output']).name);snap.mkdir(mode=0o700)
for name,r in records.items():shutil.copytree(Path(r['output']),snap/name)
persisted=[]
for p in snap.rglob('*'):
 assert not p.is_symlink()
 os.chmod(p,0o700 if p.is_dir() else 0o600)
 if p.is_file():
  n,*parts=p.relative_to(snap).parts;original=Path(records[n]['output'])/Path(*parts)
  assert p.read_bytes()==original.read_bytes();persisted.append({'path':str(p.relative_to(snap)),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size})
doc=docdir/'OperationContract-recording-adapter-2026-10-26.md'
with doc.open('x') as f:f.write(text)
os.chmod(doc,0o600);assert doc.read_text()==text and store.read_bytes()==before
files={}
for p in sorted(root.rglob('*')):
 if p.is_file():assert not p.is_symlink();files[str(p.relative_to(repo))]=p.read_bytes()
for n in [*names,'probe-recording-adapter.mjs','adapter-recording-prototype.mjs','recording-disconnect-control.mjs','archive-recording-adapter.py','adapter-unit.log','adapter-unit-v2.log','adapter-unit-v3.log','recording-adapter-document.md']:
 p=logs/n;files[str(p.relative_to(repo))]=p.read_bytes()
for n in ['.pi/skills/ui-testing-workflow/assets/private-recording-workspace.mjs','.pi/skills/ui-testing-workflow/assets/private-recording-transport.mjs','tests/unit/ui-private-recording-transport.test.ts']:files[n]=(repo/n).read_bytes()
archive=repo/'docs/ui-testing-evidence/optimization-u02-recording-adapter.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for n,b in sorted(files.items()):
  m=tarfile.TarInfo(n);m.size=len(b);m.mtime=0;t.addfile(m,io.BytesIO(b))
with tarfile.open(archive) as t:
 assert set(t.getnames())==set(files)
 for m in t:assert t.extractfile(m).read()==files[m.name]
index={'date':'2026-10-26','status':'INTERNAL_TRANSPORT_LIFECYCLE_ADAPTER_FOUR_REAL_SDK_MCP_CONTROLS_VERIFIED','plan_complete':False,'product_private_recording':'unsupported','modelCalls':0,'formalRuns':0,'businessWrites':0,'ledgerSha256':ledgers,'current_runs':records,'verification':{'vitest':'4 files 24 tests passed; new transport 8 tests','typecheck':'all five configs passed'},'historical_unit_failure':'Initial 6 tests blocked by invalid synthetic empty origins fixture; initial log retained, exact initial test source not saved','refsVerified':verified,'document':{'path':str(doc),'sha256':sha(doc.read_bytes()),'storeUnchanged':True},'snapshot':{'path':str(snap),'files':persisted},'limits':['New connection only initialized/listed tools; no original-session recording recovery','Normal control is an independent new workspace/identity/session','Native browser-cleanup-not-confirmed gap retained','No product/Electron/private record enablement; generic privacy and filesystem races unproven','Raw synthetic payloads removed; public logs reduced'],'archive':{'path':str(archive.relative_to(repo)),'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'files':len(files),'roundtrip_verified':True},'files':[{'path':n,'sha256':sha(b),'bytes':len(b)} for n,b in sorted(files.items())]}
(repo/'docs/ui-testing-evidence/optimization-u02-recording-adapter.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'files':len(files),'refs':verified,'snapshotFiles':len(persisted),'archiveBytes':archive.stat().st_size}))
