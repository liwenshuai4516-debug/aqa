import json,hashlib,tarfile,io
from pathlib import Path
repo=Path.cwd();root=repo/'tests/scratch/ui-browser-candidate/1792809587795';output=repo/'tests/scratch/ui-approved-baseline/1792923589674';files={};refs={};sha=lambda b:hashlib.sha256(b).hexdigest()
def add(p):
 p=Path(p);assert not p.is_symlink();n=str(p.relative_to(repo));assert not any(v in n.split('/') for v in ['ui-review-authority','private-authority','auth.json','model-cache.json','node_modules']);files[n]=p.read_bytes()
def tree(p):
 for f in p.rglob('*'):
  if f.is_file():add(f)
def verify(ref):
 assert sha((root/ref['path']).read_bytes())==ref['sha256'],ref['path'];refs[ref['path']]=ref['sha256']
priors={}
for name in ['optimization-u05-approved-run','optimization-u00-approved-baseline','optimization-u00-child-observer']:
 p=repo/f'docs/ui-testing-evidence/{name}.json';prior=json.loads(p.read_text());assert sha((repo/prior['archive']['path']).read_bytes())==prior['archive']['sha256'];add(p);priors[name]=prior['archive']
ledger='tests/scratch/ui-optimization-u00/u05-authorized-review-budget.json';p=json.loads((repo/'docs/ui-testing-evidence/optimization-u05-approved-run.json').read_text());assert sha((repo/ledger).read_bytes())==next(f['sha256'] for f in p['files'] if f['path']==ledger)
r=json.loads((output/'result.json').read_text());assert r['status']=='PASS';assert r['results']['data']['counts']['passed']==6;assert r['results']['details']['assertion_reached_attempt_count']==13;assert r['nestedBrowserStarts']==1
assert sha((repo/'tests/ui-approved-baseline-measure.mjs').read_bytes())==r['plan']['harness_sha256'];assert sha((repo/'tests/lib/ui-baseline-child-observer.mjs').read_bytes())==r['plan']['child_observer']['sha256']
records=[r['hostPlaywrightApi']]+[p['playwright_api'] for p in r['childProcesses']]
for record in records:
 assert record['version']=='1.62.1'
 for value in record['calls'].values():assert value['started']==value['completed'] and value['failed']==0
host=records[0]['calls'];nested={}
for record in records[1:]:
 for k,v in record['calls'].items():
  target=nested.setdefault(k,{'started':0,'completed':0,'failed':0})
  for field in target:target[field]+=v[field]
assert host['Frame.goto']['started']==1 and nested['Frame.goto']['started']==7 and nested['Page.reload']['started']==3
assert sum(record['calls'].get('Frame.ariaSnapshot',{}).get('started',0) for record in records)==0
for ref in r['immutable_refs']+[r['execution']['run_ref'],r['results']['results_ref'],r['task']['task_ref']]+r['execution']['run']['data']['output_refs']:verify(ref)
tree(root/Path(r['execution']['run_ref']['path']).parent);tree(output);add(root/r['task']['task_ref']['path'])
calibration=repo/'tests/scratch/ui-api-observer-calibration/1792923551208';c=json.loads((calibration/'result.json').read_text());assert c['status']=='PASS';assert not any(s in json.dumps(c['processes']) for s in ['Owned','Missing','data:text']);assert sum(p['playwright_api']['calls'].get('Frame.ariaSnapshot',{}).get('started',0) for p in c['processes'])==1;tree(calibration)
for name in ['tests/ui-approved-baseline-measure.mjs','tests/lib/ui-baseline-child-observer.mjs','tests/scratch/ui-optimization-u00/u00-api-observer-calibration.mjs','tests/scratch/ui-optimization-u00/archive-u00-api-observer.py']:add(repo/name)
for p in (repo/'tests/scratch/ui-optimization-u00').glob('u00-api-observer-*.log'):add(p)
archive=repo/'docs/ui-testing-evidence/optimization-u00-api-observer.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for n,b in sorted(files.items()):
  m=tarfile.TarInfo(n);m.size=len(b);m.mtime=0;t.addfile(m,io.BytesIO(b))
with tarfile.open(archive) as t:
 assert set(t.getnames())==set(files)
 for m in t:assert t.extractfile(m).read()==files[m.name]
index={'date':'2026-10-25','status':'EXTERNAL_PLAYWRIGHT_APIS_MEASURED_COMPLETE_BASELINE_PENDING','plan_complete':False,'model_calls':0,'fee_ledger_unchanged':True,'plan':r['plan'],'formal_run_ref':r['execution']['run_ref'],'counts':r['results']['data']['counts'],'assertions_reached':13,'host_api':r['hostPlaywrightApi'],'nested_api':{'version':'1.62.1','calls':nested},'explicit_snapshot_api_calls':0,'navigation_api_calls':11,'browser_starts':{'host_preflight':1,'nested_worker':1},'node_processes':r['childProcesses'],'calibration':c['checks'],'prior_archives_verified':priors,'public_refs_verified':refs,'limits':['Version-pinned private Playwright Test listener, not a public supported API','External channel API calls only; no browser auto-redirect/subframe/internal trace snapshots claim','No parameters, URLs, titles, errors, stack traces or page contents in API counters','Preloading observer/Playwright changes startup and I/O overhead; no speed claim','52 Frame.expect calls are not 52 business assertions; frozen business assertion IDs remain 13','Fresh first-generation and old-failed-batch full baselines, full paired comparison and real desktop/business acceptance remain pending','Benchmark task retains analyze blocker; no new independently approved report delivery'],'validation':{'typecheck':'passed','vitest':'51 passed in 3 files','lint':'passed','protocol':'structure passed; no-tag history skip','desktop':'not rerun; test-observer-only change','size':'passed','clean':'preview only; no deletion'},'archive':{'path':str(archive.relative_to(repo)),'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'files':len(files),'roundtrip_verified':True},'files':[{'path':n,'sha256':sha(b),'bytes':len(b)} for n,b in sorted(files.items())]}
(repo/'docs/ui-testing-evidence/optimization-u00-api-observer.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'files':len(files),'refs':len(refs),'bytes':archive.stat().st_size}))
