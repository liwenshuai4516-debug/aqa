# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: qa/ui/assets/pms-anonymous-redirect/revisions/v2/candidate.spec.ts >> anonymous OperationContract redirect baseline
- Location: qa/ui/assets/pms-anonymous-redirect/revisions/v2/candidate.spec.ts:3:1

# Error details

```
Error: expect(page).toHaveURL(expected) failed

Expected: predicate to succeed
Received: "http://192.168.90.224:8238/pms/OperationContract"
Timeout:  3000ms

```

# Page snapshot

```yaml
- generic [ref=f1e5]:
  - img [ref=f1e6]:
    - generic [ref=f1e7]: 基础平台
  - generic [ref=f1e15]: 密码认证
  - generic [ref=f1e16]: 请用账号密码登录
  - generic [ref=f1e18]:
    - textbox "请输入用户名" [ref=f1e27]
    - textbox "请输入密码" [ref=f1e36]
    - generic [ref=f1e37]: 记住密码
    - button "登 录" [ref=f1e42] [cursor=pointer]
```

# Test source

```ts
  1  | import {test,expect} from '@playwright/test';
  2  | test.use({storageState:{cookies:[],origins:[]},serviceWorkers:'block',acceptDownloads:false});
  3  | test('anonymous OperationContract redirect baseline',async({page,context,baseURL})=>{
  4  |  if(!baseURL)throw new Error('Missing scoped baseURL');
  5  |  const origin=new URL(baseURL).origin;
  6  |  await context.route('**/*',route=>new URL(route.request().url()).origin===origin&&['GET','HEAD'].includes(route.request().method())?route.continue():route.abort('blockedbyclient'));
  7  |  await page.goto('/pms/OperationContract');
  8  |  await test.step('A-anonymous-redirect protected route resolves to scoped login baseline',async()=>{
> 9  |   await expect(page).toHaveURL(url=>url.origin===origin&&url.pathname==='/login');
     |                      ^ Error: expect(page).toHaveURL(expected) failed
  10 |  });
  11 | });
  12 | 
```