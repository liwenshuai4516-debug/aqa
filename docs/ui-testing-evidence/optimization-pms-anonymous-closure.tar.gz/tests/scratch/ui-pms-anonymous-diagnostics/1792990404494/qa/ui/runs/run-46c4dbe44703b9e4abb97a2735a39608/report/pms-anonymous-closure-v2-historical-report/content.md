# UI 测试结果

范围：Record anonymous navigation from OperationContract to login route, without credentials or form submission

批次：run-46c4dbe44703b9e4abb97a2735a39608；部署：app-sha256-2888c0b0da892a1802d954396c626c063a413416cd63407f9a9072adac222d37；角色：anonymous

冻结计划：1；实际启动：1；稳定通过率：0.00%

| 状态 | 实例数 |
|---|---:|
| passed | 0 |
| failed | 1 |
| blocked | 0 |
| skipped | 0 |
| cancelled | 0 |
| not-run | 0 |
| flaky | 0 |
| unknown | 0 |

原始结果：[qa/ui/runs/run-46c4dbe44703b9e4abb97a2735a39608/report.json](../../report.json)

确定性对账与证据状态：[qa/ui/runs/run-46c4dbe44703b9e4abb97a2735a39608/results/pms-anonymous-closure-v2-historical-results/reconciliation.json](../../results/pms-anonymous-closure-v2-historical-results/reconciliation.json)

设计评估（仅本批次资产修订）：候选用例 1；通过 1；待修订 0；阻塞 0；结论 approved。

已登记功能清单：1；清单内尚无用例的功能点：无。

未探索范围（不计入上述清单分母）：Authenticated contract features, login submission, permissions and test data。

功能覆盖：冻结用例涉及 1 个功能点，其中 1 个获得执行结论；不代表全产品覆盖。

## 模块、功能与优先级统计

```json
{
  "by_module": {
    "pms-access": {
      "passed": 0,
      "failed": 1,
      "blocked": 0,
      "skipped": 0,
      "cancelled": 0,
      "not-run": 0,
      "flaky": 0,
      "unknown": 0
    }
  },
  "by_feature": {
    "pms-access/anonymous-redirect": {
      "passed": 0,
      "failed": 1,
      "blocked": 0,
      "skipped": 0,
      "cancelled": 0,
      "not-run": 0,
      "flaky": 0,
      "unknown": 0
    }
  },
  "by_priority": {
    "P0": {
      "passed": 0,
      "failed": 1,
      "blocked": 0,
      "skipped": 0,
      "cancelled": 0,
      "not-run": 0,
      "flaky": 0,
      "unknown": 0
    }
  },
  "by_oracle": {
    "requirement": [],
    "declaration": [],
    "baseline": [
      "instance-1450fdaa985d888f2bb4cb71a42b71ef"
    ]
  }
}
```

## 观察、解释与下一动作

### instance-1450fdaa985d888f2bb4cb71a42b71ef（insufficient-evidence / unknown）

- 观察事实：Frozen plan contains one anonymous redirect baseline instance. It started and reached A-anonymous-redirect; the assertion failed with configured timeout 3000ms and a received URL of http://192.168.90.224:8238/pms/OperationContract instead of the scoped /login pathname. Native reconciliation is complete: 0 passed, 1 failed, no retries.
- 观察事实：The failure error-context snapshot shows login controls (密码认证, username/password fields and 登 录 button). The error message records the protected pathname; these observations need not be simultaneous. Login content visibility is outside this candidate and does not satisfy its URL baseline.
- 观察事实：Native trace test.trace records expect@63 from 2173.834 to 2231.783 (about 57.949ms) and pw:api@64 error frame.waitForURL: net::ERR_ABORTED; maybe frame was detached?. Thus 3000ms is the configured limit, not demonstrated elapsed wait. The original native trace was read through ui_result_analysis read-trace and belongs to this failed instance/attempt.
- 候选解释：Navigation interruption is observed during the URL wait. Runtime routing, redirect or timing variation relative to the recorded anonymous baseline remains a possible explanation; the trigger and product/server cause are not established.
- 替代解释/缺口：Deployment/request/session differences or baseline timing assumptions may explain the discrepancy; no application source, server or database cause has been confirmed.
- 下一验证动作：Preserve this historical failed batch and approved v2 script unchanged. If an independently verifiable prior diagnostic is available, compare its route events with this original trace; otherwise gather separately identified evidence. Do not infer a server root cause or replace this failed result with another batch.
- 证据：[qa/ui/runs/run-46c4dbe44703b9e4abb97a2735a39608/output/qa-ui-assets-pms-anonymous-823dc-nContract-redirect-baseline-chromium/trace.zip](../../output/qa-ui-assets-pms-anonymous-823dc-nContract-redirect-baseline-chromium/trace.zip)
- 证据：[qa/ui/runs/run-46c4dbe44703b9e4abb97a2735a39608/report.json](../../report.json)
- 证据：[qa/ui/runs/run-46c4dbe44703b9e4abb97a2735a39608/output/qa-ui-assets-pms-anonymous-823dc-nContract-redirect-baseline-chromium/error-context.md](../../output/qa-ui-assets-pms-anonymous-823dc-nContract-redirect-baseline-chromium/error-context.md)

## 数据清理与残留

```json
[
  {
    "instance_id": "instance-1450fdaa985d888f2bb4cb71a42b71ef",
    "cleanup": [],
    "evidence_gaps": []
  }
]
```

## 限制与待处理事项

- 范围仅限冻结计划，不代表全产品或代码覆盖率；attempt 与 case 分开统计
- 候选与设计评估数量仅统计本批次资产修订；不推断其他候选或历史轮次。未登记的信息为不可用，不填零
- 未探索：Authenticated contract features, login submission, permissions and test data
- 冻结用例声明（历史记录，非当前状态）：Unreviewed v2; frozen diagnostic inputs prepared; candidate replay and diagnostic not performed
- 冻结资产声明（历史记录，非当前状态）：Independent design review pending; environment preflight is not a diagnostic or formal run
- instance-1450fdaa985d888f2bb4cb71a42b71ef：原因仍未知，未假定已修复或已提交缺陷

失败处理：产品问题仅形成待确认缺陷草稿；脚本问题新建修订并重审；环境/数据恢复后新批次执行；证据不足先补证据，不修改历史结果。

后续处理草稿：[缺陷与回归建议](follow-up.json)；未向外部系统提交。
