import {test,expect} from '@playwright/test';
test.use({storageState:{cookies:[],origins:[]},serviceWorkers:'block',acceptDownloads:false});
test('anonymous OperationContract redirect baseline',async({page,context,baseURL})=>{
 if(!baseURL)throw new Error('Missing scoped baseURL');
 const origin=new URL(baseURL).origin;
 await context.route('**/*',route=>new URL(route.request().url()).origin===origin&&['GET','HEAD'].includes(route.request().method())?route.continue():route.abort('blockedbyclient'));
 await page.goto('/pms/OperationContract');
 await test.step('A-anonymous-redirect protected route resolves to scoped login baseline',async()=>{
  await expect(page).toHaveURL(url=>url.origin===origin&&url.pathname==='/login');
 });
});
