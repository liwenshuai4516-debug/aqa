/** Isolated wrong-result copy: intentionally omit the protected-route redirect. No real PMS data. */
import {createServer} from 'node:http';
const html="<!doctype html><html lang=\"zh\"><meta charset=\"utf-8\"><title>Anonymous diagnostic copy</title><p>密码认证</p><p>请用账号密码登录</p><button>登 录</button></html>";
const server=createServer((req,res)=>{if(!['GET','HEAD'].includes(req.method)){res.writeHead(405);return res.end();}res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'});res.end(req.method==='HEAD'?'':html);});
server.listen(18982,'127.0.0.1');
for(const signal of ['SIGINT','SIGTERM'])process.on(signal,()=>server.close(()=>process.exit(0)));
