# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: qa/ui/assets/pms-anonymous-redirect/revisions/v3/candidate.spec.ts >> anonymous OperationContract redirect baseline
- Location: qa/ui/assets/pms-anonymous-redirect/revisions/v3/candidate.spec.ts:3:1

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 1

  Object {
    "origin": "http://127.0.0.1:18982",
-   "pathname": "/login",
+   "pathname": "/pms/OperationContract",
  }

Call Log:
- Timeout 3000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - paragraph [ref=e2]: 密码认证
  - paragraph [ref=e3]: 请用账号密码登录
  - button "登 录" [ref=e4]
```

# Test source

```ts
  1  | import {test,expect} from '@playwright/test';
  2  | test.use({storageState:{cookies:[],origins:[]},serviceWorkers:'block',acceptDownloads:false,trace:'on'});
  3  | test('anonymous OperationContract redirect baseline',async({page,context,baseURL})=>{
  4  |  if(!baseURL)throw new Error('Missing scoped baseURL');
  5  |  const origin=new URL(baseURL).origin;
  6  |  await context.route('**/*',route=>new URL(route.request().url()).origin===origin&&['GET','HEAD'].includes(route.request().method())?route.continue():route.abort('blockedbyclient'));
  7  |  await page.goto('/pms/OperationContract');
  8  |  await test.step('A-anonymous-redirect protected route resolves to scoped login baseline',async()=>{
> 9  |   await expect.poll(()=>{const url=new URL(page.url());return {origin:url.origin,pathname:url.pathname};},{timeout:3000}).toEqual({origin,pathname:'/login'});
     |                                                                                                                           ^ Error: expect(received).toEqual(expected) // deep equality
  10 |  });
  11 | });
  12 | 
```