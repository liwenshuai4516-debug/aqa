import {test,expect} from '@playwright/test';
test('anonymous OperationContract redirect baseline',async({page,context})=>{
 expect(await context.cookies()).toEqual([]);
 await context.route('**/*',r=>new URL(r.request().url()).origin===new URL(test.info().project.use.baseURL).origin&&['GET','HEAD'].includes(r.request().method())?r.continue():r.abort('blockedbyclient'));
 await page.goto('/pms/OperationContract');
 await expect(page).toHaveURL(/\/login(?:[/?#]|$)/);
 expect(await page.evaluate(()=>localStorage.getItem('token'))).toBeNull();
});
