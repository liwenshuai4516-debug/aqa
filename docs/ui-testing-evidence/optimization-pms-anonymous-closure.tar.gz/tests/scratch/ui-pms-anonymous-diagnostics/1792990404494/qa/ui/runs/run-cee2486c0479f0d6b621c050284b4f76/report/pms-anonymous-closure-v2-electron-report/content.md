# UI 测试结果

范围：Record anonymous navigation from OperationContract to login route, without credentials or form submission

批次：run-cee2486c0479f0d6b621c050284b4f76；部署：app-sha256-2888c0b0da892a1802d954396c626c063a413416cd63407f9a9072adac222d37；角色：anonymous

冻结计划：1；实际启动：1；稳定通过率：100.00%

| 状态 | 实例数 |
|---|---:|
| passed | 1 |
| failed | 0 |
| blocked | 0 |
| skipped | 0 |
| cancelled | 0 |
| not-run | 0 |
| flaky | 0 |
| unknown | 0 |

原始结果：[qa/ui/runs/run-cee2486c0479f0d6b621c050284b4f76/report.json](../../report.json)

确定性对账与证据状态：[qa/ui/runs/run-cee2486c0479f0d6b621c050284b4f76/results/pms-anonymous-closure-v2-electron-results/reconciliation.json](../../results/pms-anonymous-closure-v2-electron-results/reconciliation.json)

设计评估（仅本批次资产修订）：候选用例 1；通过 1；待修订 0；阻塞 0；结论 approved。

已登记功能清单：1；清单内尚无用例的功能点：无。

未探索范围（不计入上述清单分母）：Authenticated contract features, login submission, permissions and test data。

功能覆盖：冻结用例涉及 1 个功能点，其中 1 个获得执行结论；不代表全产品覆盖。

## 模块、功能与优先级统计

```json
{
  "by_module": {
    "pms-access": {
      "passed": 1,
      "failed": 0,
      "blocked": 0,
      "skipped": 0,
      "cancelled": 0,
      "not-run": 0,
      "flaky": 0,
      "unknown": 0
    }
  },
  "by_feature": {
    "pms-access/anonymous-redirect": {
      "passed": 1,
      "failed": 0,
      "blocked": 0,
      "skipped": 0,
      "cancelled": 0,
      "not-run": 0,
      "flaky": 0,
      "unknown": 0
    }
  },
  "by_priority": {
    "P0": {
      "passed": 1,
      "failed": 0,
      "blocked": 0,
      "skipped": 0,
      "cancelled": 0,
      "not-run": 0,
      "flaky": 0,
      "unknown": 0
    }
  },
  "by_oracle": {
    "requirement": [],
    "declaration": [],
    "baseline": [
      "instance-1450fdaa985d888f2bb4cb71a42b71ef"
    ]
  }
}
```

## 观察、解释与下一动作

## 数据清理与残留

```json
[
  {
    "instance_id": "instance-1450fdaa985d888f2bb4cb71a42b71ef",
    "cleanup": [],
    "evidence_gaps": []
  }
]
```

## 限制与待处理事项

- 范围仅限冻结计划，不代表全产品或代码覆盖率；attempt 与 case 分开统计
- 候选与设计评估数量仅统计本批次资产修订；不推断其他候选或历史轮次。未登记的信息为不可用，不填零
- 未探索：Authenticated contract features, login submission, permissions and test data
- 冻结用例声明（历史记录，非当前状态）：v3 independent design review pending
- 冻结资产声明（历史记录，非当前状态）：v3 independent review and current diagnostics pending

失败处理：产品问题仅形成待确认缺陷草稿；脚本问题新建修订并重审；环境/数据恢复后新批次执行；证据不足先补证据，不修改历史结果。

后续处理草稿：[缺陷与回归建议](follow-up.json)；未向外部系统提交。
