import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {ArtifactStore,validateArtifact,verifyReferences,ResultReviewService,checkReport} from 'pi-ui-testing';
const packet=JSON.parse(await readFile(new URL('review-packet-v2.json',import.meta.url),'utf8')),root=packet.root,store=new ArtifactStore(root);
const service=new ResultReviewService(root,join(root,'ui-review-authority'));
const delivery=JSON.parse(await readFile(new URL('electron-delivery-1793088780075/result.json',import.meta.url),'utf8'));
let artifacts=0;
for(let index=0;index<packet.reports.length;index++){
 const p=packet.reports[index],d=delivery.deliveries[index];assert.deepEqual(p.report_ref,d.report_ref);
 for(const ref of [p.report_ref,p.results_ref,p.analysis_ref,p.run_ref,d.review_ref,d.task_ref]){
  const artifact=await store.load(ref);validateArtifact(artifact);artifacts++;
 }
 assert.deepEqual((await checkReport(root,p.report_ref)).check.issues,[]);
 await service.gate(p.report_ref,d.review_ref);await verifyReferences(root,d.delivery_ref);
 assert.equal((await store.load(d.task_ref)).data.state,'completed');
}
const receipt={status:'HANDOFF_VALIDATED',artifacts_checked:artifacts,report_static_checks:2,trusted_result_approvals:2,complete_deliveries:2,completed_tasks:2,models_called:0,browsers_started:0};
await writeFile(new URL('handoff-check.json',import.meta.url),JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify(receipt));
