import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {ArtifactStore,collectResults,saveAnalysis,draftReport,checkReport} from 'pi-ui-testing';
const previous=JSON.parse(await readFile(new URL('review-packet.json',import.meta.url),'utf8')),root=previous.root,store=new ArtifactStore(root),reports=[];
for(let index=0;index<previous.reports.length;index++){
 const original=previous.reports[index],oldReport=await store.load(original.report_ref),oldAnalysis=await store.load(oldReport.data.analysis_ref);
 const id='pms-anonymous-closure-v2-'+(index===0?'historical':'electron');
 const parsed=await collectResults(root,original.run_ref,id+'-results');
 assert.deepEqual(parsed.data.counts,index===0?previous.oldCounts:previous.newCounts);
 assert.equal(parsed.details.coverage.gap_basis,'frozen-input-declarations-not-current-status');
 oldAnalysis.id=id+'-analysis';oldAnalysis.created_at=new Date().toISOString();oldAnalysis.data.results_ref=parsed.results_ref;
 if(index===0){
  const finding=oldAnalysis.data.findings[0];
  finding.facts=finding.facts.map(f=>f.replace(' The preceding positive design diagnostic and this formal attempt are distinct records; a prior diagnostic pass cannot replace this failure.',''));
  finding.next_action='Preserve this historical failed batch and approved v2 script unchanged. If an independently verifiable prior diagnostic is available, compare its route events with this original trace; otherwise gather separately identified evidence. Do not infer a server root cause or replace this failed result with another batch.';
 }
 const saved=await saveAnalysis(root,oldAnalysis),report=await draftReport(root,parsed.results_ref,saved.analysis_ref,id+'-report');
 const check=await checkReport(root,report.report_ref);assert.deepEqual(check.check.issues,[]);
 reports.push({name:original.name,report_ref:report.report_ref,run_ref:original.run_ref,results_ref:parsed.results_ref,analysis_ref:saved.analysis_ref,content_ref:check.report.data.content_ref,completeness:check.report.data.completeness,static_issues:check.check.issues,previous_report_ref:original.report_ref});
}
const packet={...previous,status:'REVISED_REPORTS_FROZEN_AFTER_R4_R5_FEEDBACK',reports,corrections:['Historical diagnostic-pass statements removed; conditional next action retained','Native 0.1.21 reconciliation and report distinguish frozen input declarations from current design/execution facts; raw input gaps unchanged'],retained_review_ref:JSON.parse(await readFile(new URL('pms-anonymous-result-review-1.json',import.meta.url),'utf8')).response.output.review_ref};
await writeFile(new URL('review-packet-v2.json',import.meta.url),JSON.stringify(packet,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(packet.reports,null,2));
