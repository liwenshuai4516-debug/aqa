/** Explicit human-authorized PMS anonymous design loop. Native reviewer owns approval. */
import assert from 'node:assert/strict';
import {readFile,writeFile,readdir} from 'node:fs/promises';
import {writeFileSync,existsSync} from 'node:fs';
import {join,dirname,resolve} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {McpClient,StdioTransport} from '@earendil-works/pi-mcp';
import {resolvePlaywrightRuntime} from '../../../.pi/skills/ui-testing-workflow/assets/playwright-runtime.mjs';
import {ModelRuntime} from '@earendil-works/pi-coding-agent';
import {ArtifactStore,UiWorkflowService,capabilities} from 'pi-ui-testing';
const ledgerPath=new URL('../ui-optimization-u00/pms-anonymous-authorized-review-budget.json',import.meta.url);
const ledger=JSON.parse(await readFile(ledgerPath,'utf8')),root=resolve(ledger.candidate_directory),store=new ArtifactStore(root);
assert.equal(ledger.authorization_id,'pms-anonymous-design-2026-10-26');
assert.ok(ledger.native_attempts.length<ledger.max_calls);
assert.ok(!ledger.native_attempts.some(a=>a.status==='started')&&!ledger.attempts.some(a=>a.status==='started'),'Unknown prior outcome; do not replay');
const number=ledger.native_attempts.length+1,request_id='pms-anonymous-design-'+number,file=join(root,request_id+'.json');assert.ok(!existsSync(file));
const save=()=>writeFileSync(ledgerPath,JSON.stringify(ledger,null,2)+'\n');
const installed=dirname(fileURLToPath(import.meta.resolve('pi-ui-testing'))),tools=new Map();
const {registerDesignTools}=await import(pathToFileURL(join(installed,'design-extension.js')).href);registerDesignTools({registerTool:t=>tools.set(t.name,t)});
const asset=await store.load(ledger.asset_ref);assert.equal(asset.data.revision,'v3');
const playwright=resolvePlaywrightRuntime(root),client=new McpClient({name:'pms-review-capability-check',version:'1.0',roots:[{uri:pathToFileURL(root).href,name:'pms-review'}]});
await client.connect(new StdioTransport({command:process.execPath,args:[playwright.cli,'run-test-mcp-server','--headless','-c',playwright.config],cwd:root,stderr:'pipe'}));
try {
const verifiedTools=await client.listTools();
await writeFile(join(root,'review-mcp-tools.json'),JSON.stringify({operation:'listTools',browserCalls:0,names:verifiedTools.map(t=>t.name)},null,2)+'\n');
const workflow=new UiWorkflowService(root,join(root,'ui-review-authority'),{tools:['read',...capabilities.map(c=>c.tool),...verifiedTools.map(t=>'mcp__ui_playwright_test__'+t.name)],skills:await readdir(join(installed,'../skills'))});
if(!ledger.task_ref){
 let task=await workflow.start({task_id:ledger.revision_task_id,mode:'record',discovery:'both',scope_ref:asset.data.scope_ref});
 task=await workflow.resumeTask(task.task_ref);
 if(task.task.data.stage==='discover-record')task=await workflow.checkpoint(task.task_ref,'discover-record',[asset.data.inventory_ref,...asset.data.recording_refs]);
 if(task.task.data.stage==='case-design')task=await workflow.checkpoint(task.task_ref,'case-design',[ledger.asset_ref]);
 ledger.task_ref=task.task_ref;save();
}
const state=await workflow.status(ledger.task_ref);assert.equal(state.task.data.stage,'design-review');
const check=await tools.get('ui_case_design').execute('pms-review-static-'+number,{request:{operation:'check',asset_ref:ledger.asset_ref}},new AbortController().signal,undefined,{cwd:root});
const checked=JSON.parse(check.content.find(c=>c.type==='text').text);assert.equal(checked.status,'completed');assert.equal(checked.output.ready_for_review,true);
const runtime=await ModelRuntime.create({modelsStorePath:join(root,'model-cache.json'),refreshOnCreate:false});
const model=(await runtime.getAvailable()).find(m=>m.provider===ledger.authorized_provider&&m.id===ledger.authorized_model);assert.ok(model,'Authorized configured model unavailable');
const pending=[],native={request_id,status:'started',asset_ref:ledger.asset_ref,started_at:new Date().toISOString()};
ledger.native_attempts.push(native);save();
const registry={streamSimple(m,context,options){
 assert.equal(m.provider,ledger.authorized_provider);assert.equal(m.id,ledger.authorized_model);assert.deepEqual(context.tools??[],[]);
 assert.ok(ledger.attempts.length<ledger.max_calls);
 const input_bytes=Buffer.byteLength(JSON.stringify(context));assert.ok(input_bytes<=ledger.max_input_bytes);
 const reserved_usd=(input_bytes+ledger.max_output_tokens)*ledger.price_upper_bound_usd_per_million/1e6;
 assert.ok(ledger.attempts.reduce((n,a)=>n+a.reserved_usd,0)+reserved_usd<=ledger.max_cost_usd);
 const attempt={number:ledger.attempts.length+1,request_id,status:'started',input_bytes,reserved_usd,max_output_tokens:ledger.max_output_tokens,provider:m.provider,model:m.id,started_at:new Date().toISOString()};ledger.attempts.push(attempt);save();
 const stream=runtime.streamSimple(m,context,{...options,maxTokens:ledger.max_output_tokens});
 pending.push(stream.result().then(message=>{attempt.status=message.stopReason;attempt.usage=message.usage;attempt.duration_ms=message.durationMs;attempt.finished_at=new Date().toISOString();if(message.errorMessage){attempt.error_status=message.errorMessage.match(/\b[45]\d\d\b/)?.[0]??null;attempt.error_category=/quota|balance|credit/i.test(message.errorMessage)?'quota':'provider-or-runtime-error';}save();},()=>{attempt.status='error';attempt.finished_at=new Date().toISOString();save();}));return stream;
}};
let outcome;
try{
 const response=await tools.get('ui_design_review').execute(request_id,{task_ref:ledger.task_ref,asset_ref:ledger.asset_ref,request_id},new AbortController().signal,undefined,{cwd:root,model,modelRegistry:registry,sessionManager:{getSessionDir:()=>root}});
 await Promise.all(pending);const body=JSON.parse(response.content.filter(c=>c.type==='text').map(c=>c.text).join('\n'));
 native.status=body.status;native.finished_at=new Date().toISOString();save();outcome={request_id,asset_ref:ledger.asset_ref,task_ref:ledger.task_ref,response:body,formalRuns:0,browserCalls:0,authorized_model:ledger.authorized_provider+'/'+ledger.authorized_model,callsUsed:ledger.attempts.length,reservedUsd:ledger.attempts.reduce((n,a)=>n+a.reserved_usd,0)};
 await writeFile(file,JSON.stringify(outcome,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(outcome,null,2));
}catch(error){await Promise.allSettled(pending);native.status='host-error';native.finished_at=new Date().toISOString();save();await writeFile(file,JSON.stringify({request_id,status:'host-error',error:error.message},null,2)+'\n',{flag:'wx'});throw error;}

} finally {await client.close();}
