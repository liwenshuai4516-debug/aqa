// Deterministic local dispatch through the actual Electron SDK. Not a model-planning test.
import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {once} from 'node:events';
import {readFile,writeFile,mkdir,mkdtemp,cp,readdir} from 'node:fs/promises';
import {resolve,join} from 'node:path';
import {tmpdir} from 'node:os';
import electron from 'electron';
import {ArtifactStore,sha256,recoveryPlan} from 'pi-ui-testing';
import {enableUiTesting} from '../../../scripts/enable-ui-testing.mjs';
import {launchNativeApp} from '../../desktop/native-app.mjs';
import {ensureBuild} from '../../lib/ensure-build.mjs';
import {portUp} from '../../lib/port-utils.mjs';
assert.equal(process.env.PI_WEB_SMOKE_PREBUILT,'1');ensureBuild(process.cwd(),'pms-anonymous-electron');
const root=resolve('tests/scratch/ui-pms-anonymous-diagnostics/1792990404494'),store=new ArtifactStore(root);
const output=resolve('tests/scratch/ui-pms-anonymous-closure/electron-'+Date.now());await mkdir(output,{recursive:true});
await cp(new URL(import.meta.url),join(output,'harness.mjs'));
const privateRoot=await mkdtemp(join(tmpdir(),'pms-anonymous-desktop-')),agentDir=join(privateRoot,'agent'),dataDir=join(privateRoot,'data');
await mkdir(agentDir,{recursive:true,mode:0o700});await mkdir(dataDir,{recursive:true,mode:0o700});
const ledger=JSON.parse(await readFile('tests/scratch/ui-optimization-u00/pms-anonymous-authorized-review-budget.json','utf8'));
const approved=JSON.parse(await readFile(join(root,'pms-anonymous-design-2.json'),'utf8'));assert.equal(approved.response.output.decision,'approved');
const spec=JSON.parse(await readFile(join(root,ledger.diagnostic_spec_ref.path),'utf8'));
const old=JSON.parse(await readFile(join(root,'pms-anonymous-formal-1.json'),'utf8'));
const recovery=await recoveryPlan(root,old.execution.run_ref,'rerun-failed');assert.deepEqual(recovery.blockers,[]);
await writeFile(join(output,'parent-recovery-plan.json'),JSON.stringify(recovery,null,2));
const result={status:'blocked',workspace:root,privateRoot,output,modelCalls:0,formalRuns:0,businessWrites:0,controlProviderCalls:0,stages:[],parentRunRef:old.execution.run_ref,assetRef:ledger.asset_ref,reviewRef:approved.response.output.review_ref,limitations:['Local dispatch verifies actual Electron/SDK tool integration, not autonomous model planning','New revision uses a new full execution task; not a same-revision recovery or replacement of historical failure','Anonymous URL baseline only; no case-library import']};
let app,page,provider,pending,sequence=0;
const until=async(check,label,timeout=90000)=>{const end=Date.now()+timeout;while(Date.now()<end){if(await check())return;await new Promise(ok=>setTimeout(ok,150))}throw Error('Timed out: '+label)};
async function native(tool,request){
 const id=++sequence;pending={tool,args:{request},id,sent:false};
 await page.locator('.inputbox textarea').fill('执行已冻结的匿名只读检查 '+id+'，保留原生门禁与证据。');
 await page.locator('.inputbox textarea').press('Enter');
 await until(()=>page.locator('.messages').getByText('ANON_DONE_'+id,{exact:true}).count(),tool);
 let reply=pending.reply;
 if(!reply){
  for(const dir of await readdir(join(agentDir,'sessions'),{withFileTypes:true}))if(dir.isDirectory())for(const file of await readdir(join(agentDir,'sessions',dir.name)))if(file.endsWith('.jsonl')){
   for(const line of (await readFile(join(agentDir,'sessions',dir.name,file),'utf8')).split('\n').filter(Boolean)){
    const m=JSON.parse(line).message;if(m?.role==='toolResult'&&m.toolCallId==='anon_'+id)reply=JSON.parse(m.content.filter(c=>c.type==='text').map(c=>c.text).join('\n'));
   }
  }
 }
 assert.equal(reply?.status,'completed',JSON.stringify(reply));result.stages.push({tool,operation:request.operation,response:reply});
 await writeFile(join(output,'progress.json'),JSON.stringify(result,null,2));return reply;
}
try{
 provider=createServer(async(req,res)=>{
  let bytes='';for await(const b of req)bytes+=b;const payload=JSON.parse(bytes);result.controlProviderCalls++;
  let delta,finish;if(!pending){res.writeHead(409);return res.end()}
  if(!pending.sent){assert.ok(payload.tools.some(t=>t.function.name===pending.tool));pending.sent=true;delta={tool_calls:[{index:0,id:'anon_'+pending.id,type:'function',function:{name:pending.tool,arguments:JSON.stringify(pending.args)}}]};finish='tool_calls'}
  else{const m=payload.messages.findLast(m=>m.role==='tool'&&m.tool_call_id==='anon_'+pending.id);try{pending.reply=JSON.parse(typeof m.content==='string'?m.content:m.content.filter(c=>c.type==='text').map(c=>c.text).join('\n'))}catch{}delta={content:'ANON_DONE_'+pending.id};finish='stop'}
  res.writeHead(200,{'content-type':'text/event-stream'});for(const [d,f]of[[delta,null],[{},finish]])res.write('data: '+JSON.stringify({id:'local-anon',object:'chat.completion.chunk',model:'control',choices:[{index:0,delta:d,finish_reason:f}]})+'\n\n');res.end('data: [DONE]\n\n');
 });provider.listen(0,'127.0.0.1');await once(provider,'listening');
 await writeFile(join(agentDir,'auth.json'),'{"fixture":{"type":"api_key","key":"local-only"}}',{mode:0o600});
 await writeFile(join(agentDir,'models.json'),JSON.stringify({providers:{fixture:{api:'openai-completions',apiKey:'local-only',baseUrl:'http://127.0.0.1:'+provider.address().port,models:[{id:'control',name:'Local dispatch',contextWindow:200000,maxTokens:256}]}}}),{mode:0o600});
 await enableUiTesting(process.cwd(),agentDir);
 const port=18985;assert.equal(await portUp(port),false,'Preserve other listeners');
 const env={...process.env};for(const key of Object.keys(env))if(/(API_KEY|AUTH_TOKEN|ACCESS_TOKEN|SECRET_ACCESS_KEY|SESSION_TOKEN)$/.test(key)||/^(AWS_|GOOGLE_|GCLOUD_|AZURE_|PI_)/.test(key)||['ELECTRON_RUN_AS_NODE','NODE_OPTIONS'].includes(key))delete env[key];
 Object.assign(env,{PI_DESKTOP_USER_DATA:join(privateRoot,'ui'),PI_CODING_AGENT_DIR:agentDir,PI_WEB_DATA_DIR:dataDir,PI_WEB_CWD:root,PI_WEB_PORT:String(port),PI_WEB_PLUGIN_CATALOG_URL:'off',PI_WEB_SDK:'bundled',PI_WEB_TOOL_LAZY_LOADING:'0'});
 app=await launchNativeApp({executablePath:electron,packaged:false,env});page=await app.firstWindow();await page.waitForSelector('.app');
 await app.context().addInitScript(()=>{const Original=window.WebSocket;window.__anonMessages=[];window.WebSocket=class extends Original{constructor(...args){super(...args);window.__anonSocket=this;this.addEventListener('message',e=>{try{window.__anonMessages.push(JSON.parse(e.data))}catch{}})}}});
 await page.reload();await until(()=>page.evaluate(()=>window.__anonMessages.some(m=>m.type==='ready')),'desktop ready');
 const close=page.locator('.setup-modal .modal-close');if(await close.isVisible())await close.click();
 await page.evaluate(()=>window.__anonSocket.send(JSON.stringify({type:'set_model',modelId:'fixture/control'})));
 await until(()=>page.evaluate(()=>window.__anonMessages.some(m=>m.state?.model?.id==='control')),'local model selection');
 // Transfer existing native private registrations byte-for-byte to this isolated desktop session.
 const dirs=(await readdir(join(agentDir,'sessions'),{withFileTypes:true})).filter(d=>d.isDirectory());assert.equal(dirs.length,1);
 await cp(join(root,'ui-review-authority'),join(agentDir,'sessions',dirs[0].name,'ui-review-authority'),{recursive:true});result.nativeAuthorityCopied=true;
 const reused=await native('ui_design_diagnose',{operation:'reuse',asset_ref:ledger.asset_ref,review_ref:result.reviewRef,spec_ref:ledger.diagnostic_spec_ref});assert.equal(reused.output.runtime_ready,true);
 const designed=await native('ui_test_workflow',{operation:'checkpoint',task_ref:ledger.task_ref,stage:'design-review',output_refs:[ledger.asset_ref,result.reviewRef]});result.designTaskRef=designed.artifact_refs[0];
 const task_id='pms-anonymous-electron-execute-v3';
 await native('ui_test_workflow',{operation:'start',input:{task_id,mode:'execute',asset_ref:ledger.asset_ref}});
 const run=await native('ui_test_run',{operation:'start',input:{task_id,request_id:'pms-anonymous-electron-formal-2',asset_ref:ledger.asset_ref,review_ref:result.reviewRef,environment_ref:spec.environment_ref,config_ref:spec.config_ref,timeout_ms:120000}});
 result.formalRuns=1;result.runRef=run.artifact_refs[0];
 const analyzed=await native('ui_result_analysis',{operation:'analyze-task',task_id});
 result.analysis=analyzed.output;result.status='ELECTRON_ANONYMOUS_FORMAL_AND_REPORT_CANDIDATE_COMPLETE';
 await page.screenshot({path:join(output,'electron-result.png')});
 result.prebuiltServerSha256=sha256(await readFile('dist/server/index.js'));result.prebuiltDesktopSha256=sha256(await readFile('dist/desktop/main.js'));
}catch(error){result.failure=error.message;process.exitCode=1}
finally{
 if(app){await writeFile(join(privateRoot,'desktop.log'),app.getLogs(),{mode:0o600});await app.close()}
 provider?.closeAllConnections();if(provider)await new Promise(ok=>provider.close(ok));
 await writeFile(join(output,'result.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));
}
