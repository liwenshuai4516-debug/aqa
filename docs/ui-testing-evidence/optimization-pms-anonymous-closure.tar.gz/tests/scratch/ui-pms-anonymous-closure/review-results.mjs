import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {writeFileSync,existsSync} from 'node:fs';
import {join} from 'node:path';
import {ModelRuntime} from '@earendil-works/pi-coding-agent';
const packet=JSON.parse(await readFile(new URL('review-packet-v2.json',import.meta.url),'utf8')),root=packet.root;
const ledgerPath=new URL('result-review-budget.json',import.meta.url);
let ledger;
if(existsSync(ledgerPath))ledger=JSON.parse(await readFile(ledgerPath,'utf8'));
else{
 ledger={authorization_id:'pms-anonymous-results-2026-10-27',question_call_id:'call_70be24c5dc9d4a37ac77ba3f84c66b86',human_reply:'授权新增结果评审额度并完成交付',purpose:'Independent R1-R6 review and native delivery of frozen historical failed and revised Electron passed anonymous reports; separate from design budget',provider:'gpt',model:'gpt-6.1-sol',authorized_endpoint:'https://api.sudorelay.com',max_calls:3,max_output_tokens:8192,max_input_bytes:1048576,max_cost_usd:1,price_upper_bound_usd_per_million:1/3,price_basis:'Previously confirmed conservative upper bound; reserve one token per UTF-8 input byte plus max output',reports:packet.reports,attempts:[],native_attempts:[]};
 await writeFile(ledgerPath,JSON.stringify(ledger,null,2)+'\n',{flag:'wx'});
}
ledger.revised_reports=packet.reports;
const save=()=>writeFileSync(ledgerPath,JSON.stringify(ledger,null,2)+'\n');
assert.ok(!ledger.attempts.some(a=>a.status==='started')&&!ledger.native_attempts.some(a=>a.status==='started'),'Reconcile unknown prior calls instead of replay');
const defs=new Map();const {registerResultTools}=await import(new URL('result-extension.js',import.meta.resolve('pi-ui-testing')));registerResultTools({registerTool:t=>defs.set(t.name,t)});
const runtime=await ModelRuntime.create({modelsStorePath:join(root,'model-cache.json'),refreshOnCreate:false});
const model=(await runtime.getAvailable()).find(m=>m.provider===ledger.provider&&m.id===ledger.model);assert.ok(model,'Authorized configured model unavailable');
assert.equal(new URL(model.baseUrl).origin,ledger.authorized_endpoint);
for(let index=0;index<packet.reports.length;index++){
 const report=packet.reports[index],request_id=index===0?'pms-anonymous-result-review-1-revised':'pms-anonymous-result-review-2',file=new URL(request_id+'.json',import.meta.url);
 if(existsSync(file)){const old=JSON.parse(await readFile(file,'utf8'));assert.equal(old.response.output.decision,'approved','Prior non-approved review requires explicit revision');continue}
 const native={request_id,status:'started',report_ref:report.report_ref,started_at:new Date().toISOString()};
 assert.ok(ledger.attempts.length<ledger.max_calls);ledger.native_attempts.push(native);save();const pending=[];
 const registry={streamSimple(m,context,options){
  assert.equal(m.provider,ledger.provider);assert.equal(m.id,ledger.model);assert.deepEqual(context.tools??[],[]);assert.ok(ledger.attempts.length<ledger.max_calls);
  const input_bytes=Buffer.byteLength(JSON.stringify(context));assert.ok(input_bytes<=ledger.max_input_bytes);
  const reserved_usd=(input_bytes+ledger.max_output_tokens)*ledger.price_upper_bound_usd_per_million/1e6;
  assert.ok(ledger.attempts.reduce((n,a)=>n+a.reserved_usd,0)+reserved_usd<=ledger.max_cost_usd);
  const attempt={request_id,status:'started',input_bytes,reserved_usd,max_output_tokens:ledger.max_output_tokens,started_at:new Date().toISOString()};ledger.attempts.push(attempt);save();
  const stream=runtime.streamSimple(m,context,{...options,maxTokens:ledger.max_output_tokens});
  pending.push(stream.result().then(message=>{attempt.status=message.stopReason;attempt.usage=message.usage;attempt.duration_ms=message.durationMs;attempt.finished_at=new Date().toISOString();if(message.errorMessage)attempt.error_category='provider-or-runtime-error';save()},()=>{attempt.status='error';attempt.finished_at=new Date().toISOString();save()}));return stream;
 }};
 try{
  const raw=await defs.get('ui_result_review').execute(request_id,{request:{operation:'review',report_ref:report.report_ref,request_id}},new AbortController().signal,undefined,{cwd:root,model,modelRegistry:registry,sessionManager:{getSessionDir:()=>root}});
  await Promise.all(pending);const response=JSON.parse(raw.content.filter(c=>c.type==='text').map(c=>c.text).join('\n'));
  native.status=response.status;native.finished_at=new Date().toISOString();save();await writeFile(file,JSON.stringify({report:report.name,report_ref:report.report_ref,response},null,2)+'\n',{flag:'wx'});
  console.log(JSON.stringify({request_id,response},null,2));assert.equal(response.status,'completed');assert.equal(response.output.decision,'approved','Review did not approve; stop dependent delivery');
 }catch(error){await Promise.allSettled(pending);if(native.status==='started')native.status='host-error';native.finished_at=new Date().toISOString();save();throw error}
}
