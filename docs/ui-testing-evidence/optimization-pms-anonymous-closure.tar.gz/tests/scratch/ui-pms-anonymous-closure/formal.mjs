/** One read-only anonymous baseline formal run through native admission; no model or business writes. */
import assert from 'node:assert/strict';
import {readFile,writeFile,readdir,cp} from 'node:fs/promises';
import {existsSync} from 'node:fs';
import {join,dirname,resolve} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {ArtifactStore,UiWorkflowService,DesignReviewService,RuntimeAdmissionService,UiRunService,capabilities,collectResults} from 'pi-ui-testing';
const ledger=JSON.parse(await readFile(new URL('../ui-optimization-u00/pms-anonymous-authorized-review-budget.json',import.meta.url),'utf8'));
const root=resolve(ledger.candidate_directory),file=join(root,'pms-anonymous-formal-2.json'),authority=join(root,'ui-review-authority'),store=new ArtifactStore(root);
assert.ok(!existsSync(file),'Prior formal result exists; inspect status instead of replay');
const approved=JSON.parse(await readFile(join(root,'pms-anonymous-design-2.json'),'utf8'));assert.equal(approved.response.output.decision,'approved');
const review=approved.response.output.review_ref;
await new DesignReviewService(root,authority).gate(ledger.asset_ref,review);
const diagnostic=await new RuntimeAdmissionService(root,authority).status('pms-anonymous-diagnostic-2');assert.equal(diagnostic.runtime_ready,true);
const spec=JSON.parse(await readFile(join(root,ledger.diagnostic_spec_ref.path),'utf8'));
const installed=dirname(fileURLToPath(import.meta.resolve('pi-ui-testing'))),workflow=new UiWorkflowService(root,authority,{tools:['read',...capabilities.map(c=>c.tool)],skills:await readdir(join(installed,'../skills'))});
let discovery=await workflow.find('pms-anonymous-redirect-repair');
if(discovery.task.data.state!=='completed'){
 discovery=await workflow.resumeTask(discovery.task_ref);
 discovery=await workflow.checkpoint(discovery.task_ref,'design-review',[ledger.asset_ref,review]);
}
assert.equal(discovery.task.data.state,'completed');
const task_id='pms-anonymous-execute-v3',request_id='pms-anonymous-formal-2';
const task=await workflow.start({task_id,mode:'execute',asset_ref:ledger.asset_ref});assert.equal(task.task.data.state,'running',JSON.stringify(task.blockers));
const result={status:'unknown',request_id,assetRef:ledger.asset_ref,reviewRef:review,diagnosticSummaryRef:diagnostic.summary_ref,discoveryTaskRef:discovery.task_ref,executionTaskRef:task.task_ref,modelCalls:0,businessWrites:0,scope:'Anonymous OperationContract to scoped /login URL baseline only; no protected business role/data acceptance'};
try{
 const execution=await new UiRunService(root,authority).start({task_id,request_id,asset_ref:ledger.asset_ref,review_ref:review,environment_ref:spec.environment_ref,config_ref:spec.config_ref,timeout_ms:120000});
 result.execution=execution;const summary=execution.run.data.output_refs.find(r=>r.path.endsWith('/execution-summary.json'));assert.ok(summary);result.executionSummary=JSON.parse(await readFile(join(root,summary.path),'utf8'));
 result.results=await collectResults(root,execution.run_ref,'pms-anonymous-results-v3');
 result.status=result.executionSummary.status==='completed'?'completed':'blocked';
 if(result.status!=='completed')process.exitCode=1;
}catch(error){result.status='blocked';result.error={message:error.message,artifact_refs:error.artifact_refs??[]};process.exitCode=1;}
finally{await cp(new URL(import.meta.url),join(root,'formal-harness-v3.mjs'));await writeFile(file,JSON.stringify(result,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(result,null,2));}
