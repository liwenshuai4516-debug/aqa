from pathlib import Path
import json,hashlib,tarfile,io,os,shutil,re,subprocess
repo=Path.cwd();work=repo/'tests/scratch/ui-pms-anonymous-closure';root=repo/'tests/scratch/ui-pms-anonymous-diagnostics/1792990404494'
sha=lambda b:hashlib.sha256(b).hexdigest()
packet=json.loads((work/'review-packet-v2.json').read_text())
delivery_path=work/'electron-delivery-1793088780075/result.json';delivery=json.loads(delivery_path.read_text())
assert delivery['status']=='ELECTRON_ANONYMOUS_BOTH_REPORTS_APPROVED_DELIVERED_TASKS_COMPLETE'
assert len(delivery['deliveries'])==2 and all(d['task_state']=='completed' and d['independently_approved']for d in delivery['deliveries'])
budget=json.loads((work/'result-review-budget.json').read_text());assert len(budget['attempts'])==3
design_path=repo/'tests/scratch/ui-optimization-u00/pms-anonymous-authorized-review-budget.json';design=json.loads(design_path.read_text());assert len(design['attempts'])==2
native=Path('/Users/liyingjun/Desktop/SW-QA/13-pi/agent-client')
native_files=['packages/ui-testing/src/results.ts','packages/ui-testing/package.json','packages/ui-testing/README.md','tests/ui-testing/results.test.mjs']
for name in native_files:
 p=work/'native-source'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((native/name).read_bytes())
checks=0;historical=[]
def verify(v,owner):
 global checks
 if isinstance(v,dict):
  if isinstance(v.get('path'),str)and isinstance(v.get('sha256'),str):
   rel=Path(v['path']);assert not rel.is_absolute()and '..'not in rel.parts,(owner,rel)
   p=root/rel
   if p.is_file() and sha(p.read_bytes())==v['sha256']:checks+=1
   elif str(rel).startswith('qa/ui/tasks/')and str(rel).endswith('/manifest.json'):
    assert p.is_file();historical.append({'owner':owner,'ref':v,'current_sha256':sha(p.read_bytes())})
   else:raise AssertionError((owner,rel,'missing or changed immutable ref'))
  for value in v.values():verify(value,owner)
 elif isinstance(v,list):
  for value in v:verify(value,owner)
for p in (root/'qa').rglob('*.json'):verify(json.loads(p.read_text()),str(p.relative_to(root)))
links=0
for item in delivery['deliveries']:
 p=root/item['delivery_ref']['path'];assert sha(p.read_bytes())==item['delivery_ref']['sha256']
 for target in re.findall(r'\]\(([^)]+)\)',p.read_text()):
  assert (p.parent/target).resolve().is_relative_to(root);assert (p.parent/target).is_file(),target;links+=1
distribution=repo/'.pi/skills/ui-testing-workflow/assets/pi-ui-testing-0.1.21.tgz';installed=repo/'tools/e2e/node_modules/pi-ui-testing';installed_files=0;installation_differences=[]
with tarfile.open(distribution)as t:
 for m in t:
  if not m.isfile():continue
  rel=Path(m.name).relative_to('package');expected=t.extractfile(m).read();actual=(installed/rel).read_bytes();installed_files+=1
  if actual!=expected:
   assert str(rel)in ['README.md','skills/ui-test-workflow/SKILL.md'],'Unexpected runtime change: '+str(rel)
   installation_differences.append({'path':str(rel),'distribution_sha256':sha(expected),'installed_sha256':sha(actual),'status':'preserved unrelated installed documentation difference; attribution not established'})
   p=work/'installation-differences'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(actual)
docdir=Path.home()/'Library/Application Support/Pi Agent Desktop/data/data-space/project-documents/e2f5d42d-2781-4e68-a452-4c87c7d1d346'
store=docdir.parent.parent/'store.json';store_before=sha(store.read_bytes())
snapshot=docdir/'anonymous-closure-2026-10-27';snapshot.mkdir(mode=0o700,exist_ok=True)
snapshots=[]
for p in sorted((root/'qa').rglob('*')):
 if not p.is_file():continue
 assert not p.is_symlink();rel=p.relative_to(root);target=snapshot/rel;target.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
 if target.exists():assert target.read_bytes()==p.read_bytes()
 else:target.write_bytes(p.read_bytes())
 os.chmod(target,0o600);assert target.read_bytes()==p.read_bytes();snapshots.append({'path':str(rel),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size})
for p in snapshot.rglob('*'):
 if p.is_dir():os.chmod(p,0o700)
intro='# 经营合同匿名基线：独立批准与正式交付（2026-10-27）\n\n历史 v2 正式批次 0通过/1失败保留；v3 Electron 新正式批次 1通过/0失败、零重试。两份报告独立结果评估通过，原任务均已完成最终交接。只验匿名同源 /login URL 基线，不证明登录角色/租户业务或服务端根因。没有新增用例库入库或绑定。\n\n'
for i,item in enumerate(delivery['deliveries']):
 rel=item['delivery_ref']['path'];intro+=f'- [{"历史失败完整报告"if i==0 else"新修订通过完整报告"}]({snapshot.name}/{rel})\n'
intro+='\n公开快照与原生文件逐字节一致。仅保存文件，不宣称应用文档列表登记；原数据空间 store 未改。历史 ERR_ABORTED 底层触发原因仍 unknown。\n'
doc=docdir/'OperationContract-anonymous-approved-delivery-2026-10-27.md'
if doc.exists():assert doc.read_text()==intro
else:doc.write_text(intro)
os.chmod(doc,0o600);assert doc.read_text()==intro;assert sha(store.read_bytes())==store_before
receipt={'document':str(doc),'sha256':sha(doc.read_bytes()),'snapshot':str(snapshot),'files':snapshots,'store_unchanged':True,'store_sha256':store_before,'application_document_index':'not-registered','case_imports':0}
(work/'data-space-documents.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
(work/'distribution-check.json').write_text(json.dumps({'version':'0.1.21','sha256':sha(distribution.read_bytes()),'native_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=native,text=True).strip(),'native_upstream_pushed':False,'installed_files_compared':installed_files,'all_equal':not installation_differences,'all_runtime_equal':True,'documentation_differences':installation_differences},indent=2)+'\n')
files={}
def add(p):
 assert not p.is_symlink();assert not set(p.parts)&{'node_modules','ui-review-authority','private-evidence','private-reviews'}
 assert p.name not in {'auth.json','models.json','model-cache.json'}
 files[str(p.relative_to(repo))]=p.read_bytes()
for p in (root/'qa').rglob('*'):
 if p.is_file():add(p)
for p in work.rglob('*'):
 if p.is_file():add(p)
add(design_path)
for name in ['pms-anonymous-design-2.json','native-diagnostic-2.json','diagnostic-harness-v3.mjs']:add(root/name)
archive=repo/'docs/ui-testing-evidence/optimization-pms-anonymous-closure.tar.gz'
with tarfile.open(archive,'w:gz')as t:
 for name,b in sorted(files.items()):m=tarfile.TarInfo(name);m.size=len(b);m.mtime=0;m.mode=0o600;t.addfile(m,io.BytesIO(b))
with tarfile.open(archive)as t:
 assert set(t.getnames())==set(files)
 for m in t:assert t.extractfile(m).read()==files[m.name]
index={'date':'2026-10-27','status':'ANONYMOUS_REVISION_FORMAL_PASS_BOTH_REPORTS_INDEPENDENTLY_APPROVED_ELECTRON_DELIVERED','anonymous_execution_and_report_items_closed':True,'entire_optimization_plan_complete':False,'historical_counts':packet['oldCounts'],'new_counts':packet['newCounts'],'reports':delivery['deliveries'],'design_calls_total':len(design['attempts']),'design_reserved_usd':sum(a['reserved_usd']for a in design['attempts']),'result_review_calls':len(budget['attempts']),'result_review_reserved_usd':sum(a['reserved_usd']for a in budget['attempts']),'native_source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=native,text=True).strip(),'distribution':json.loads((work/'distribution-check.json').read_text()),'immutable_refs_verified':checks,'historical_mutable_task_refs':historical,'delivery_links_verified':links,'durable_project_documents':{k:v for k,v in receipt.items()if k!='files'},'durable_snapshot_files':len(snapshots),'validation':{'native_regression':'22 passed, 1 live-model test skipped','host_unit':'62 passed in 4 files','typecheck':'passed, all 5 configurations','lint':'passed','protocol':'structural checks passed; git tag heuristic skipped','diff':'passed'},'limitations':['Historical abort trigger unknown; no server-root-cause claim','Anonymous URL baseline only; no role/tenant/business acceptance','No anonymous case import or binding','Local controller dispatch is not autonomous model planning','Historical diagnostic-success trace cannot be reconstructed'],'archive':{'path':str(archive.relative_to(repo)),'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'files':len(files),'roundtrip_verified':True},'files':[{'path':n,'sha256':sha(b),'bytes':len(b)}for n,b in sorted(files.items())]}
(repo/'docs/ui-testing-evidence/optimization-pms-anonymous-closure.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in index.items()if k not in ['files','historical_mutable_task_refs','reports']},ensure_ascii=False,indent=2))
