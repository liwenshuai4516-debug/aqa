import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {writeFile,mkdir} from 'node:fs/promises';
import {chromium,expect} from '@playwright/test';
import {CHROME_PATH} from '../../lib/chrome.mjs';
const results={started_at:new Date().toISOString(),kind:'non-formal-mechanism-investigation',local:[],real:[],modelCalls:0};
const output=new URL('./attempt2/',import.meta.url);await mkdir(output,{recursive:true});
const server=createServer((req,res)=>{
 res.setHeader('content-type','text/html');
 if(req.url.startsWith('/login'))return setTimeout(()=>res.end('<p>login</p>'),200);
 res.end('<p>protected baseline</p>');
});
await new Promise((ok,no)=>{server.once('error',no);server.listen(18984,'127.0.0.1',ok)});
const browser=await chromium.launch({executablePath:CHROME_PATH,headless:true});
const inspect=async(base,mode,real=false)=>{
 const context=await browser.newContext({storageState:{cookies:[],origins:[]},serviceWorkers:'block',acceptDownloads:false});
 const page=await context.newPage(),origin=new URL(base).origin,events=[],blocked=[];
 const stamp=()=>Math.round(performance.now()-start);
 const start=performance.now();
 await context.route('**/*',route=>{
  const r=route.request(),allowed=new URL(r.url()).origin===origin&&['GET','HEAD'].includes(r.method());
  if(!allowed)blocked.push({method:r.method(),origin:new URL(r.url()).origin,path:new URL(r.url()).pathname});
  if(!real&&new URL(r.url()).search==='?first')return route.abort('aborted');
  return allowed?route.continue():route.abort('blockedbyclient');
 });
 page.on('framenavigated',f=>{if(f===page.mainFrame())events.push({ms:stamp(),event:'navigation',path:new URL(f.url()).pathname})});
 page.on('requestfailed',r=>{if(r.isNavigationRequest())events.push({ms:stamp(),event:'navigation-failed',path:new URL(r.url()).pathname,error:r.failure()?.errorText})});
 const name=real?'real-'+mode:'local-'+mode;
 await context.tracing.start({screenshots:true,snapshots:true,sources:true});
 try{
  await page.goto(base+'/pms/OperationContract');
  if(!real&&mode!=='negative')await page.evaluate(()=>{setTimeout(()=>location.href='/login?first',50);setTimeout(()=>location.href='/login?second',100)});
  const assertionStart=performance.now();let old;
  if(mode==='old'||real){
   try{await expect(page).toHaveURL(u=>u.origin===origin&&u.pathname==='/login',{timeout:3000});old={passed:true};}
   catch(e){old={passed:false,error:e.message.replace(/\u001b\[[0-9;]*m/g,'')};}
   old.duration_ms=Math.round(performance.now()-assertionStart);
  }
  let revised;
  if(mode!=='old'){
   const at=performance.now();
   try{await expect.poll(()=>{const u=new URL(page.url());return {origin:u.origin,pathname:u.pathname}},{timeout:3000}).toEqual({origin,pathname:'/login'});revised={passed:true};}
   catch(e){revised={passed:false,error:e.message.replace(/\u001b\[[0-9;]*m/g,'')};}
   revised.duration_ms=Math.round(performance.now()-at);
  }
  return {name,old,revised,final:{origin:new URL(page.url()).origin,path:new URL(page.url()).pathname},events,blocked,trace:name+'.zip'};
 }finally{await context.tracing.stop({path:new URL(name+'.zip',output).pathname});await context.close();}
};
try{
 results.local.push(await inspect('http://127.0.0.1:18984','old'));
 results.local.push(await inspect('http://127.0.0.1:18984','revised'));
 results.local.push(await inspect('http://127.0.0.1:18984','negative'));
 assert.equal(results.local[1].revised.passed,true);
 assert.equal(results.local[2].revised.passed,false);
 const env=JSON.parse(await (await import('node:fs/promises')).readFile('tests/scratch/ui-pms-anonymous-diagnostics/1792990404494/qa/ui/assets/pms-anonymous-redirect/revisions/v2/positive-environment.json','utf8'));
 results.real.push(await inspect(env.base_url,'observation-1',true));
}finally{
 await browser.close();server.closeAllConnections();await new Promise(ok=>server.close(ok));
 results.finished_at=new Date().toISOString();
 await writeFile(new URL('investigation.json',output),JSON.stringify(results,null,2)+'\n');
 console.log(JSON.stringify(results,null,2));
}
