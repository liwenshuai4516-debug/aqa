/** Compare minimal managed auth with the full target-specific adapter, using one fresh login. No capture or business writes. */
import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir,mkdtemp,rm,realpath,cp,access} from 'node:fs/promises';
import {tmpdir,homedir} from 'node:os';
import {join} from 'node:path';
import {chromium} from 'playwright';
import {authState,sha256} from 'pi-ui-testing';
import {preparePmsSession} from '../../lib/pms-private-session.mjs';
import {CHROME_PATH} from '../../lib/chrome.mjs';
import {createPrivateBrowserStates} from '../../../plugins/data-space/private-browser-state.mjs';
import {normalizeEnvDynamic,dynamicFresh} from '../../../plugins/data-space/env-script.mjs';
assert.ok(process.argv.includes('--refresh'),'Explicit configured login required');
const repo=process.cwd(),output=join(repo,'tests/scratch/ui-pms-private-comparison',String(Date.now()));await mkdir(output,{recursive:true});
const privateRoot=await realpath(await mkdtemp(join(tmpdir(),'pms-private-comparison-'))),project=join(privateRoot,'project'),dataDir=join(privateRoot,'data');await mkdir(project,{mode:0o700});await mkdir(dataDir,{mode:0o700});
const originalFile=join(homedir(),'Library/Application Support/Pi Agent Desktop/data/data-space/store.json'),before=await readFile(originalFile),store=JSON.parse(before),systemId='e2f5d42d-2781-4e68-a452-4c87c7d1d346',envId='f46a32da-2eac-43ca-86b8-2fa5eca5385c';
const env=store.envs.find(e=>e.id===envId&&e.systemId===systemId);assert.ok(env);const target=new URL('/pms/OperationContract',env.baseUrl),expectedAccount=env.params.find(p=>p.key==='账号')?.value;assert.ok(expectedAccount);
const plan={systemId,envId,revision:store.revision,target:target.href,comparison:['anonymous','managed-token-only','full-target-session'],authSource:'One actual configured login and its permission read; same token in both authenticated contexts',allowed:['Explicit configured login POST once','Permission/profile reads','Same-origin browser GET/HEAD only'],forbidden:['Form input/submission','Business writes','Foreign origins','Screenshot/trace/DOM/response body capture'],snapshot:'Derived in memory from observed login token; authoritative Data Space cache not refreshed',role:'unknown',data:'unknown',modelCalls:0,formalRuns:0};await writeFile(join(output,'plan.json'),JSON.stringify(plan,null,2)+'\n');
const result={status:'blocked',plan,explicitPreparationRequests:[],contexts:[],modelCalls:0,formalRuns:0,businessWrites:0,originalStoreWrites:0,limitations:['Direct production manager/native authState comparison in test process; not an Electron Agent business run','In-memory fresh parameter snapshot derived from actual login; not a Data Space refresh tool/cache integration test','Public marker/route/profile checks do not establish business permissions or test-data readiness','No private recording or approved diagnostic/formal execution']};
let full,manager,browser,managedPath;
try{
 full=await preparePmsSession({store,systemId,envId,refresh:true,fetchImpl:async(url,init)=>{result.explicitPreparationRequests.push({method:init.method,path:new URL(url).pathname});return fetch(url,init);}});
 assert.deepEqual(result.explicitPreparationRequests,[{method:'POST',path:'/api/base-service/login'},{method:'GET',path:'/api/base-service/permission'}]);
 const fullPath=await authState({auth:full.auth}),state=JSON.parse(await readFile(fullPath,'utf8')),token=state.origins.find(o=>o.origin===target.origin)?.localStorage.find(p=>p.name==='token')?.value;assert.ok(token);
 const snapshot=structuredClone(store),freshEnv=snapshot.envs.find(e=>e.id===envId),at=new Date().toISOString(),expiresAt=new Date(Date.now()+Number(env.script.ttlMinutes)*60000).toISOString();
 freshEnv.dynamic=normalizeEnvDynamic([{key:'token',value:token,secret:true,at,expiresAt}]);freshEnv.scriptRun={at,ok:true,error:'',ms:0};assert.ok(dynamicFresh(freshEnv));
 manager=createPrivateBrowserStates({dataDir,store:()=>snapshot});
 const managed=await manager.prepare(project,{engine:'ui',mode:'execute',systemId,envId,targetUrl:target.href,privateBindings:[{parameterKey:'token',storageKey:'token'}]});
 managedPath=await authState({auth:managed.auth,base_url:target.href},project);assert.ok(managedPath);
 const managedState=JSON.parse(await readFile(managedPath,'utf8'));assert.equal(managedState.origins[0].localStorage.length,1);assert.equal(managedState.origins[0].localStorage[0].value,token);
 result.manager={nativeConsumption:'authState scope/expiry validation passed',privateBindings:1,currentDynamicTokenConsumed:true,stateValuesPublic:false,authentication:managed.preparation.authentication,role:managed.preparation.role,data:managed.preparation.data};
 browser=await chromium.launch({headless:true,...(CHROME_PATH?{executablePath:CHROME_PATH}:{})});
 for(const [kind,path] of [['anonymous',undefined],['managed-token-only',managedPath],['full-target-session',fullPath]]){
  const context=await browser.newContext({...(path?{storageState:path}:{}),serviceWorkers:'block',acceptDownloads:false});
  const observation={kind,allowedReadRequests:0,blockedWriteRequests:0,blockedForeignRequests:0,pageErrors:0,httpErrors:0};result.contexts.push(observation);
  try{
   await context.route('**/*',async route=>{const request=route.request();if(new URL(request.url()).origin!==target.origin){observation.blockedForeignRequests++;return route.abort('blockedbyclient');}if(!['GET','HEAD'].includes(request.method())){observation.blockedWriteRequests++;return route.abort('blockedbyclient');}observation.allowedReadRequests++;return route.continue();});
   const page=await context.newPage();page.on('pageerror',()=>observation.pageErrors++);page.on('response',r=>{if(r.status()>=400)observation.httpErrors++;});
   await page.goto(target.href,{waitUntil:'networkidle',timeout:25000});
   const url=new URL(page.url());observation.atTargetRoute=url.origin===target.origin&&url.pathname===target.pathname;observation.atLoginRoute=url.origin===target.origin&&url.pathname==='/login';observation.atAccessDeniedRoute=url.origin===target.origin&&['/401','/403'].includes(url.pathname);
   observation.publicControls={};for(const label of ['查询','搜索','新增','保存草稿','经营合同'])observation.publicControls[label]=await page.getByText(label,{exact:true}).count();
   observation.browserStorage=await page.evaluate(()=>({tokenPresent:!!localStorage.getItem('token'),accountPresent:!!localStorage.getItem('account'),menuPresent:!!localStorage.getItem('pms_menu'),tenantPresent:!!localStorage.getItem('pms_tenant')}));
   if(path)observation.accountProbe=await page.evaluate(async expected=>{let token=localStorage.getItem('token');try{const p=JSON.parse(token);if(typeof p==='string')token=p;}catch{}if(!token)return{state:'not-ready',reason:'token-absent'};try{const r=await fetch('/api/base-service/account-profile',{method:'GET',redirect:'error',headers:{token,'x-parent-client-code':'pms','x-client-code':'pms'},signal:AbortSignal.timeout(10000)}),profile=await r.json();return{state:r.ok&&profile.code===200&&profile.data?.username===expected?'matched':'not-ready',reason:'same-browser-profile-account-comparison'};}catch{return{state:'unknown',reason:'profile-request-failed'};}},expectedAccount);
   observation.status='observed';
  }catch{observation.status='blocked';observation.reason='navigation-or-observation-failed';}
  finally{await context.close();observation.contextClosed=true;}
 }
 assert.ok(result.contexts.every(c=>c.status==='observed'));
 assert.equal(result.contexts[0].atLoginRoute,true,'Anonymous baseline changed; do not infer auth comparison');
 assert.equal(result.contexts[2].accountProbe.state,'matched','Full positive control is not authenticated');assert.equal(result.contexts[2].atTargetRoute,true,'Full positive control did not reach target');
 const minimal=result.contexts[1];result.conclusion=minimal.atTargetRoute&&minimal.accountProbe.state==='matched'?'TOKEN_ONLY_REACHES_TARGET_ACCOUNT_MATCHED_ROLE_DATA_UNVERIFIED':minimal.accountProbe.state==='matched'?'TOKEN_AUTHENTICATES_BUT_BROWSER_INITIALIZATION_INCOMPLETE':'TOKEN_ONLY_AUTHENTICATION_NOT_CONFIRMED';
 result.status='COMPARISON_OBSERVED';
}catch(error){result.blocker=/^PMS private preparation blocked: [a-z-]+$/.test(error.message)?error.code:'private-comparison-precondition-or-observation-failed';process.exitCode=1;}
finally{
 if(browser)await browser.close();
 if(manager){manager.dispose();if(managedPath){await assert.rejects(access(managedPath));result.managedStateRemoved=true;}}
 if(full){const path=process.env[full.auth.reference];await full.dispose();await assert.rejects(access(path));result.fullStateRemoved=true;}
 await rm(privateRoot,{recursive:true,force:true});result.privateRootRemoved=true;
 result.storeUnchanged=(await readFile(originalFile)).equals(before);assert.ok(result.storeUnchanged);
 for(const [source,name] of [[new URL(import.meta.url),'harness.mjs'],[join(repo,'tests/lib/pms-private-session.mjs'),'adapter.mjs'],[join(repo,'plugins/data-space/private-browser-state.mjs'),'manager.mjs']])await cp(source,join(output,name));
 await writeFile(join(output,'result.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({output,...result},null,2));
}
