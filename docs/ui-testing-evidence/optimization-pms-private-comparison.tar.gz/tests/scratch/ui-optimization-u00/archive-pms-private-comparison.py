from pathlib import Path
import json, hashlib, tarfile, io, os
repo=Path.cwd(); out=repo/'tests/scratch/ui-pms-private-comparison/1792991555884'
sha=lambda b:hashlib.sha256(b).hexdigest()
r=json.loads((out/'result.json').read_text()); assert r['status']=='COMPARISON_OBSERVED'
assert r['storeUnchanged'] and r['managedStateRemoved'] and r['fullStateRemoved'] and r['privateRootRemoved']
assert r['modelCalls']==r['formalRuns']==r['businessWrites']==r['originalStoreWrites']==0
assert r['contexts'][0]['atLoginRoute'] and all(c['atTargetRoute'] and c['accountProbe']['state']=='matched' for c in r['contexts'][1:])
ledger=repo/'tests/scratch/ui-optimization-u00/u05-authorized-review-budget.json'
assert sha(ledger.read_bytes())==json.loads((repo/'docs/ui-testing-evidence/optimization-pms-anonymous-diagnostics.json').read_text())['modelReviewLedgerSha256']
(out/'.cleanup-keep').write_text('Retain real PMS preparation comparison; not approved formal execution.\n')
text='''# 经营合同受管 token 与完整状态对照（准备观察，非正式执行）

项目：Electron 数据空间“项目管理系统”；环境及目标沿用现有配置 /pms/OperationContract。

2026-10-26，同一次真实配置登录生成的 token 分别用于受管 token-only 引用和完整会话，另设匿名独立 context。匿名跳转 /login；受管 token-only 与完整状态均停留目标页，且同一浏览器的 account-profile 账号比对 matched。原生 authState 消费受管引用及工作区/有效期验证通过。

这修正了“必须先做 PMS 会话结构转换才能到达目标”的假设；不证明业务角色、租户上下文或隔离测试数据已经就绪。token-only 的 account/tenant 本地项为空；完整状态包含这些项。两者都观察到“查询”，没有观察到“新增”或“保存草稿”；不能据此推断权限。

范围：配置登录 POST 1次、permission GET 1次；浏览器仅允许同源 GET/HEAD。匿名/受管/完整三组分别观察到 41/30/30 次读取（认证组含账号探针），写入及外域请求均0，页面与HTTP错误均0。未保存截图、trace、DOM、响应正文、账号或token。零拒绝计数不代表完成守卫反例验证。

限制：动态参数快照由本轮实际登录 token 在内存中派生；未通过实际 Electron 环境刷新接口或刷新原缓存。测试进程直接消费生产 manager/authState，不是 Electron Agent 业务运行。角色/租户/数据仍 unknown，私密录制未开放，候选评审、正反诊断及正式执行均未开展。

清理：所有 context、浏览器、受管状态、完整私有状态及临时根均已清理；原库逐字节不变。模型调用0、正式批次0、业务写入0。本记录不改变原3条源码草稿状态。

恢复：优先核验隔离私有副本中的实际 Electron 环境刷新→prepare-private→原生消费；随后独立补业务角色/租户/测试数据和录制隐私。无需把尚未证实必要的会话转换继续设为硬前置。

公开证据保存在同目录 private-comparison-1792991555884/。文件持久保存不代表应用文档列表可见或已登记正式测试结果。
'''
docdir=Path.home()/'Library/Application Support/Pi Agent Desktop/data/data-space/project-documents/e2f5d42d-2781-4e68-a452-4c87c7d1d346'
store=docdir.parent.parent/'store.json';before=store.read_bytes()
snapshot=docdir/'private-comparison-1792991555884';snapshot.mkdir(mode=0o700)
items=[]
for name in ['plan.json','result.json','harness.mjs','adapter.mjs','manager.mjs']:
 p=out/name; b=p.read_bytes(); target=snapshot/name
 with target.open('xb') as f:f.write(b)
 os.chmod(target,0o600);assert target.read_bytes()==b
 items.append({'path':name,'sha256':sha(b),'bytes':len(b)})
doc=docdir/'OperationContract-private-state-comparison-2026-10-26.md'
with doc.open('x') as f:f.write(text)
os.chmod(doc,0o600);assert doc.read_text()==text;assert store.read_bytes()==before
receipt={'document':{'path':str(doc),'sha256':sha(doc.read_bytes()),'bytes':doc.stat().st_size},'snapshot':{'path':str(snapshot),'files':items},'storeUnchanged':True,'application_document_index':'unsupported'}
(out/'data-space-documents.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
files={}
for p in sorted(out.iterdir()):
 assert p.is_file() and not p.is_symlink();files[str(p.relative_to(repo))]=p.read_bytes()
for name in ['pms-token-comparison.log','compare-pms-private-state.mjs','archive-pms-private-comparison.py']:
 p=repo/'tests/scratch/ui-optimization-u00'/name;files[str(p.relative_to(repo))]=p.read_bytes()
archive=repo/'docs/ui-testing-evidence/optimization-pms-private-comparison.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for n,b in sorted(files.items()):
  m=tarfile.TarInfo(n);m.size=len(b);m.mtime=0;t.addfile(m,io.BytesIO(b))
with tarfile.open(archive) as t:
 assert set(t.getnames())==set(files)
 for m in t:assert t.extractfile(m).read()==files[m.name]
index={'date':'2026-10-26','status':r['status'],'plan_complete':False,'modelCalls':0,'formalRuns':0,'modelReviewLedgerSha256':sha(ledger.read_bytes()),'ledger_unchanged':True,'result':r,'durable_project_documents':receipt,'archive':{'path':str(archive.relative_to(repo)),'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'files':len(files),'roundtrip_verified':True},'files':[{'path':n,'sha256':sha(b),'bytes':len(b)}for n,b in sorted(files.items())]}
(repo/'docs/ui-testing-evidence/optimization-pms-private-comparison.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'files':len(files),'bytes':archive.stat().st_size,'persistent_files':len(items),'ledger_unchanged':True}))
