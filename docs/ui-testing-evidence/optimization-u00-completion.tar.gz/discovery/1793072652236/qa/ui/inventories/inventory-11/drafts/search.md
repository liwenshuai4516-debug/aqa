{
  "feature": "search",
  "scenario": "search-declared",
  "states": [
    "query matches Gamma"
  ],
  "source": {
    "path": "qa/ui/scopes/declaration/fixture.mjs",
    "sha256": "f07cad393d22c4629c771ef7763de96b47d030b6730fbec222fd110da2b89cc5"
  },
  "expected": [
    "query filters names",
    "reset restores first page"
  ],
  "observations": [
    {
      "path": "qa/ui/recordings/tester/events/action-1/response.json",
      "sha256": "f3a4b647a821b2c2125c7dc9a3f70ae4a851418c1cb2b57f3040746a2c41cbf7"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-6/response.json",
      "sha256": "0825a74f97f031026f0da5e29cd072db4bcf279a598a050c1eb5e7ef4c09b6c8"
    }
  ],
  "locators": {
    "query": "getByRole('textbox', { name: 'Query' })",
    "search": "getByRole('button', { name: 'Search' })"
  },
  "gaps": [
    "Reset not observed yet"
  ]
}