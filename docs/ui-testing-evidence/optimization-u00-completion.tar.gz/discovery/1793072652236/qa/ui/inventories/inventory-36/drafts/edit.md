{
  "feature": "edit",
  "scenario": "edit-declared",
  "states": [
    "dialog open",
    "filled then cancelled",
    "saved once",
    "one persisted name after reload"
  ],
  "source": {
    "path": "qa/ui/scopes/declaration/fixture.mjs",
    "sha256": "f07cad393d22c4629c771ef7763de96b47d030b6730fbec222fd110da2b89cc5"
  },
  "expected": [
    "dialog opens and cancels without writes",
    "saved name survives reload"
  ],
  "observations": [
    {
      "path": "qa/ui/recordings/tester/events/action-12/response.json",
      "sha256": "693ba780efeba2301ab94a2f807f16d521f7a7574fbfcd40ee0fd9ecb4eb9ab5"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-17/response.json",
      "sha256": "5fdf9e5bb49b67eda594978bf6f5cd1469d8f2524ba9f0ccc12dc2c5ee98f076"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-19/response.json",
      "sha256": "24442297382810a83953f4696b4aa710517af0a3d888c5a0b0de6696adee5956"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-24/response.json",
      "sha256": "fe14cb50375e44b9453be2a3e3a467f24bc7fb7f4fc8f78d676f71a29f5d8dfc"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-27/response.json",
      "sha256": "25f9b351e11b429f83d9c71b7701cb4bbd4e188dcc275e97f9d5c54b51f1039a"
    }
  ],
  "locators": {
    "query": "getByRole('textbox', { name: 'Query' })",
    "search": "getByRole('button', { name: 'Search' })",
    "reset": "getByRole('button', { name: 'Reset' })",
    "add": "getByRole('button', { name: 'Add' })",
    "name": "getByRole('textbox', { name: 'Name' })",
    "cancel": "getByRole('button', { name: 'Cancel' })",
    "save": "getByRole('button', { name: 'Save' })"
  },
  "gaps": []
}