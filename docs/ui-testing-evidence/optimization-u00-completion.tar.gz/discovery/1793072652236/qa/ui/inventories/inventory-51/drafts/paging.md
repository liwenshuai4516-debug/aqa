{
  "feature": "paging",
  "scenario": "paging-declared",
  "states": [
    "first page",
    "last page",
    "query retained across next and previous",
    "both page boundaries"
  ],
  "source": {
    "path": "qa/ui/scopes/declaration/fixture.mjs",
    "sha256": "f07cad393d22c4629c771ef7763de96b47d030b6730fbec222fd110da2b89cc5"
  },
  "expected": [
    "two rows per page",
    "next and previous retain query"
  ],
  "observations": [
    {
      "path": "qa/ui/recordings/tester/events/action-32/response.json",
      "sha256": "4d7c40c3d0dd84a73c8bfda7d0292d10888dfcb617512d926af25b81d1d70fb6"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-35/response.json",
      "sha256": "e170b95c5b87c604b904841954ebb134066bc089cfcb69fc166bf7cc1a3d5e1e"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-38/response.json",
      "sha256": "6049880d327f52860f4de91b181a425c121655f04a1e24d68e034e10e33e62bd"
    }
  ],
  "locators": {
    "query": "getByRole('textbox', { name: 'Query' })",
    "search": "getByRole('button', { name: 'Search' })",
    "reset": "getByRole('button', { name: 'Reset' })",
    "add": "getByRole('button', { name: 'Add' })",
    "name": "getByRole('textbox', { name: 'Name' })",
    "cancel": "getByRole('button', { name: 'Cancel' })",
    "save": "getByRole('button', { name: 'Save' })",
    "next": "getByRole('button', { name: 'Next' })",
    "previous": "getByRole('button', { name: 'Previous' })"
  },
  "gaps": []
}