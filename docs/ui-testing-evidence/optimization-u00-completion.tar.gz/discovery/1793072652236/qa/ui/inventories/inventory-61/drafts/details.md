{
  "feature": "details",
  "scenario": "details-declared",
  "states": [
    "about selected",
    "details expanded",
    "details collapsed"
  ],
  "source": {
    "path": "qa/ui/scopes/declaration/fixture.mjs",
    "sha256": "f07cad393d22c4629c771ef7763de96b47d030b6730fbec222fd110da2b89cc5"
  },
  "expected": [
    "tab selection changes panel",
    "details expansion changes visibility"
  ],
  "observations": [
    {
      "path": "qa/ui/recordings/tester/events/action-41/response.json",
      "sha256": "f231d01e6ed841dc89447433f8041fd95c4d2c15786aed3b7244161a5ac48aa2"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-44/response.json",
      "sha256": "2916a13d74d377040da516668de8d33ec7f5a21e8aa4f6c046ed4b14d3e84520"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-46/response.json",
      "sha256": "3a62f66379821969ba32f4fce4e0489ea99123701278ea0b6f4d54747b0fcc5b"
    }
  ],
  "locators": {
    "query": "getByRole('textbox', { name: 'Query' })",
    "search": "getByRole('button', { name: 'Search' })",
    "reset": "getByRole('button', { name: 'Reset' })",
    "add": "getByRole('button', { name: 'Add' })",
    "name": "getByRole('textbox', { name: 'Name' })",
    "cancel": "getByRole('button', { name: 'Cancel' })",
    "save": "getByRole('button', { name: 'Save' })",
    "next": "getByRole('button', { name: 'Next' })",
    "previous": "getByRole('button', { name: 'Previous' })",
    "about": "getByRole('tab', { name: 'About' })",
    "details": "getByText('Details')"
  },
  "gaps": []
}