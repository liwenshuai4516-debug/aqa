{
  "feature": "search",
  "scenario": "search-declared",
  "states": [
    "query matches Gamma"
  ],
  "source": {
    "path": "qa/ui/scopes/declaration/fixture.mjs",
    "sha256": "f07cad393d22c4629c771ef7763de96b47d030b6730fbec222fd110da2b89cc5"
  },
  "expected": [
    "query filters names",
    "reset restores first page"
  ],
  "observations": [
    {
      "path": "qa/ui/recordings/tester/events/action-1/response.json",
      "sha256": "9014f0def38f14e023d0edbb9e004455afe93b74706a72152b7473e2afdead8c"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-6/response.json",
      "sha256": "0c27ec8e78ddf7cfb26fcbe86efe753381d30882ec9e33d59da68349527cb29c"
    }
  ],
  "locators": {
    "query": "getByRole('textbox', { name: 'Query' })",
    "search": "getByRole('button', { name: 'Search' })"
  },
  "gaps": [
    "Reset not observed yet"
  ]
}