{
  "feature": "paging",
  "scenario": "paging-declared",
  "states": [
    "first page",
    "last page",
    "query retained across next and previous",
    "both page boundaries"
  ],
  "source": {
    "path": "qa/ui/scopes/declaration/fixture.mjs",
    "sha256": "f07cad393d22c4629c771ef7763de96b47d030b6730fbec222fd110da2b89cc5"
  },
  "expected": [
    "two rows per page",
    "next and previous retain query"
  ],
  "observations": [
    {
      "path": "qa/ui/recordings/tester/events/action-32/response.json",
      "sha256": "c4635776b30eab20c917eb61c3682bf8ca6336e43b7be8cfbf1866c69e625467"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-35/response.json",
      "sha256": "bdbf9eb58115787895805bd8c6de5aa610ecabb7404de9edaa8ce977238d26ba"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-38/response.json",
      "sha256": "474ae151e84c19caa9de3e506fef2e2812e875bc1bcc55c446360594c3913bea"
    }
  ],
  "locators": {
    "query": "getByRole('textbox', { name: 'Query' })",
    "search": "getByRole('button', { name: 'Search' })",
    "reset": "getByRole('button', { name: 'Reset' })",
    "add": "getByRole('button', { name: 'Add' })",
    "name": "getByRole('textbox', { name: 'Name' })",
    "cancel": "getByRole('button', { name: 'Cancel' })",
    "save": "getByRole('button', { name: 'Save' })",
    "next": "getByRole('button', { name: 'Next' })",
    "previous": "getByRole('button', { name: 'Previous' })"
  },
  "gaps": []
}