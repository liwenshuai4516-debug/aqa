{
  "feature": "edit",
  "scenario": "edit-declared",
  "states": [
    "dialog open",
    "filled then cancelled",
    "saved once",
    "one persisted name after reload"
  ],
  "source": {
    "path": "qa/ui/scopes/declaration/fixture.mjs",
    "sha256": "f07cad393d22c4629c771ef7763de96b47d030b6730fbec222fd110da2b89cc5"
  },
  "expected": [
    "dialog opens and cancels without writes",
    "saved name survives reload"
  ],
  "observations": [
    {
      "path": "qa/ui/recordings/tester/events/action-12/response.json",
      "sha256": "661f6350c583c92e50c64630c2dae2d2bf314e1d4bd19fa7912360a2ed745ad4"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-17/response.json",
      "sha256": "029693a5bb1348f604defcb7afc3051ca528bbf5ee54d72b84f5b02b078a4a78"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-19/response.json",
      "sha256": "e11a829defdf8a8efb47e89792cff0d4120e58546777d1c8c648693166f90f6c"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-24/response.json",
      "sha256": "1cd9029c6cf2e4c4122b4a8e701c7683d4b1d0313d467e9aab2f5f0213d435f7"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-27/response.json",
      "sha256": "e0c87e6c6de10a3b9c34ec7187c418d0d8555fe3526b1a348519083fe76c52a0"
    }
  ],
  "locators": {
    "query": "getByRole('textbox', { name: 'Query' })",
    "search": "getByRole('button', { name: 'Search' })",
    "reset": "getByRole('button', { name: 'Reset' })",
    "add": "getByRole('button', { name: 'Add' })",
    "name": "getByRole('textbox', { name: 'Name' })",
    "cancel": "getByRole('button', { name: 'Cancel' })",
    "save": "getByRole('button', { name: 'Save' })"
  },
  "gaps": []
}