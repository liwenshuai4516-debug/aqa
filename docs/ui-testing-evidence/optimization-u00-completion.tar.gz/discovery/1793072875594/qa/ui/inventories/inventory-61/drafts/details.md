{
  "feature": "details",
  "scenario": "details-declared",
  "states": [
    "about selected",
    "details expanded",
    "details collapsed"
  ],
  "source": {
    "path": "qa/ui/scopes/declaration/fixture.mjs",
    "sha256": "f07cad393d22c4629c771ef7763de96b47d030b6730fbec222fd110da2b89cc5"
  },
  "expected": [
    "tab selection changes panel",
    "details expansion changes visibility"
  ],
  "observations": [
    {
      "path": "qa/ui/recordings/tester/events/action-41/response.json",
      "sha256": "4fbe09000d7eaaf2f4f5d4b2a8babd33c1592afe3fa5859ccef7168be1a66a03"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-44/response.json",
      "sha256": "23ae238775b60a56423c0a9fa4f3ec0d52b43db8f4d52a2a0044c43217ee4f48"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-46/response.json",
      "sha256": "9081f7cb87642ef90777b729d3924b7c713d040a67da6cc4c75f09d317dfa2ff"
    }
  ],
  "locators": {
    "query": "getByRole('textbox', { name: 'Query' })",
    "search": "getByRole('button', { name: 'Search' })",
    "reset": "getByRole('button', { name: 'Reset' })",
    "add": "getByRole('button', { name: 'Add' })",
    "name": "getByRole('textbox', { name: 'Name' })",
    "cancel": "getByRole('button', { name: 'Cancel' })",
    "save": "getByRole('button', { name: 'Save' })",
    "next": "getByRole('button', { name: 'Next' })",
    "previous": "getByRole('button', { name: 'Previous' })",
    "about": "getByRole('tab', { name: 'About' })",
    "details": "getByText('Details')"
  },
  "gaps": []
}