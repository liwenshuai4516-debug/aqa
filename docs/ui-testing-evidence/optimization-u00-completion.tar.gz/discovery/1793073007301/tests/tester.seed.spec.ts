import {test,expect} from '@playwright/test';
import {writeFile} from 'node:fs/promises';
let u05ViewerContext,u05ViewerObservation;
test.beforeAll(async({browser})=>{
 u05ViewerContext=await browser.newContext();
 try{
  const viewerPage=await u05ViewerContext.newPage();
  await viewerPage.goto("http://127.0.0.1:58459/?role=viewer");
  await expect(viewerPage.locator('#identity')).toHaveText('Role: viewer');
  await expect(viewerPage.getByRole('status')).toHaveText('Ready');
  await expect(viewerPage.getByRole('button',{name:'Add',exact:true})).toHaveCount(0);
  await expect(viewerPage.locator('#add')).toHaveCount(1);
  await expect(viewerPage.locator('#add')).toBeHidden();
  u05ViewerObservation={role:'viewer',identity:await viewerPage.locator('#identity').textContent(),accessibleAdd:await viewerPage.getByRole('button',{name:'Add',exact:true}).count(),domAdd:await viewerPage.locator('#add').count(),hidden:await viewerPage.locator('#add').isHidden()};
 }finally{await u05ViewerContext.close();}
});
test('seed',async({page})=>{
 await page.addInitScript(()=>{
  const states: {status:string,rows:string[]}[]=[];
  (window as any).__u05StatusObservations=states;
  new MutationObserver(()=>{
   const status=document.querySelector('[role=status]')?.textContent;
   if(status && status!==states.at(-1)?.status)
    states.push({status,rows:Array.from(document.querySelectorAll('li'),li=>li.textContent||'')});
  }).observe(document,{subtree:true,childList:true,characterData:true});
 });
 await page.goto('/?role=tester');
 await expect(page.locator('#identity')).toHaveText('Role: tester');
 await expect(page.getByRole('status')).toHaveText('Ready');
 const states=await page.evaluate(()=>(window as any).__u05StatusObservations);
 expect(states).toEqual([{status:'Loading',rows:[]},{status:'Ready',rows:["Alpha","Beta"]}]);
 await writeFile('qa/ui/recordings/tester/loading-observation.json',JSON.stringify({role:"tester",states}));
 expect(page.context()).not.toBe(u05ViewerContext);
 await writeFile('qa/ui/recordings/tester/viewer-observation.json',JSON.stringify({...u05ViewerObservation,separateContext:page.context()!==u05ViewerContext}));
});