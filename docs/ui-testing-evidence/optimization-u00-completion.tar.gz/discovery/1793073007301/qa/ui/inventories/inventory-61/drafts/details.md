{
  "feature": "details",
  "scenario": "details-declared",
  "states": [
    "about selected",
    "details expanded",
    "details collapsed"
  ],
  "source": {
    "path": "qa/ui/scopes/declaration/fixture.mjs",
    "sha256": "f07cad393d22c4629c771ef7763de96b47d030b6730fbec222fd110da2b89cc5"
  },
  "expected": [
    "tab selection changes panel",
    "details expansion changes visibility"
  ],
  "observations": [
    {
      "path": "qa/ui/recordings/tester/events/action-41/response.json",
      "sha256": "9e157848ad1fcf3ab9eecc6d51a6ffd34a1418541f8c0c7dfa2e3625cf929e2f"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-44/response.json",
      "sha256": "9f7242545334010c62dfc3ccd0e653f176b9683c6b0983521dc2b24d42e34c45"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-46/response.json",
      "sha256": "1e4f2dc6a161ee854ca8ffba3132f1552ae2bac7edfd1f8b49893f4236afe625"
    }
  ],
  "locators": {
    "query": "getByRole('textbox', { name: 'Query' })",
    "search": "getByRole('button', { name: 'Search' })",
    "reset": "getByRole('button', { name: 'Reset' })",
    "add": "getByRole('button', { name: 'Add' })",
    "name": "getByRole('textbox', { name: 'Name' })",
    "cancel": "getByRole('button', { name: 'Cancel' })",
    "save": "getByRole('button', { name: 'Save' })",
    "next": "getByRole('button', { name: 'Next' })",
    "previous": "getByRole('button', { name: 'Previous' })",
    "about": "getByRole('tab', { name: 'About' })",
    "details": "getByText('Details')"
  },
  "gaps": []
}