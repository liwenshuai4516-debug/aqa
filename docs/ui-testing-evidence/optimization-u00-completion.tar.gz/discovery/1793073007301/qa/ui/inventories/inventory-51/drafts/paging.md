{
  "feature": "paging",
  "scenario": "paging-declared",
  "states": [
    "first page",
    "last page",
    "query retained across next and previous",
    "both page boundaries"
  ],
  "source": {
    "path": "qa/ui/scopes/declaration/fixture.mjs",
    "sha256": "f07cad393d22c4629c771ef7763de96b47d030b6730fbec222fd110da2b89cc5"
  },
  "expected": [
    "two rows per page",
    "next and previous retain query"
  ],
  "observations": [
    {
      "path": "qa/ui/recordings/tester/events/action-32/response.json",
      "sha256": "cc2e0d71cc183c19d54e8087818295e202cc3aaaa22eb9ff6cb5f45da02d75a0"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-35/response.json",
      "sha256": "eb7d86012ce871f70296d372d0d4c92615cfbff9874c027d359b43f42d665773"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-38/response.json",
      "sha256": "89ef362ac36c982219bc3705591adb22449a431da951c54ea5da19c1d2ef6508"
    }
  ],
  "locators": {
    "query": "getByRole('textbox', { name: 'Query' })",
    "search": "getByRole('button', { name: 'Search' })",
    "reset": "getByRole('button', { name: 'Reset' })",
    "add": "getByRole('button', { name: 'Add' })",
    "name": "getByRole('textbox', { name: 'Name' })",
    "cancel": "getByRole('button', { name: 'Cancel' })",
    "save": "getByRole('button', { name: 'Save' })",
    "next": "getByRole('button', { name: 'Next' })",
    "previous": "getByRole('button', { name: 'Previous' })"
  },
  "gaps": []
}