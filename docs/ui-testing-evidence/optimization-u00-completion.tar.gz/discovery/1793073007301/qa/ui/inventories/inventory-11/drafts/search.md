{
  "feature": "search",
  "scenario": "search-declared",
  "states": [
    "query matches Gamma"
  ],
  "source": {
    "path": "qa/ui/scopes/declaration/fixture.mjs",
    "sha256": "f07cad393d22c4629c771ef7763de96b47d030b6730fbec222fd110da2b89cc5"
  },
  "expected": [
    "query filters names",
    "reset restores first page"
  ],
  "observations": [
    {
      "path": "qa/ui/recordings/tester/events/action-1/response.json",
      "sha256": "f1ad6918807dfc58aa6f2f7d763bdf889328542e2c1b1eba02a6933bf61900c8"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-6/response.json",
      "sha256": "67f6e82887ac066d911777851d36f78a9533d1b5b2dc0b3340f4122605c1670d"
    }
  ],
  "locators": {
    "query": "getByRole('textbox', { name: 'Query' })",
    "search": "getByRole('button', { name: 'Search' })"
  },
  "gaps": [
    "Reset not observed yet"
  ]
}