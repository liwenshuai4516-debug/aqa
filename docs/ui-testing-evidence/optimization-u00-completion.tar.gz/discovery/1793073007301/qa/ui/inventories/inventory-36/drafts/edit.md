{
  "feature": "edit",
  "scenario": "edit-declared",
  "states": [
    "dialog open",
    "filled then cancelled",
    "saved once",
    "one persisted name after reload"
  ],
  "source": {
    "path": "qa/ui/scopes/declaration/fixture.mjs",
    "sha256": "f07cad393d22c4629c771ef7763de96b47d030b6730fbec222fd110da2b89cc5"
  },
  "expected": [
    "dialog opens and cancels without writes",
    "saved name survives reload"
  ],
  "observations": [
    {
      "path": "qa/ui/recordings/tester/events/action-12/response.json",
      "sha256": "6da423258bceab0acae9cd1ed47acd3af754e9c911892c12db13335885c65418"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-17/response.json",
      "sha256": "aa7e09a59643622d0fd2eb8cecf7f214e71bfaf19d10542071a050b47e6fb60e"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-19/response.json",
      "sha256": "680894c78ab7964931e65e74902f6ae5396f75dd351e4340bff3a2c3461bd828"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-24/response.json",
      "sha256": "bb3692604c6d5fc6ad0bf8cff55673f15510e7f9020cd1200e33a1397881616f"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-27/response.json",
      "sha256": "f161e6bb38c38a96decb7679fd3600f22d40912608dd2f07251096b81f094056"
    }
  ],
  "locators": {
    "query": "getByRole('textbox', { name: 'Query' })",
    "search": "getByRole('button', { name: 'Search' })",
    "reset": "getByRole('button', { name: 'Reset' })",
    "add": "getByRole('button', { name: 'Add' })",
    "name": "getByRole('textbox', { name: 'Name' })",
    "cancel": "getByRole('button', { name: 'Cancel' })",
    "save": "getByRole('button', { name: 'Save' })"
  },
  "gaps": []
}