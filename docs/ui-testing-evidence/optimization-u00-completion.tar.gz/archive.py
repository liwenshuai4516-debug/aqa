import json, hashlib, tarfile, shutil, time
from pathlib import Path

repo=Path.cwd(); base=repo/'tests/scratch/ui-u00-completion'; stage=base/('archive-stage-'+str(time.time_ns()))
assert not stage.exists(), 'Use a new stage; never erase evidence'
stage.mkdir()
def digest(data): return hashlib.sha256(data).hexdigest()
def load(path): return json.loads(path.read_text())
def put(src, dst):
 dst=stage/dst; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst)
def tree(src,dst):
 for p in sorted(src.rglob('*')):
  if p.is_file() and not p.is_symlink(): put(p,Path(dst)/p.relative_to(src))

fresh=['1793072652236','1793072833077','1793072875594','1793073007301']
for name in fresh: tree(repo/'tests/scratch/ui-browser-candidate'/name,Path('discovery')/name)
failed=['u00-failed-1793073058234','u00-failed-1793073281480']
for name in failed: tree(repo/'tests/scratch/ui-failed-baseline'/name,Path('failure')/name)
reg=repo/'tests/scratch/ui-approved-baseline/1793073346898'
tree(reg,'regression')
for name in ['1793073052318','1793073381923']:
 src=repo/'tests/scratch/ui-catalog-paired'/name
 tree(src,Path('paired')/name)
 # The immutable before package already exists in Git; do not duplicate extraction.
 assert not any((stage/'paired'/name/'before').glob('**/node_modules'))
for src in ['tests/ui-function-discovery-test.mjs','tests/lib/ui-baseline-design-review.mjs','tests/lib/ui-discovery-measure.mjs','tests/lib/ui-baseline-child-observer.mjs','tests/ui-failed-batch-baseline.mjs','tests/ui-approved-baseline-measure.mjs','tests/ui-catalog-paired-benchmark.mjs','tests/ui-catalog-read-benchmark.mjs','tests/fixtures/data-space/ui-optimization-page.mjs']:
 put(repo/src,Path('sources')/src)
for p in base.glob('*.log'):
 if not p.name.startswith('archive-'): put(p,Path('checks')/p.name)
put(base/'authorized-review-budget.json','budget.json')
put(base/'catalog-current-preflight.json','catalog-current-preflight.json')
put(base/'archive.py','archive.py')
put(repo/'docs/ui-testing-u00-baseline-comparison.md','report.md')

# Resolve real immutable references; historical lineage stays linked to its indexed archive.
prior={}
for p in sorted((repo/'docs/ui-testing-evidence').glob('*.json')):
 try: index=load(p)
 except (ValueError,UnicodeError): continue
 lists=[index.get('files',[])]
 if isinstance(index.get('archive'),dict): lists.append(index['archive'].get('files',[]))
 entries=[e for group in lists if isinstance(group,list) for e in group]
 for entry in entries:
  if isinstance(entry,dict) and 'path' in entry and 'sha256' in entry: prior.setdefault(entry['sha256'],{'index':str(p.relative_to(repo)),'member':entry['path']})

def refs(value):
 if isinstance(value,dict):
  if isinstance(value.get('path'),str) and value['path'].startswith('qa/') and isinstance(value.get('sha256'),str): yield value
  for v in value.values(): yield from refs(v)
 elif isinstance(value,list):
  for v in value: yield from refs(v)

shared=repo/'tests/scratch/ui-browser-candidate/1792809587795'
roots=[(repo/'tests/scratch/ui-browser-candidate'/n,Path('discovery')/n) for n in fresh]
roots += [(shared,Path('shared-project'))]
verified=[];lineage=[];transient=[]; seen=set();queue=[]
for root,prefix in roots:
 if root==shared:
  for n in failed:
   queue += [(p,root,prefix) for p in (stage/'failure'/n).rglob('*.json')]
  queue += [(p,root,prefix) for p in (stage/'regression').rglob('*.json')]
 else: queue += [(p,root,prefix) for p in (stage/prefix).rglob('*.json')]
while queue:
 p,root,prefix=queue.pop()
 key=(str(p),str(root))
 if key in seen: continue
 seen.add(key)
 try: data=load(p)
 except (ValueError,UnicodeError): continue
 for ref in refs(data):
  src=root/ref['path']; dest=stage/prefix/ref['path']
  if src.is_file() and digest(src.read_bytes())==ref['sha256']:
   if not dest.exists():
    put(src,prefix/ref['path'])
    if dest.suffix=='.json': queue.append((dest,root,prefix))
   else: assert digest(dest.read_bytes())==ref['sha256']
   verified.append({'path':str(prefix/ref['path']),'sha256':ref['sha256']})
  elif ref['sha256'] in prior:
   lineage.append({'ref':ref,**prior[ref['sha256']]})
  elif ref['path'].startswith('qa/ui/tasks/'):
   transient.append({'ref':ref,'reason':'Historical task FileRef differs from the retained current task; not an immutable evidence reference'})
  else: raise AssertionError('Missing immutable reference '+str(ref))

# Keep only benchmark records; worker corpus and dependency extraction are reconstructible.
for name in ['1793073052318','1793073381923']:
 extracted=stage/'paired'/name/'before'
 if extracted.exists(): shutil.rmtree(extracted)
 packed=stage/'paired'/name/'before.tgz'
 if packed.exists(): packed.unlink()

for item in {x['ref']['sha256']:x for x in lineage}.values():
 ix=load(repo/item['index']); meta=ix['archive']; ap=repo/'docs/ui-testing-evidence'/meta['path']
 assert digest(ap.read_bytes())==meta['sha256']
 with tarfile.open(ap) as existing: assert digest(existing.extractfile(item['member']).read())==item['ref']['sha256']

check={'verified':verified,'historicalLineage':lineage,'mutableTaskReferences':transient,'missingImmutableReferences':[]}
(stage/'reference-check.json').write_text(json.dumps(check,ensure_ascii=False,indent=2)+'\n')
archive=repo/'docs/ui-testing-evidence/optimization-u00-completion.tar.gz'
with tarfile.open(archive,'w:gz') as output:
 for p in sorted(stage.rglob('*')):
  if p.is_file(): output.add(p,arcname=str(p.relative_to(stage)),recursive=False)
files=[]
with tarfile.open(archive) as source:
 for item in source.getmembers():
  data=source.extractfile(item).read(); assert data==(stage/item.name).read_bytes()
  files.append({'path':item.name,'bytes':len(data),'sha256':digest(data)})
f=load(repo/'tests/scratch/ui-browser-candidate/1793073007301/result.json')
m=load(repo/'tests/scratch/ui-browser-candidate/1793073007301/measurement.json')
r=load(reg/'result.json'); failure=load(repo/'tests/scratch/ui-failed-baseline/u00-failed-1793073281480/result.json')
pair=load(repo/'tests/scratch/ui-catalog-paired/1793073381923/result.json'); budget=load(base/'authorized-review-budget.json')
index={'schema_version':'1.0','date':'2026-10-27','status':'ENGINEERING_BASELINES_AND_CURRENT_QUERY_PAIRS_RECORDED','fullPlanComplete':False,
 'nativeVersion':'0.1.18','hostStartCommit':'a2080bcda46df872eff124431606d2474d04de3c',
 'discovery':{'status':f['status'],'recordingRef':f['recordingRef'],'assetRef':f['assetRef'],'independentReviewRef':f['independentReviewRef'],'milestones':m['milestones'],'actions':f['actions'],'counts':f['counts'],'modelWaitMs':f['providerElapsedMs'],'toolCallsToApproval':next(i+1 for i,x in enumerate(m['invocations']) if x['tool']=='ui_design_review'),'allHarnessToolCalls':len(m['invocations'])},
 'regression':{'status':r['status'],'runRef':r['execution']['run_ref'],'counts':r['results']['data']['counts'],'samples':[{k:v for k,v in s.items() if k!='files'} for s in r['samples']],'nestedRunnerBrowserStarts':r['nestedBrowserStarts'],'hostPlaywrightApi':r['hostPlaywrightApi'],'childProcesses':r['childProcesses']},
 'failureRecovery':{'status':failure['status'],'continuousMs':failure['failedAnalysisToRerunReportMs'],'parentRunRef':failure['parent']['run_ref'],'parentCounts':failure['parentResults']['data']['counts'],'rerunRunRef':failure['rerun']['run_ref'],'rerunCounts':failure['rerunResults']['data']['counts'],'analysisChildStarts':len(failure['analysisMeasurement']['directChildren']),'independentResultReview':'not-performed-new-candidates-remain-blocked'},
 'comparison':{'status':pair['status'],'plan':pair['plan'],'workers':len(pair['workers']),'queries':sum(len(w['data']['samples']) for w in pair['workers']),'comparisons':pair['comparisons'],'browserStarts':0,'modelCalls':0},
 'authorization':{'id':budget['authorization'],'calls':len(budget['attempts']),'maxCalls':3,'reservedCostUpperBoundUsd':sum(a['reservedUsd'] for a in budget['attempts']),'maxCostUsd':1,'decisions':['revise','revise','approved'],'notSupplierBill':True},
 'preservedEarlierAttempts':{'discoveryRejected':['1793072652236','1793072875594'],'permissionFailureBeforeBrowser':'1793072833077','preparatoryDiagnosticsAndRecovery':'u00-failed-1793073058234','firstCurrentPairedSet':'1793073052318','firstReceiptModelCallsCorrection':{'receiptUnchanged':True,'receiptValue':0,'ledgerDerivedActualCalls':1}},
 'referenceVerification':{'verifiedCount':len(verified),'historicalLineageCount':len(lineage),'mutableTaskReferenceCount':len(transient),'missingImmutableReferences':0,'archiveReadback':'passed'},
 'limits':['Deterministic SDK/MCP harness, not outer model autonomous planning or Electron cold startup','Warm dependency/filesystem caches; observer overhead included','Fresh discovery and failed-batch nested browser APIs unmeasured; regression APIs measured separately','No full-workflow before/after pairs or U03/U07 benefit claim; original 20 percent goal not achieved or lowered','New failure/rerun reports are candidates without independent result review','No PMS/Electron rerun this round; prior real-business result-review blockers remain'],
 'archive':{'path':archive.name,'sha256':digest(archive.read_bytes()),'bytes':archive.stat().st_size,'files':files}}
(repo/'docs/ui-testing-evidence/optimization-u00-completion.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'archiveBytes':archive.stat().st_size,'files':len(files),'verified':len(verified),'lineage':len(lineage),'mutableTasks':len(transient)},ensure_ascii=False))
