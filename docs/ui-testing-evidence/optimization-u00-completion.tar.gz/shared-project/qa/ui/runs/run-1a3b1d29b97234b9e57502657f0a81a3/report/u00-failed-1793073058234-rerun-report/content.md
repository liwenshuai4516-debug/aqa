# UI 测试结果

范围：All frozen assertions evidenced or explicitly blocked.

批次：run-1a3b1d29b97234b9e57502657f0a81a3；部署：u00-1；角色：tester and viewer in separate contexts

冻结计划：1；实际启动：1；稳定通过率：100.00%

| 状态 | 实例数 |
|---|---:|
| passed | 1 |
| failed | 0 |
| blocked | 0 |
| skipped | 0 |
| cancelled | 0 |
| not-run | 0 |
| flaky | 0 |
| unknown | 0 |

原始结果：[qa/ui/runs/run-1a3b1d29b97234b9e57502657f0a81a3/report.json](../../report.json)

确定性对账与证据状态：[qa/ui/runs/run-1a3b1d29b97234b9e57502657f0a81a3/results/u00-failed-1793073058234-rerun-results/reconciliation.json](../../results/u00-failed-1793073058234-rerun-results/reconciliation.json)

设计评估（仅本批次资产修订）：候选用例 6；通过 6；待修订 0；阻塞 0；结论 approved。

已登记功能清单：6；清单内尚无用例的功能点：无。

未探索范围（不计入上述清单分母）：Other products and undeclared roles。

功能覆盖：冻结用例涉及 6 个功能点，其中 1 个获得执行结论；不代表全产品覆盖。

## 模块、功能与优先级统计

```json
{
  "by_module": {
    "names": {
      "passed": 1,
      "failed": 0,
      "blocked": 0,
      "skipped": 0,
      "cancelled": 0,
      "not-run": 0,
      "flaky": 0,
      "unknown": 0
    }
  },
  "by_feature": {
    "names/edit": {
      "passed": 1,
      "failed": 0,
      "blocked": 0,
      "skipped": 0,
      "cancelled": 0,
      "not-run": 0,
      "flaky": 0,
      "unknown": 0
    }
  },
  "by_priority": {
    "P0": {
      "passed": 1,
      "failed": 0,
      "blocked": 0,
      "skipped": 0,
      "cancelled": 0,
      "not-run": 0,
      "flaky": 0,
      "unknown": 0
    }
  },
  "by_oracle": {
    "requirement": [],
    "declaration": [
      "instance-a523bb3f36aa0ea9cb84e7996f857270"
    ],
    "baseline": []
  }
}
```

## 观察、解释与下一动作

## 数据清理与残留

```json
[
  {
    "instance_id": "instance-a523bb3f36aa0ea9cb84e7996f857270",
    "cleanup": [],
    "evidence_gaps": []
  }
]
```

## 限制与待处理事项

- 范围仅限冻结计划，不代表全产品或代码覆盖率；attempt 与 case 分开统计
- 本批次是父批次 run-c8211929b02748665852fa11ac18ccfa 的续跑/重跑；只报告本次选择集合，不能用子集通过替换原失败或宣称原全量通过；不同部署版本不合并。
- 候选与设计评估数量仅统计本批次资产修订；不推断其他候选或历史轮次。未登记的信息为不可用，不填零
- 未探索：Other products and undeclared roles
- Candidate synthesis is not execution: seed/browser observations support discovery; all thirteen script assertions require independent review and diagnostics.
- Candidate synthesis is not execution: seed/browser observations support discovery; all thirteen script assertions require independent review and diagnostics.
- 14 probes/13 assertions are HTTP/static preparation only; no trusted review, diagnostic observation or runtime admission. All owned servers stopped.

失败处理：产品问题仅形成待确认缺陷草稿；脚本问题新建修订并重审；环境/数据恢复后新批次执行；证据不足先补证据，不修改历史结果。

后续处理草稿：[缺陷与回归建议](follow-up.json)；未向外部系统提交。
