# UI 测试结果

范围：All frozen assertions evidenced or explicitly blocked.

批次：run-c8211929b02748665852fa11ac18ccfa；部署：u00-1；角色：tester and viewer in separate contexts

冻结计划：6；实际启动：6；稳定通过率：83.33%

| 状态 | 实例数 |
|---|---:|
| passed | 5 |
| failed | 1 |
| blocked | 0 |
| skipped | 0 |
| cancelled | 0 |
| not-run | 0 |
| flaky | 0 |
| unknown | 0 |

原始结果：[qa/ui/runs/run-c8211929b02748665852fa11ac18ccfa/report.json](../../report.json)

确定性对账与证据状态：[qa/ui/runs/run-c8211929b02748665852fa11ac18ccfa/results/u00-failed-1793073058234-results/reconciliation.json](../../results/u00-failed-1793073058234-results/reconciliation.json)

设计评估（仅本批次资产修订）：候选用例 6；通过 6；待修订 0；阻塞 0；结论 approved。

已登记功能清单：6；清单内尚无用例的功能点：无。

未探索范围（不计入上述清单分母）：Other products and undeclared roles。

功能覆盖：冻结用例涉及 6 个功能点，其中 6 个获得执行结论；不代表全产品覆盖。

## 模块、功能与优先级统计

```json
{
  "by_module": {
    "names": {
      "passed": 5,
      "failed": 1,
      "blocked": 0,
      "skipped": 0,
      "cancelled": 0,
      "not-run": 0,
      "flaky": 0,
      "unknown": 0
    }
  },
  "by_feature": {
    "names/search": {
      "passed": 1,
      "failed": 0,
      "blocked": 0,
      "skipped": 0,
      "cancelled": 0,
      "not-run": 0,
      "flaky": 0,
      "unknown": 0
    },
    "names/edit": {
      "passed": 0,
      "failed": 1,
      "blocked": 0,
      "skipped": 0,
      "cancelled": 0,
      "not-run": 0,
      "flaky": 0,
      "unknown": 0
    },
    "names/details": {
      "passed": 1,
      "failed": 0,
      "blocked": 0,
      "skipped": 0,
      "cancelled": 0,
      "not-run": 0,
      "flaky": 0,
      "unknown": 0
    },
    "names/paging": {
      "passed": 1,
      "failed": 0,
      "blocked": 0,
      "skipped": 0,
      "cancelled": 0,
      "not-run": 0,
      "flaky": 0,
      "unknown": 0
    },
    "names/permission": {
      "passed": 1,
      "failed": 0,
      "blocked": 0,
      "skipped": 0,
      "cancelled": 0,
      "not-run": 0,
      "flaky": 0,
      "unknown": 0
    },
    "names/states": {
      "passed": 1,
      "failed": 0,
      "blocked": 0,
      "skipped": 0,
      "cancelled": 0,
      "not-run": 0,
      "flaky": 0,
      "unknown": 0
    }
  },
  "by_priority": {
    "P0": {
      "passed": 5,
      "failed": 1,
      "blocked": 0,
      "skipped": 0,
      "cancelled": 0,
      "not-run": 0,
      "flaky": 0,
      "unknown": 0
    }
  },
  "by_oracle": {
    "requirement": [],
    "declaration": [
      "instance-3676c8b6dd7f5d14900d8ab444ba18a7",
      "instance-a523bb3f36aa0ea9cb84e7996f857270",
      "instance-2f4bd473beddd0519837fb76b7d2f00c",
      "instance-59613436ac54f4165bf739dbe7a2a33b",
      "instance-303d072eb55c2632d3ba7a41676f94ab",
      "instance-2487f9659a29078bc38ed50f720d019b"
    ],
    "baseline": []
  }
}
```

## 观察、解释与下一动作

### instance-a523bb3f36aa0ea9cb84e7996f857270（insufficient-evidence / unknown）

- 观察事实：C-edit failed at A-edit-2: getByRole(listitem) expected [U05-owned-item], received [], timeout 5000ms after save/reload/search. Five other cases passed; thirteen assertion steps were reached, not all passed.
- 观察事实：The native failure trace belongs to this failed instance/attempt. Scope is synthetic client persistence behavior; this is not evidence of an OperationContract defect.
- 候选解释：The harness intends a controlled response variant, but runtime response identity is unverified by the supplied native evidence. Persistence loss is a hypothesis; no product/server/database cause is established.
- 替代解释/缺口：Browser behavior alone does not establish an underlying storage or server implementation cause.
- 下一验证动作：Restore the declared positive fixture and freeze a new failed-only batch from initial state; preserve the parent failure and do not infer full-plan success from the subset.
- 证据：[qa/ui/runs/run-c8211929b02748665852fa11ac18ccfa/output/qa-ui-assets-u05-browser-c-4a496-t-Cancel-and-persisted-save-chromium/trace.zip](../../output/qa-ui-assets-u05-browser-c-4a496-t-Cancel-and-persisted-save-chromium/trace.zip)
- 证据：[qa/ui/runs/run-c8211929b02748665852fa11ac18ccfa/report.json](../../report.json)

## 数据清理与残留

```json
[
  {
    "instance_id": "instance-3676c8b6dd7f5d14900d8ab444ba18a7",
    "cleanup": [],
    "evidence_gaps": []
  },
  {
    "instance_id": "instance-a523bb3f36aa0ea9cb84e7996f857270",
    "cleanup": [],
    "evidence_gaps": []
  },
  {
    "instance_id": "instance-2f4bd473beddd0519837fb76b7d2f00c",
    "cleanup": [],
    "evidence_gaps": []
  },
  {
    "instance_id": "instance-59613436ac54f4165bf739dbe7a2a33b",
    "cleanup": [],
    "evidence_gaps": []
  },
  {
    "instance_id": "instance-303d072eb55c2632d3ba7a41676f94ab",
    "cleanup": [],
    "evidence_gaps": []
  },
  {
    "instance_id": "instance-2487f9659a29078bc38ed50f720d019b",
    "cleanup": [],
    "evidence_gaps": []
  }
]
```

## 限制与待处理事项

- 范围仅限冻结计划，不代表全产品或代码覆盖率；attempt 与 case 分开统计
- 候选与设计评估数量仅统计本批次资产修订；不推断其他候选或历史轮次。未登记的信息为不可用，不填零
- 未探索：Other products and undeclared roles
- Candidate synthesis is not execution: seed/browser observations support discovery; all thirteen script assertions require independent review and diagnostics.
- Candidate synthesis is not execution: seed/browser observations support discovery; all thirteen script assertions require independent review and diagnostics.
- 14 probes/13 assertions are HTTP/static preparation only; no trusted review, diagnostic observation or runtime admission. All owned servers stopped.
- instance-a523bb3f36aa0ea9cb84e7996f857270：原因仍未知，未假定已修复或已提交缺陷

失败处理：产品问题仅形成待确认缺陷草稿；脚本问题新建修订并重审；环境/数据恢复后新批次执行；证据不足先补证据，不修改历史结果。

后续处理草稿：[缺陷与回归建议](follow-up.json)；未向外部系统提交。
