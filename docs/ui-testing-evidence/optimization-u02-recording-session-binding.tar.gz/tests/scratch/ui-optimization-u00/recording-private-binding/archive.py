from pathlib import Path
import hashlib,json,tarfile,io,base64
repo=Path.cwd();root=repo/'tests/scratch/ui-optimization-u00/recording-private-binding';export=repo/'tests/scratch/ui-optimization-u00/u02-recording-binding-final-export'
sha=lambda b:hashlib.sha256(b).hexdigest()
manifest=json.loads((export/'bundle-manifest.json').read_text());assert manifest['source_commit']=='c473a606323c8f3ac40341fe2ee263f6403031c5'
package=repo/'.pi/skills/ui-testing-workflow/assets/pi-ui-testing-0.1.15.tgz';b=package.read_bytes();assert sha(b)==manifest['files']['assets/pi-ui-testing-0.1.15.tgz']
lock=json.loads((repo/'tools/e2e/package-lock.json').read_text());assert lock['packages']['node_modules/pi-ui-testing']['integrity']=='sha512-'+base64.b64encode(hashlib.sha512(b).digest()).decode()
assert (repo/'node_modules/pi-ui-testing/src/recording.ts').read_bytes()==(export/'assets/runtime/src/recording.ts').read_bytes()
assert 'Tests  35 passed' in (root/'unit-serial.log').read_text()
assert 'ℹ pass 5' in (root/'native-binding-final.log').read_text()
sdk=json.loads((root/'sdk.log').read_text());assert sdk['status']=='passed';assert sdk['actualModelCalls']==sdk['businessRequests']==0
assert any('native SDK private session' in x for x in sdk['checks'])
desktop=json.loads((root/'desktop.log').read_text());assert desktop['status']=='PASS';assert desktop['actualModelCalls']==desktop['businessRequests']==0
files={str(p.relative_to(repo)):p.read_bytes() for p in root.iterdir() if p.is_file()}
for n in ['packages/ui-testing/src/recording.ts','tests/ui-testing/recording-private-binding.test.mjs','packages/ui-testing/skills/ui-discover-record/references/start.md','packages/ui-testing/package.json','tsconfig.json']:
 p=root/n;files[str(p.relative_to(repo))]=p.read_bytes()
for n in ['bundle-manifest.json','assets/runtime/src/recording.ts','assets/runtime/skills/ui-discover-record/references/start.md']:
 p=export/n;files[str(p.relative_to(repo))]=p.read_bytes()
for n in ['.pi/skills/ui-testing-workflow/assets/private-recording-session.mjs','.pi/skills/ui-testing-workflow/references/maintenance.md','tests/unit/ui-private-recording-workspace.test.ts','tests/ui-testing-integration-test.mjs','tools/e2e/package.json','tools/e2e/package-lock.json','docs/ui-testing-optimization-execution.md','docs/ui-testing-optimization-plan.md']:
 files[n]=(repo/n).read_bytes()
for p in Path(desktop['evidence']).rglob('*'):
 assert not p.is_symlink()
 if p.is_file():files[str(p.relative_to(repo))]=p.read_bytes()
ledgers={n:sha((root.parent/n).read_bytes()) for n in ['u05-authorized-review-budget.json','pms-anonymous-authorized-review-budget.json']}
assert ledgers==json.loads((repo/'docs/ui-testing-evidence/optimization-u02-recording-product-preflight.json').read_text())['ledgerSha256']
archive=repo/'docs/ui-testing-evidence/optimization-u02-recording-session-binding.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for n,b in sorted(files.items()):
  x=tarfile.TarInfo(n);x.size=len(b);x.mode=0o600;t.addfile(x,io.BytesIO(b))
with tarfile.open(archive,'r:gz') as t:
 for x in t.getmembers():assert t.extractfile(x).read()==files[x.name]
index={'schema_version':'1.0','stage':'U02 native private session binding and host preparation','status':'INTERNAL_NATIVE_TO_HOST_PASSED_PRODUCT_RECORDING_NOT_CONNECTED','planComplete':False,'nativeVersion':'0.1.15','nativeCommit':manifest['source_commit'],'nativePushed':False,'packageSha256':sha(package.read_bytes()),'modelCalls':0,'formalRuns':0,'businessWrites':0,'newNativeTestsPassed':5,'unit':{'files':4,'passed':35,'earlierFailuresRetained':True},'sdk':'passed','electron':'PASS','ledgerSha256':ledgers,'archive':{'path':str(archive.relative_to(repo)),'sha256':sha(archive.read_bytes()),'files':len(files)},'files':{n:sha(b) for n,b in sorted(files.items())},'limits':['explicit input set does not prove arbitrary dependency closure','product MCP capture/filter path not connected','not real PMS private recording','no full reconnect/resume or frame/target support acceptance','document files require application indexing before UI list claim']}
archive.with_suffix('').with_suffix('.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'files':len(files),'archiveSha256':sha(archive.read_bytes()),'packageSha256':index['packageSha256'],'desktopEvidence':desktop['evidence']},ensure_ascii=False))
