from pathlib import Path
import hashlib,json,tarfile,io,os,shutil
repo=Path.cwd();root=repo/'tests/scratch/ui-pms-anonymous-diagnostics/1792990404494';logs=repo/'tests/scratch/ui-optimization-u00';sha=lambda b:hashlib.sha256(b).hexdigest()
ledger=json.loads((logs/'pms-anonymous-authorized-review-budget.json').read_text());review=json.loads((root/'pms-anonymous-design-1.json').read_text());diagnostic=json.loads((root/'native-diagnostic-1.json').read_text());formal=json.loads((root/'pms-anonymous-formal-1.json').read_text());candidate=json.loads((root/'pms-anonymous-report-candidate-v2.json').read_text());task=json.loads((root/'pms-report-2-workflow.json').read_text());check=json.loads((root/'pms-report-2-static-check.json').read_text())
assert review['response']['output']['decision']=='approved' and diagnostic['response']['output']['runtime_ready']
assert formal['results']['data']['counts']['failed']==1 and formal['results']['data']['counts']['passed']==0 and formal['results']['details']['complete']
assert candidate['report']['review_status']=='not-reviewed' and check['check']['issues']==[] and task['task']['data']['stage']=='result-review' and task['task']['data']['state']!='completed'
assert len(ledger['attempts'])==len(ledger['native_attempts'])==1 and ledger['attempts'][0]['status']!='started'
old=sha((logs/'u05-authorized-review-budget.json').read_bytes());assert old==json.loads((repo/'docs/ui-testing-evidence/optimization-u02-recording-lifecycle.json').read_text())['modelReviewLedgerSha256']
verified=0;mutable_refs=[]
def walk(v,source):
 global verified
 if isinstance(v,dict):
  if isinstance(v.get('path'),str) and isinstance(v.get('sha256'),str):
   p=Path(v['path']);assert not p.is_absolute() and '..' not in p.parts,(source,p)
   if str(p).startswith('qa/ui/tasks/'):
    mutable_refs.append({'source':source,'ref':v,'currentMatches':(root/p).exists() and sha((root/p).read_bytes())==v['sha256']})
   else:assert sha((root/p).read_bytes())==v['sha256'],(source,p);verified+=1
  for x in v.values():walk(x,source)
 elif isinstance(v,list):
  for x in v:walk(x,source)
for p in (root/'qa').rglob('*.json'):walk(json.loads(p.read_text()),str(p.relative_to(root)))
for name in ['pms-anonymous-design-1.json','native-diagnostic-1.json','pms-anonymous-formal-1.json','pms-anonymous-report-candidate-v2.json']:walk(json.loads((root/name).read_text()),name)
source_names=['review-pms-anonymous.mjs','diagnose-pms-anonymous.mjs','run-pms-anonymous.mjs','analyze-pms-anonymous.mjs','analyze-pms-anonymous-v2.mjs','check-pms-report.mjs','archive-pms-reviewed.py','pms-anonymous-authorized-review-budget.json','pms-anonymous-review1.log','pms-anonymous-review1-v2.log','pms-anonymous-diagnostic-1.log','pms-anonymous-formal-1.log','pms-anonymous-analysis-1.log','pms-anonymous-analysis-2.log','pms-report-2-check.log']
root_names=['result.json','pms-anonymous-design-1.json','review-mcp-tools.json','native-diagnostic-1.json','diagnostic-harness.mjs','pms-anonymous-formal-1.json','formal-harness.mjs','formal-failure-trace.json','formal-failure-trace-v2.json','pms-anonymous-report-candidate.json','pms-anonymous-report-candidate-v2.json','analysis-harness.mjs','analysis-harness-v2.mjs','pms-report-2-static-check.json','pms-report-2-workflow.json','package.json','playwright.config.mjs']
files={}
for p in (root/'qa').rglob('*'):
 if p.is_file():assert not p.is_symlink();files[str(p.relative_to(repo))]=p.read_bytes()
for n in root_names:
 p=root/n;files[str(p.relative_to(repo))]=p.read_bytes()
for n in source_names:
 p=logs/n;files[str(p.relative_to(repo))]=p.read_bytes()
text='''# 项目管理系统：匿名入口基线正式失败报告候选

日期：2026-10-26。权威项目为Electron桌面数据空间“项目管理系统”；本轮浏览器使用项目所选环境的真实PMS站点，目标/pms/OperationContract，角色anonymous。只允许空context的同源GET/HEAD，无账号密码或私有state，无业务写入；不是认证后的经营合同功能验收，也不是Electron Agent全链验收。

冻结v2资产1场景、1断言，单独新授权gpt/gpt-6.1-sol独立D1–D10设计评审最多3次、每次8192输出tokens、合计1美元。实际第1轮由原生ui_design_review创建独立无工具Agent，D1–D10全部pass，原生批准已登记；使用1/3次、保守费用预留0.044977333美元。供应商usage cost字段为0源于配置价格为0，不能解读为实际免费；保守预留独立控制预算，旧U05额度不变。剩余2次用途仍为设计评审，未经授权不用于结果评审。

首次准备工作流因为只登记阶段工具、没有实际MCP工具而阻塞，未调用模型。保留错误日志；随后连接真实Playwright1.62.1 MCP、listTools验证所需能力并原任务resume/checkpoint，不伪造工具名可用或换任务清零。MCP列表检查没有启动浏览器动作，评审结束自有连接关闭。

原生正反诊断：真实匿名目标断言通过；冻结本机18982错误副本返回登录控件但故意省略/pms/OperationContract到/login跳转，同一不变断言正确检出。原生runtime_ready=true，所有证据引用完整；仅停止本次自有错误副本进程，真实服务未改动。

随后独立正式批次run-46c4dbe44703b9e4abb97a2735a39608再次预检并从空context执行：冻结1、启动1、passed0、failed1，其余状态0、零重试、关键断言到达、原生对账complete。执行completed不等于测试通过。错误消息记录URL仍为/pms/OperationContract，未满足同源/login行为基线，原始失败和此前诊断通过分别保留，不自动重跑或改预期/超时。

原生ui_result_analysis读取本次trace：test.trace expect@63从2173.834到2231.783约57.949ms，导航等待同时出现frame.waitForURL: net::ERR_ABORTED; maybe frame was detached?。错误文字Timeout:3000ms是配置上限，不代表实际等待3秒。失败快照可见密码认证/登录控件，但与URL错误消息不必同时，不能用内容可见替代URL断言或推断服务端/数据库根因。

分析分类insufficient-evidence/certainty unknown。第一版analysis-1/report-1误写“failed after 3000ms”，保留为已替代草稿；当前analysis-2/report-2已修正并明确导航中断事实，原始run/结果/断言没有修改。当前报告原生静态检查issues=[]、证据完整，但尚无R1–R6独立批准；工作流停留result-review/running，最终交付未完成。报告中继承的asset/cases pre-review gaps为冻结时历史文字，实际当前设计/诊断状态以原生批准、runtime_ready与run回执为准，未倒写旧资产。

下一步：申请在现有预算内将1次剩余设计调用改用于当前报告独立结果评审；保留另1次设计额度，不新增次数/总费用。与此同时可继续对比正式失败与正向诊断的部署/路由证据。没有确定触发条件前不自动重播真实浏览器，不扩大为业务权限缺陷。

资料保存为项目文档及同目录anonymous-native-2026-10-26公开快照（qa保持原相对布局、私有批准目录/模型缓存/凭据/依赖不复制），文件0600/目录0700并回读。store.json未修改，应用没有文档列表索引，不声明已显示或正式结果入库。原库3条源码草稿保持未评审/未绑定/未执行。U00连续完整基线、产品私密录制、真实角色/租户/数据、Electron完整链、U03/U07和M1/M2仍未完成。
'''
docdir=Path.home()/'Library/Application Support/Pi Agent Desktop/data/data-space/project-documents/e2f5d42d-2781-4e68-a452-4c87c7d1d346';store=docdir.parent.parent/'store.json';before=store.read_bytes();snapshot=docdir/'anonymous-native-2026-10-26';snapshot.mkdir(mode=0o700)
for n,b in files.items():
 p=Path(n);relative=p.relative_to(root.relative_to(repo)) if p.is_relative_to(root.relative_to(repo)) else Path('harness')/p.name
 target=snapshot/relative;target.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
 with target.open('xb') as f:f.write(b)
 os.chmod(target,0o600);assert target.read_bytes()==b
for p in snapshot.rglob('*'):
 if p.is_dir():os.chmod(p,0o700)
doc=docdir/'OperationContract-anonymous-failed-report-candidate-2026-10-26.md'
with doc.open('x') as f:f.write(text)
os.chmod(doc,0o600);assert doc.read_text()==text and store.read_bytes()==before
report=json.loads((root/candidate['report']['report_ref']['path']).read_text());native_report=root/report['data']['content_ref']['path'];copy=docdir/'OperationContract-anonymous-native-report-2-2026-10-26.md'
with copy.open('xb') as f:f.write(native_report.read_bytes())
os.chmod(copy,0o600);assert copy.read_bytes()==native_report.read_bytes()
archive=repo/'docs/ui-testing-evidence/optimization-u00-pms-anonymous-reviewed.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for n,b in sorted(files.items()):m=tarfile.TarInfo(n);m.size=len(b);m.mtime=0;t.addfile(m,io.BytesIO(b))
with tarfile.open(archive) as t:
 assert set(t.getnames())==set(files)
 for m in t:assert t.extractfile(m).read()==files[m.name]
index={'date':'2026-10-26','status':'DESIGN_APPROVED_DIAGNOSTIC_VALIDATED_FORMAL_ONE_FAILED_REPORT2_PENDING_INDEPENDENT_REVIEW','plan_complete':False,'candidate':ledger['asset_ref'],'review':review,'diagnostic':diagnostic,'formal':formal,'reportCandidate':candidate,'workflow':{'stage':task['task']['data']['stage'],'state':task['task']['data']['state'],'task_ref':task['task_ref']},'authorization':ledger,'oldU05LedgerSha256':old,'oldU05LedgerUnchanged':True,'fileRefsVerified':verified,'historicalMutableTaskRefs':mutable_refs,'reportStaticIssues':check['check']['issues'],'timingCorrection':'Report1 incorrectly described 3000ms elapsed; retained. Report2 uses native trace 57.949ms and ERR_ABORTED, not a confirmed root cause.','documents':[{'path':str(p),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size} for p in [doc,copy]],'snapshot':{'path':str(snapshot),'files':len(files),'storeUnchanged':True},'limits':['Anonymous URL baseline only; not authenticated contract roles/tenant/data','Review/diagnostic/formal were separate from Electron Agent UI end-to-end','Formal failure retained; no automatic replay or script weakening','Report2 complete evidence but no R1-R6 independent approval; no final delivery','Frozen pre-review gaps are historical text; current state comes from native receipts','Private authority and model caches are not archived'],'archive':{'path':str(archive.relative_to(repo)),'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'files':len(files),'roundtrip_verified':True},'files':[{'path':n,'sha256':sha(b),'bytes':len(b)} for n,b in sorted(files.items())]}
(repo/'docs/ui-testing-evidence/optimization-u00-pms-anonymous-reviewed.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'files':len(files),'refs':verified,'mutableRefs':len(mutable_refs),'bytes':archive.stat().st_size,'modelCalls':len(ledger['attempts']),'report2':candidate['report']['report_ref']}))
