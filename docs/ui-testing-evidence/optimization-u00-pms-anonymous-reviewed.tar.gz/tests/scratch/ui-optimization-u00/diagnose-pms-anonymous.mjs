/** Verify the exact frozen service, without executing the candidate or diagnostic runner. */
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {once} from 'node:events';
import {readFile,writeFile,cp} from 'node:fs/promises';
import {join,dirname} from 'node:path';
import {pathToFileURL,fileURLToPath} from 'node:url';
import {existsSync} from 'node:fs';
import {ArtifactStore,sha256} from 'pi-ui-testing';
const root=join(process.cwd(),'tests/scratch/ui-pms-anonymous-diagnostics/1792990404494'),resultFile=join(root,'native-diagnostic-1.json'),request_id='pms-anonymous-diagnostic-1',base='qa/ui/assets/pms-anonymous-redirect/revisions/v2';
assert.ok(!existsSync(resultFile),'Existing request result: inspect status instead of replay');
const ledger=JSON.parse(await readFile(new URL('./pms-anonymous-authorized-review-budget.json',import.meta.url),'utf8'));
const approved=JSON.parse(await readFile(join(root,'pms-anonymous-design-1.json'),'utf8'));
assert.equal(approved.response.output.decision,'approved');
const store=new ArtifactStore(root);await store.load(ledger.asset_ref);await store.load(approved.response.output.review_ref);
const definitions=new Map(),installed=dirname(fileURLToPath(import.meta.resolve('pi-ui-testing')));
const {registerDesignTools}=await import(pathToFileURL(join(installed,'design-extension.js')).href);registerDesignTools({registerTool:t=>definitions.set(t.name,t)});
const spec=JSON.parse(await readFile(join(root,base,'diagnostic-plan.json'))),mutation=spec.probes[0].mutation_refs.find(r=>r.path.endsWith('negative-server.mjs'));
assert.equal(sha256(await readFile(join(root,mutation.path))),mutation.sha256);
const environment=JSON.parse(await readFile(join(root,base,'negative-environment.json')));
const child=spawn(process.execPath,['--input-type=module','-e',`await import(${JSON.stringify(pathToFileURL(join(root,mutation.path)).href)});await new Promise(setImmediate);console.log('SOURCE_READY');`],{stdio:['ignore','pipe','pipe']});
let stderr='',stdout='',ready=false,closed=false,preflight,response;
child.stderr.on('data',b=>{stderr+=b});
const exit=once(child,'exit');
try{
 await new Promise((ok,no)=>{
  const timer=setTimeout(()=>no(Error('Frozen service startup timeout')),10000);
  child.once('error',e=>{clearTimeout(timer);no(e)});
  child.once('exit',()=>{clearTimeout(timer);if(!ready)no(Error('Frozen service exited before ready: '+stderr))});
  child.stdout.on('data',b=>{stdout+=b;if(stdout.includes('SOURCE_READY')){ready=true;clearTimeout(timer);ok();}});
 });
 assert.equal(child.exitCode,null);
 const actual=await fetch(environment.base_url+'/pms/OperationContract',{redirect:'manual',signal:AbortSignal.timeout(5000)}),html=await actual.text();
 assert.equal(actual.status,200);assert.equal(actual.headers.get('location'),null);assert.ok(html.includes('密码认证')&&html.includes('登 录'));
 response={status:actual.status,location:actual.headers.get('location'),bodySha256:sha256(html),pathname:new URL(actual.url).pathname,baselineFaultObserved:'protected path returns 200 without redirect; candidate not executed'};
 const outcome=await definitions.get('ui_design_diagnose').execute(request_id,{request:{operation:'diagnose',asset_ref:ledger.asset_ref,review_ref:approved.response.output.review_ref,spec_ref:ledger.diagnostic_spec_ref,request_id}},new AbortController().signal,undefined,{cwd:root,sessionManager:{getSessionDir:()=>root}});
 preflight=JSON.parse(outcome.content.filter(c=>c.type==='text').map(c=>c.text).join('\n'));
 if(preflight.status!=='completed')process.exitCode=1;

}finally{
 if(child.exitCode===null)child.kill('SIGTERM');
 const [code,signal]=await exit;closed=true;
 assert.equal(code,0,'Owned frozen service did not close normally: '+stderr);assert.equal(signal,null);
}
const result={request_id,status:preflight?.status??'unknown',assetRef:ledger.asset_ref,reviewRef:approved.response.output.review_ref,specRef:ledger.diagnostic_spec_ref,response:preflight,mutationRef:mutation,wrongResultServiceProbe:response,ownedServiceReady:ready,ownedServiceClosed:closed,modelCalls:0,formalRuns:0,realTargetModified:false};
await cp(new URL(import.meta.url),join(root,'diagnostic-harness.mjs'));await writeFile(resultFile,JSON.stringify(result,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(result,null,2));
