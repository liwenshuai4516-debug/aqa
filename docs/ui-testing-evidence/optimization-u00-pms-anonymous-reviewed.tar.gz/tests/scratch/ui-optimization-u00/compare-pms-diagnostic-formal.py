from pathlib import Path
import json,hashlib,re
root=Path('tests/scratch/ui-pms-anonymous-diagnostics/1792990404494');sha=lambda b:hashlib.sha256(b).hexdigest()
d=json.loads((root/'native-diagnostic-1.json').read_text())['response']['output'];f=json.loads((root/'pms-anonymous-formal-1.json').read_text());positive=d['rounds'][0]
pr=positive['report_ref'];report=json.loads((root/pr['path']).read_text());fr=next(x for x in f['execution']['run']['data']['output_refs'] if x['path'].endswith('/input.json'));request=json.loads((root/fr['path']).read_text());pc=next(x for x in positive['evidence_refs'] if x['path'].endswith('/playwright.config.mjs'));fc=next(x for x in f['execution']['run']['data']['output_refs'] if x['path'].endswith('/playwright.config.mjs'))
parsed=[]
for ref in [pc,fc]:
 b=(root/ref['path']).read_bytes();assert sha(b)==ref['sha256'];parsed.append(json.loads(re.search(r'export default \{\.\.\.base,\.\.\.(.*),grep:undefined',b.decode()).group(1)))
same_fields=['testDir','testMatch','retries','repeatEach','workers','fullyParallel','forbidOnly','projects'];assert all(parsed[0][k]==parsed[1][k] for k in same_fields)
assert request['asset_ref']==d['asset_ref'] and request['review_ref']==d['review_ref'] and request['environment_ref']==d['environment_ref']
def traces(v):
 if isinstance(v,dict):
  if v.get('name')=='trace':yield v
  for x in v.values():yield from traces(x)
 elif isinstance(v,list):
  for x in v:yield from traces(x)
positive_traces=list(traces(report));assert positive_traces==[]
result={'status':'READ_ONLY_INPUT_COMPARISON_COMPLETE_ROOT_CAUSE_UNKNOWN','asset_ref_same':True,'review_ref_same':True,'environment_ref_same':True,'config_ref_same':request['config_ref']==json.loads((root/d['input_ref']['path']).read_text())['spec']['config_ref'] if 'spec' in json.loads((root/d['input_ref']['path']).read_text()) else 'same frozen base import observed in both generated configs','same_generated_fields':same_fields,'different_generated_fields':{k:[parsed[0][k],parsed[1][k]]for k in ['globalTimeout','outputDir','reporter']},'positive':{'report_ref':pr,'stats':report['stats'],'trace_attachments':positive_traces},'formal':{'input_ref':fr,'counts':f['results']['data']['counts'],'failedTraceRef':next(x for x in f['results']['data']['instances'][0]['attempts'][0]['evidence_refs']if x['path'].endswith('/trace.zip'))},'limitations':['Same declared deployment/environment/config does not prove identical runtime responses','Positive config retains traces only on failure; no positive trace is available for route-event comparison','Global timeout 60000 vs 120000 is recorded, not established as cause; observed formal assertion/navigation interruption was about 58ms','No extra target request, browser/model call or formal replay']}
p=root/'positive-formal-comparison.json'
with p.open('x') as o:o.write(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':result['status'],'positiveTraceAvailable':False}))
