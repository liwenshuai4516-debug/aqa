import json,hashlib,tarfile,io
from pathlib import Path
repo=Path.cwd();sha=lambda b:hashlib.sha256(b).hexdigest();files={};ref_count=0

def add(p):
 p=Path(p);assert p.is_file() and not p.is_symlink();n=str(p.relative_to(repo));assert not any(v in n.split('/') for v in ['ui-review-authority','private-reviews','private-authority','auth.json','models.json','node_modules']);files[n]=p.read_bytes()
def tree(p):
 for f in p.rglob('*'):
  if f.is_file():add(f)
prior=json.loads((repo/'docs/ui-testing-evidence/optimization-u05-approved-run.json').read_text());ledger='tests/scratch/ui-optimization-u00/u05-authorized-review-budget.json';assert sha((repo/ledger).read_bytes())==next(f['sha256'] for f in prior['files'] if f['path']==ledger)
checks=[]
for run in ['1792926220108','1792926220103']:
 out=repo/'tests/scratch/ui-private-evidence'/run;r=json.loads((out/'result.json').read_text());assert r['status']=='PASS' and r['leaks']==[] and len(r['checks'])==6
 assert r['formal']['failedCounts']['failed']==1 and r['formal']['passedEvidenceComplete'] is False and r['formal']['failedEvidenceComplete'] is False
 root=out/'public'
 def walk(v):
  global ref_count
  if isinstance(v,dict):
   if isinstance(v.get('path'),str) and isinstance(v.get('sha256'),str):
    p=root/v['path'];assert p.is_file(),str(p);assert sha(p.read_bytes())==v['sha256'],str(p);ref_count+=1
   for item in v.values():walk(item)
  elif isinstance(v,list):
   for item in v:walk(item)
 for p in (root/'qa').rglob('*.json'):walk(json.loads(p.read_text()))
 tree(out);checks.append({'root':str(out.relative_to(repo)),'status':r['status'],'checks':r['checks'],'formal':r['formal'],'leaks':r['leaks']})
assert checks[0]['formal']['rotatedCaptures']==3 and checks[1]['formal']['rotatedCaptures']==0
# Failure outputs contain paths/counts only; never archive their leaked public workspace or raw private captures.
failed=[]
for run in ['1792925188263', '1792925390901', '1792925555157', '1792926122115', '1792926161300', '1792926190885']:
 p=repo/'tests/scratch/ui-private-evidence'/run/'result.json';r=json.loads(p.read_text());assert r['status']=='FAIL';add(p);failed.append({'run':run,'error':r['error'],'leak_file_count':len(r['leaks'])})
desktop=repo/'tests/scratch/ui-workflow-visibility/1792925606628';d=json.loads((desktop/'result.json').read_text());assert d['status']=='PASS' and len(d['checks'])==7;tree(desktop)
for p in (repo/'tests/scratch/ui-optimization-u00').glob('u02-rotated-*'):
 if p.is_dir():tree(p)
 elif p.suffix in ['.log','.json']:add(p)
for p in ['tests/ui-private-evidence-test.mjs','tests/fixtures/data-space/ui-fixture.mjs','tests/scratch/ui-optimization-u00/archive-u02-rotated.py']:add(repo/p)
package=repo/'.pi/skills/ui-testing-workflow/assets/pi-ui-testing-0.1.9.tgz'
with tarfile.open(package) as t:
 installed=0
 for m in t:
  if m.isfile():assert t.extractfile(m).read()==(repo/'node_modules/pi-ui-testing'/Path(m.name).relative_to('package')).read_bytes();installed+=1
assert installed==95
archive=repo/'docs/ui-testing-evidence/optimization-u02-rotated-credentials.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for n,b in sorted(files.items()):
  m=tarfile.TarInfo(n);m.size=len(b);m.mtime=0;t.addfile(m,io.BytesIO(b))
with tarfile.open(archive) as t:
 assert set(t.getnames())==set(files)
 for m in t:assert t.extractfile(m).read()==files[m.name]
index={'date':'2026-10-25','status':'OBSERVABLE_RUNTIME_CREDENTIAL_ROTATION_ISOLATED_U02_FULL_SCOPE_PENDING','plan_complete':False,'native_version':'0.1.9','upstream_commit':'5bd52eb63245519a21f0304bd415021fed6a6436','upstream_pushed':False,'actual_model_calls':0,'fee_ledger_unchanged':True,'business_requests':0,'positive_negative_and_formal_review':'Controlled engineering reviewers only; no new independent model approval','failures_retained':failed,'current_scenarios':checks,'public_file_ref_verifications':ref_count,'desktop':{'evidence':str(desktop.relative_to(repo)),'checks':d['checks'],'scope':'Real isolated Electron settings, disable/enable/reload, slash discovery, MCP87/reconnect; not full business chain'},'validation':{'typecheck':'upstream and host passed','native_final':'13 passed, 0 skipped','native_preliminary':'59 passed, 2 live reviews skipped; source changed while suite was running, not final-version whole-suite proof','sdk_mcp':'19 passed','host_vitest':'51 passed / 3 files','privacy':'Two real authenticated scenarios, 6 checks each; original and runtime cookie forms absent from public files/decoded attachments/uncompressed ZIP','lint':'passed','protocol':'structure passed; no-tag history skipped','clean':'preview only; no deletion'},'package':{'path':str(package.relative_to(repo)),'sha256':sha(package.read_bytes()),'installed_equal_files':installed},'limits':['Only values observable in standard Cookie/Set-Cookie/Authorization/Proxy-Authorization headers are newly discovered','No guarantee for unknown values without trace, business-sensitive content, arbitrary/nested encoding or scripts writing files','Recording MCP and data-space private execution bridge are still incomplete','Authenticated success now retains a private trace, adding work and explicitly incomplete public resources; passed outcome remains passed','Historical U00 measurements keep original 0.1.7 version; no performance claim for 0.1.9','Original trusted U05 approval was not cloned or renewed; no new candidate/review authorization consumed','Real OperationContract roles/data/oracles and complete Electron M1/M2 remain pending'],'archive':{'path':str(archive.relative_to(repo)),'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'files':len(files),'roundtrip_verified':True},'files':[{'path':n,'sha256':sha(b),'bytes':len(b)} for n,b in sorted(files.items())]}
(repo/'docs/ui-testing-evidence/optimization-u02-rotated-credentials.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'files':len(files),'refs':ref_count,'bytes':archive.stat().st_size,'installed':installed}))
