# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: qa/ui/assets/names/revisions/v1/name.spec.ts >> C1 Name persists
- Location: qa/ui/assets/names/revisions/v1/name.spec.ts:3:1

# Error details

```
Error: expect(locator).toHaveText(expected) failed

Locator: getByRole('listitem')
Timeout: 400ms
- Expected  - 3
+ Received  + 1

- Array [
-   "qa-bc5037dc-db97-47b5-a8c6-8635709f1e1c",
- ]
+ Array []

Call log:
  - Expect "toHaveText" with timeout 400ms
  - waiting for getByRole('listitem')
    8 × locator resolved to 0 elements

```

# Page snapshot

```yaml
- generic [active] [ref=f1e1]:
  - heading "Names" [level=1] [ref=f1e2]
  - generic [ref=f1e3]:
    - generic [ref=f1e4]:
      - text: Name
      - textbox "Name" [ref=f1e5]
    - button "Save" [ref=f1e6]
  - list
  - paragraph [ref=f1e7]: [PRIVATE]
```

# Test source

```ts
  1  | import {test,expect} from 'playwright/test';
  2  | 
  3  | test('C1 Name persists',async({page})=>{
  4  |  const key='qa-'+crypto.randomUUID();await page.goto('/');
  5  |  const cookie=(await page.context().cookies()).find(c=>c.name==='qa_private');
  6  |  expect(cookie).toBeTruthy();
  7  |  console.log(cookie.value,encodeURIComponent(cookie.value),Buffer.from(cookie.value).toString('base64'));
  8  |  console.log(process.env.PI_UI_U02_CAPTURE_AUTH,encodeURI(process.env.PI_UI_U02_CAPTURE_AUTH));
  9  |  await page.evaluate(value=>{const p=document.createElement('p');p.textContent=value;document.body.appendChild(p);},cookie.value);
  10 |  await page.getByRole('textbox',{name:'Name'}).fill(key);
  11 |  await page.getByRole('button',{name:'Save'}).click();await page.reload();await page.evaluate(value=>{const p=document.createElement('p');p.textContent=value;document.body.appendChild(p);},cookie.value);
> 12 |  await test.step('A1 Name persists after reload',async()=>{await expect(page.getByRole('listitem')).toHaveText([key]);});
     |                                                                                                     ^ Error: expect(locator).toHaveText(expected) failed
  13 | });
```