import assert from 'node:assert/strict';
import {mkdtemp,readFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {createServer} from 'node:http';
import {chromium} from 'playwright';
import {CHROME_PATH} from '../../lib/chrome.mjs';
import {observeStorageBeforeNavigation} from './storage-event-observer-prototype.mjs';
const root=await mkdtemp(join(tmpdir(),'storage-events-')),file=join(root,'events.ndjson');
const server=createServer((req,res)=>{res.setHeader('Content-Type','text/html');res.end('<h1>Storage fixture</h1>');});
let browser;
try{
 await new Promise(r=>server.listen(18984,'127.0.0.1',r));
 browser=await chromium.launch({headless:true,...(CHROME_PATH?{executablePath:CHROME_PATH}:{})});
 const context=await browser.newContext(),page=await context.newPage();
 const observer=await observeStorageBeforeNavigation(page,file);await page.goto('http://127.0.0.1:18984/');
 await page.evaluate(()=>{localStorage.setItem('token','synthetic-added');localStorage.token='synthetic-assigned';localStorage.removeItem('token');sessionStorage.setItem('token','synthetic-session');sessionStorage.clear();});
 await observer.flush();const events=(await readFile(file,'utf8')).trim().split('\n').map(JSON.parse);
 assert.ok(events.some(e=>e.type==='domStorageItemAdded'&&e.newValue==='synthetic-added'&&e.storageId.isLocalStorage));
 assert.ok(events.some(e=>e.type==='domStorageItemUpdated'&&e.oldValue==='synthetic-added'&&e.newValue==='synthetic-assigned'));
 assert.ok(events.some(e=>e.type==='domStorageItemRemoved'&&e.key==='token'));
 assert.ok(events.some(e=>e.type==='domStorageItemAdded'&&e.newValue==='synthetic-session'&&!e.storageId.isLocalStorage));
 assert.ok(events.some(e=>e.type==='domStorageItemsCleared'));
 console.log(JSON.stringify({status:'CHROMIUM_DOMSTORAGE_EVENTS_VERIFIED',eventTypes:events.map(e=>e.type),propertyAssignmentObserved:true,removedValueObserved:true,sessionStorageObserved:true,modelCalls:0,businessWrites:0}));
}finally{await browser?.close();await new Promise(r=>server.close(r));await rm(root,{recursive:true,force:true});}
