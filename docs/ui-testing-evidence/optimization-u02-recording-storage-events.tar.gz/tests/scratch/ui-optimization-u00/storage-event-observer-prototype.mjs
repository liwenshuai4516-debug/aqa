/** Synthetic Chromium-only experiment. Not installed as a product capability. */
import {appendFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {dirname,resolve} from 'node:path';
const observers=new WeakMap();
export async function flushStorageObservation(page) {
  const observer=observers.get(page);if(!observer)throw Error("Private storage observer unavailable");await observer.flush();
}
export async function observeStorageBeforeNavigation(page, file) {
  file=resolve(file);mkdirSync(dirname(file),{recursive:true,mode:0o700});
  writeFileSync(file,JSON.stringify({type:'starting',version:1})+'\n',{mode:0o600,flag:'wx'});
  const append=entry=>appendFileSync(file,JSON.stringify(entry)+'\n');
  const client=await page.context().newCDPSession(page);
  for(const type of ['domStorageItemAdded','domStorageItemUpdated','domStorageItemRemoved','domStorageItemsCleared'])
    client.on('DOMStorage.'+type,event=>append({type,...event}));
  await client.send('DOMStorage.enable');
  append({type:'ready',version:1});
  // A second page may have an independent target; this prototype refuses to infer its coverage.
  page.context().on('page',()=>append({type:'unsupported-new-page'}));
  const observer={flush:async()=>{await client.send('Runtime.evaluate',{expression:'void 0'});append({type:'barrier'});}};observers.set(page,observer);Object.defineProperty(page,'__pi_private_storage_flush',{value:observer.flush});return observer;
}
