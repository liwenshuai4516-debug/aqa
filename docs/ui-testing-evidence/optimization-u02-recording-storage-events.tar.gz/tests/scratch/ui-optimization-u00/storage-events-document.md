# U02 Chromium 存储事件：阶段记录

2026-10-26；Electron 权威项目“项目管理系统”；原生 pi-ui-testing 0.1.14、Pi SDK 1.2.0、Playwright Test 1.62.1。仅自有合成站点和私有合成身份；没有真实 PMS 录制、模型调用或正式批次。整体计划未完成，产品私密 record 继续 unsupported。

## 本轮进展

上一轮“首次采集前写入并删除的新值”仍泄露。本轮复用 Playwright CDPSession 的 Chromium DOMStorage.enable，受控 seed 在 page.goto 前订阅原生 added/updated/removed/cleared 事件。独立真实浏览器探针确认 setItem、属性赋值、删除、sessionStorage 变化可见；原型不覆盖 DOM Storage 方法或修改页面 JS。

内部 private-recording-storage-events.mjs 负责私有事件记录、CDP 刷新屏障及读取核验。原始事件文件只在工作区外、0700父目录/0600文件，以wx新建；事件数上限128、2MiB，超限/断连/关闭拒绝flush。页面关闭解除监听和detach。第二个页面写unsupported标记，由读取侧拒绝；只核验指定origin，坏JSON/结构/缺屏障/权限/符号链接均拒绝。受控seed明确登记该模块并冻结摘要，不向未授权目标自行注入。

VM边界：Playwright unsafe工具只注入page和结束句柄，早期helper错误使用process.cwd动态导入，实际两轮在首次helper被阻断、未finish，不能算partial或通过。源码核对确认process不在VM上下文。改为seed给实际page对象绑定固定私有flush函数，helper只调用该函数，无动态导入或私有绝对路径。精确初轮harness/原型及公开错误已保留；初轮原始私有输入已清理，部分引用不可回读，索引列明。较早合成源码未完整保留时不冒称有全部原始依据。

宿主在固定SDK嵌套helper成功后，读取已刷新私有日志。原生事件的oldValue/newValue仅为现有过滤器归一化，不伪称浏览器storageState，也不保存为测试状态；复用0.1.14 observeStorageState及既有JSON/编码规则。仍采集当前原生storageState与trace认证头，过滤父响应，保留原生writer和生命周期门禁。

## 实际录制对照

- 原型瞬态字符串：seed确认新值存在，删除并确认null，DOM反射旧值；原生complete/1脚本/gaps=[]，公开草稿与原生字节一致。
- 长期内部模块的瞬态嵌套JSON：同样通过；私有事件在删除前记录含叶值的JSON，4次helper读取事件历史，公开响应/SDK长输出/工作区未检出已知初始与新增秘密或受支持编码，媒体块0。
- writer阶段损坏自有事件日志：拒绝公开，私有原生草稿保留/公开不存在；partial/0脚本，保留private-authentication-storage-events-invalid等缺口。
- 采集响应到达时取消原signal：同样partial/0脚本且无公开草稿，保留private-authentication-capture-cancelled等缺口。
- writer阶段受控新建第二页面：真实context.newPage触发观察器的unsupported标记，公开阻断、partial/0脚本，保留private-storage-unsupported-new-page等缺口，未声称观察到新页面认证。该负向夹具是明确的越界拒绝验证，不是一般业务导航权限。

3类partial对照的browser_close均实际成功，未重放未知业务。scope明确单page/origin、最多8个固定helper/128事件/2MiB/30工具调用；正向实际5业务+4helper=9个MCP调用，原生steps只计5，SDK实际hook事件保留parentToolCallId归属。所有轮模型调用/正式批次/真实业务写入0，PMS剩余2次仅设计额度及旧U05账本未变。

## 工程、保存与限制

新增7项单测覆盖历史值/屏障、坏证据/跨origin/权限/符号链接、第二页面、事件/字节预算、关闭/断连及公开工作区拒绝。初轮6项因macOS /var临时目录别名未canonicalize，全部在准备阶段被路径门禁拒绝；修正夹具为realpath后通过，没有放松实现守卫。初轮源码和失败日志保留。最终相关3文件26项Vitest、完整5配置typecheck、lint/协议同步/size/diff通过；协议tag启发式无可用tag跳过。最终模块另加事件版本校验，最终单测覆盖正常读取；未单独执行版本号错误的MCP对照，真实MCP四轮使用的精确模块在各自输入快照中保留，不把后来版本替换旧证据。

本轮新增内部模块，无产品工具或入口登记，mcp-extension未导入；既有Electron产品私密record仍unsupported。本轮未重跑Electron界面；上一轮实际桌面发现/禁用/重载证据保留但不算本轮通过。未改运行包/个人配置、不停止当前应用。

归档 docs/ui-testing-evidence/optimization-u02-recording-storage-events.json / .tar.gz，包含源码、正反原生公开产物、初轮失败及校验索引。私有原始事件/trace/storageState及SDK临时输出按归属清理，自有进程关闭；保留摘要不等于原始文件可回读。文档及公开/减少内容快照存入权威Electron项目文档，0700/0600逐文件回读、store.json未写；不声称应用列表显示或正式结果入库。

下一步：验证frame/其他target、断连及完整重连续录、已存在页面和监听失效的执行侧拒绝，再接产品私有准备与生命周期。当前CDP单page方案不证明跨frame、IndexedDB、任意页面/协议秘密或文件系统竞态安全；通用输入闭包、真实角色/租户/数据、U00计量、U03/U07与M1/M2仍未完成。
