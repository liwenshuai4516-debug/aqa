/** Private synthetic experiment only. Not registered in the product; exact source snapshot and exclusive draft publication experiment. */
import {appendFileSync,readFileSync,writeFileSync,lstatSync,existsSync,mkdirSync,chmodSync} from 'node:fs';
import {pathToFileURL} from 'node:url';
import {join,isAbsolute,relative} from 'node:path';
import {createHash} from 'node:crypto';
import {guardPrivateRecordingTransport} from '../../../.pi/skills/ui-testing-workflow/assets/private-recording-transport.mjs';
import {StdioTransport} from '@earendil-works/pi-mcp';
import {createMcpExtension} from '@earendil-works/pi-coding-agent';
import {validateRecordingSeed} from '../../../.pi/skills/ui-testing-workflow/assets/recording-preflight.mjs';
import {resolvePlaywrightRuntime} from '../../../.pi/skills/ui-testing-workflow/assets/playwright-runtime.mjs';
export function probeExtension({rawRoot,statePath,workspace,outputFile,inputFiles,inputHashes,childEnv,authority,baseline,snapshot,beforePublication,connection,privacy}){
 const text=value=>privacy.text(value);
 const sanitize=value=>{
  if(typeof value==='string')return text(value);
  if(Array.isArray(value))return value.map(sanitize);
  if(value&&typeof value==='object'){
   if(['image','audio','resource_link'].includes(value.type)||value.type==='resource'&&value.resource?.blob)return{type:'text',text:'[Private media/resource withheld; reduced evidence only]'};
   return Object.fromEntries(Object.entries(value).map(([k,v])=>[text(k),sanitize(v)]));
  }
  return value;
 };
 const mcp=createMcpExtension({
  loadConfig:ctx=>{const runtime=resolvePlaywrightRuntime(rawRoot);return{servers:[{name:'ui-playwright-test',scope:'extension',source:import.meta.url,config:{command:process.execPath,args:[runtime.cli,'run-test-mcp-server','--headless','-c',runtime.config],cwd:rawRoot,exposure:'direct',timeout:45}}],errors:[]};},
  createTransport:entry=>{
   const pending=new Map(),requests=new Map();connection.privateCaptures=[];connection.storageEventCaptures=[];connection.sdkCaptureReceipts=[];let captureOrdinal=0;
   const safePath=(root,path)=>{if(isAbsolute(path)||relative(root,join(root,path)).startsWith('..'))throw Error('Private publication path rejected');let p=root;for(const part of path.split('/')){p=join(p,part);if(existsSync(p)&&lstatSync(p).isSymbolicLink())throw Error('Private publication symlink rejected');}return p;};
   const digest=bytes=>createHash('sha256').update(bytes).digest('hex');
   const unchanged=()=>inputFiles.every(name=>digest(readFileSync(safePath(workspace,name)))===inputHashes[name]&&digest(readFileSync(safePath(rawRoot,name)))===inputHashes[name]);
   const inner=new StdioTransport({command:entry.config.command,args:entry.config.args,cwd:entry.config.cwd,env:childEnv,stderr:'pipe'});
   connection.disconnect=()=>inner.close();
   inner.onClose(()=>{connection.closeObserved=true;});
   const guarded=guardPrivateRecordingTransport({transport:inner,snapshot,

    receive:async(message,publish)=>{appendFileSync(join(rawRoot,'protocol.ndjson'),JSON.stringify(message)+'\n',{mode:0o600});const request=requests.get(message.id);requests.delete(message.id);const draft=pending.get(message.id);pending.delete(message.id);
     if(request?.capture){
      if(!message.result||message.result.isError||message.error)throw Error('Private trace capture tool failed');
      const file=safePath(privacy.directory,'output/auth-'+request.capture+'/trace.zip');
      const storage=safePath(privacy.directory,'output/auth-'+request.capture+'/storage.json');
      if(!lstatSync(storage).isFile())throw Error('Private storage capture unavailable');
      chmodSync(storage,0o600);if(connection.corruptStorage)writeFileSync(storage,JSON.stringify({cookies:[],origins:[{localStorage:[{value:42}]}]}));
      const eventPath=safePath(privacy.directory,'output/storage-events.ndjson');
      if(!lstatSync(eventPath).isFile())throw Error('Private storage observer unavailable');
      if(connection.corruptStorageEvents)writeFileSync(eventPath,'invalid owned storage events\n');
      const eventBytes=readFileSync(eventPath);if(eventBytes.length>2*1024*1024||!eventBytes.toString().endsWith('\n'))throw Error('Private storage observer incomplete');
      const events=eventBytes.toString().trim().split('\n').map(JSON.parse);
      if(events.length>128||events[0]?.type!=='starting'||events[1]?.type!=='ready'||events.at(-1)?.type!=='barrier')throw Error('Private storage observer incomplete');
      const values=[];for(const event of events.slice(2,-1)){
       if(event.type==='barrier')continue;
       if(!['domStorageItemAdded','domStorageItemUpdated','domStorageItemRemoved','domStorageItemsCleared'].includes(event.type)||event.storageId?.securityOrigin!=='http://127.0.0.1:18983'||typeof event.storageId?.isLocalStorage!=='boolean')throw Error('Private storage observer unsupported target');
       for(const key of ['oldValue','newValue'])if(event[key]!==undefined){if(typeof event[key]!=='string')throw Error('Private storage event invalid');values.push({value:event[key]});}
      }
      // Normalize actual CDP event values for the existing filter only; this is not a browser state snapshot.
      privacy.observeStorageState({cookies:[],origins:[{localStorage:values}]});
      connection.storageEventCaptures.push({ordinal:request.capture,bytes:eventBytes.length,events:events.length,valueObservations:values.length,sha256:digest(eventBytes),source:'actual-chromium-domstorage-events'});
      const storageBytes=readFileSync(storage);privacy.observeStorageState(JSON.parse(storageBytes.toString()));
      if(connection.corruptCapture)writeFileSync(file,'invalid owned trace');
      if(!lstatSync(file).isFile()||lstatSync(file).isSymbolicLink())throw Error('Private trace capture unavailable');
      const bytes=readFileSync(file);if(connection.cancelCapture){connection.cancelCapture();connection.cancelCapture=null;}await privacy.process(message);
      connection.privateCaptures.push({ordinal:request.capture,tool:'browser_run_code_unsafe',throughSdkExecuteTool:true,traceSha256:digest(bytes),traceBytes:bytes.length,storageSha256:digest(storageBytes),storageBytes:storageBytes.length,status:'headers-observed-before-public-response'});
      return{...message,result:{content:[{type:'text',text:'Private authentication headers captured; raw content withheld'}]}};
     }
     if(request&&request.name!=='browser_close'&&message.result&&!message.result.isError){
      if(captureOrdinal>=8)throw Error('Private capture budget exhausted');
      await snapshot.assertCurrent();const ordinal=++captureOrdinal;mkdirSync(join(privacy.directory,'output','auth-'+ordinal),{recursive:true,mode:0o700});
      const code="async (page) => { const observer=await import(process.cwd()+'/tests/observe-storage.mjs'); await observer.flushStorageObservation(page); await page.context().storageState({path:'../../output/auth-"+ordinal+"/storage.json'}); await page.context().tracing.stopChunk({path:'../../output/auth-"+ordinal+"/trace.zip'}); await page.context().tracing.startChunk(); return {private_auth_capture:'complete'}; }";
      connection.captureInput=code;connection.captureOrdinal=ordinal;
      const context=connection.currentTool;if(!context?.ctx.executeTool)throw Error('Native nested tool context unavailable');
      const outcome=await context.ctx.executeTool('mcp__ui_playwright_test__browser_run_code_unsafe',{code,intent:'Collect owned private authentication trace before publishing the parent response; no business interaction'},{signal:context.signal});
      connection.sdkCaptureReceipts.push({ordinal,parentToolCallId:context.ctx.toolCallId??null,toolCallId:outcome.toolCall?.id,toolName:outcome.toolCall?.name,outcomeKeys:Object.keys(outcome),isError:!!outcome.isError,detailsKeys:Object.keys(outcome.result?.details??{})});
      connection.captureInput=null;connection.captureOrdinal=null;
      if(outcome.isError)throw Error('Private authentication capture blocked; parent response withheld');
      await snapshot.assertCurrent();
     }

     if(draft&&message.result&&!message.result.isError){
      await beforePublication?.();
      try{
       const source=safePath(rawRoot,outputFile),target=safePath(workspace,outputFile),bytes=readFileSync(source);
       if(!lstatSync(source).isFile()||bytes.toString()!==draft.code||text(bytes.toString())!==bytes.toString())throw Error('Draft bytes changed or contain private values');
       await publish(()=>writeFileSync(target,bytes,{mode:0o600,flag:'wx'}));
       message={...message,result:{...message.result,content:[...message.result.content,{type:'text',text:'Public draft copied byte-for-byte from native writer; sha256='+createHash('sha256').update(bytes).digest('hex')}]}};
      }catch{message={...message,result:{content:[{type:'text',text:'Private native draft retained; public publication blocked without overwrite'}],isError:true}};}
     }
     if(draft)connection.publicationSettled?.();return sanitize(message);},
   });
   return{
    start:()=>guarded.start(),close:()=>guarded.close(),
    send:async(message,options)=>{
     if(message.method==='tools/call'){requests.set(message.id,{name:message.params.name,capture:message.params.name==='browser_run_code_unsafe'&&message.params.arguments?.code===connection.captureInput?connection.captureOrdinal:null});
      if(message.params.name!=='browser_close'&&!unchanged())throw Error('Recording snapshot changed; no action dispatched');
      if(message.params.name==='generator_write_test'){
       const args=message.params.arguments;
       if(args.fileName!==outputFile||text(args.code)!==args.code)throw Error('Draft publication input rejected');
       const target=safePath(workspace,outputFile);if(existsSync(target))throw Error('Existing public draft preserved');
       safePath(rawRoot,outputFile);pending.set(message.id,{code:args.code});
      }
     }
     return guarded.send(message.result?.roots?{...message,result:{...message.result,roots:[{uri:pathToFileURL(rawRoot).href,name:'private-recording'}]}}:message,options);
    },
    onMessage:listener=>guarded.onMessage(listener),
    onError:listener=>guarded.onError(listener),
    onClose:listener=>guarded.onClose(listener),
    get stderr(){return text(inner.stderr);}
   };
  }
 });
 return async pi=>{
  connection.sdkEvents=[];for(const kind of ['tool_call','tool_result'])pi.on(kind,async event=>{if(event.toolName.startsWith('mcp__ui_playwright_test__'))connection.sdkEvents.push({kind,toolName:event.toolName,toolCallId:event.toolCallId,parentToolCallId:event.parentToolCallId??null,...(kind==='tool_result'?{isError:!!event.isError}:{})});});
  pi.on('tool_call',async(event,ctx)=>{if(event.toolName!=='mcp__ui_playwright_test__generator_setup_page')return;try{await validateRecordingSeed(ctx.cwd,event.input);}catch(error){return{block:true,reason:error.message};}});
  return mcp({...pi,registerTool:tool=>pi.registerTool({...tool,execute:async(...args)=>{const previous=connection.currentTool;connection.currentTool={ctx:args[4],signal:args[2]};try{return await tool.execute(...args);}finally{connection.currentTool=previous;}}})});
 };
}
