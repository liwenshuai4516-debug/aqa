{
  "feature": "search",
  "scenario": "search-declared",
  "states": [
    "filtered",
    "reset"
  ],
  "source": {
    "path": "qa/ui/scopes/declaration/fixture.mjs",
    "sha256": "f07cad393d22c4629c771ef7763de96b47d030b6730fbec222fd110da2b89cc5"
  },
  "expected": [
    "query filters names",
    "reset restores first page"
  ],
  "observations": [
    {
      "path": "qa/ui/recordings/tester/events/action-1/response.json",
      "sha256": "a1adf1a4e9b787e3713d529e4ee866c395493e94eff7b55a3f21b2b707fb6303"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-6/response.json",
      "sha256": "56534921ef01e4b6f8bde50b8a7e7c1d5e241edf670ce24fa13bc6210bc7519c"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-9/response.json",
      "sha256": "76500b3e441f37567e357289888345a4f37fb8e1e9ee912d2d9324fa6c5600c1"
    }
  ],
  "locators": {
    "query": "getByRole('textbox', { name: 'Query' })",
    "search": "getByRole('button', { name: 'Search' })",
    "reset": "getByRole('button', { name: 'Reset' })"
  },
  "gaps": []
}