{
  "feature": "details",
  "scenario": "details-declared",
  "states": [
    "about selected",
    "details expanded"
  ],
  "source": {
    "path": "qa/ui/scopes/declaration/fixture.mjs",
    "sha256": "f07cad393d22c4629c771ef7763de96b47d030b6730fbec222fd110da2b89cc5"
  },
  "expected": [
    "tab selection changes panel",
    "details expansion changes visibility"
  ],
  "observations": [
    {
      "path": "qa/ui/recordings/tester/events/action-40/response.json",
      "sha256": "dc23bb7e7784573534eb3b80aab860d353f5d52eca967d25f3d13a3509829a14"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-43/response.json",
      "sha256": "e9ff6a8ab79bd9f9292dab8378ea97573e5e3301f71b9a5f13cff84f68dd3d8f"
    }
  ],
  "locators": {
    "query": "getByRole('textbox', { name: 'Query' })",
    "search": "getByRole('button', { name: 'Search' })",
    "reset": "getByRole('button', { name: 'Reset' })",
    "add": "getByRole('button', { name: 'Add' })",
    "name": "getByRole('textbox', { name: 'Name' })",
    "cancel": "getByRole('button', { name: 'Cancel' })",
    "save": "getByRole('button', { name: 'Save' })",
    "next": "getByRole('button', { name: 'Next' })",
    "previous": "getByRole('button', { name: 'Previous' })",
    "about": "getByRole('tab', { name: 'About' })",
    "details": "getByText('Details')"
  },
  "gaps": []
}