{
  "feature": "edit",
  "scenario": "edit-declared",
  "states": [
    "dialog open",
    "filled then cancelled",
    "saved once",
    "one persisted name after reload"
  ],
  "source": {
    "path": "qa/ui/scopes/declaration/fixture.mjs",
    "sha256": "f07cad393d22c4629c771ef7763de96b47d030b6730fbec222fd110da2b89cc5"
  },
  "expected": [
    "dialog opens and cancels without writes",
    "saved name survives reload"
  ],
  "observations": [
    {
      "path": "qa/ui/recordings/tester/events/action-12/response.json",
      "sha256": "64f79832b71be8f2237765caa04a90758f78a98bedbb8797d1822e82ab7ce7c9"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-17/response.json",
      "sha256": "e879f46485e0e837069f00e40404e2bb24fae8bd49f66dc006e6e14306d5beae"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-19/response.json",
      "sha256": "be507aa2c24c653551c6a49a5fff2d6955ed5048561dde42a7e4485a95f6bc26"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-24/response.json",
      "sha256": "31628b6e7fd29f3a5b2d9060d84e7fb4fdd39c9e6dbc1707de5c80e486a410e7"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-27/response.json",
      "sha256": "f11a8d60475e8c443a39835ab02f7013e27b043e2873ab1529c788ef8967ea6b"
    }
  ],
  "locators": {
    "query": "getByRole('textbox', { name: 'Query' })",
    "search": "getByRole('button', { name: 'Search' })",
    "reset": "getByRole('button', { name: 'Reset' })",
    "add": "getByRole('button', { name: 'Add' })",
    "name": "getByRole('textbox', { name: 'Name' })",
    "cancel": "getByRole('button', { name: 'Cancel' })",
    "save": "getByRole('button', { name: 'Save' })"
  },
  "gaps": []
}