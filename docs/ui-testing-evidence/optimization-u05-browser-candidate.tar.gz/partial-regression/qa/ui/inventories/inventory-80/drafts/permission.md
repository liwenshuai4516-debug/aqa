{
  "feature": "permission",
  "scenario": "permission-declared",
  "states": [
    "viewer Add hidden"
  ],
  "source": {
    "path": "qa/ui/scopes/declaration/fixture.mjs",
    "sha256": "f07cad393d22c4629c771ef7763de96b47d030b6730fbec222fd110da2b89cc5"
  },
  "expected": [
    "viewer cannot see Add",
    "tester can see Add"
  ],
  "observations": [
    {
      "path": "qa/ui/recordings/viewer/events/action-54/response.json",
      "sha256": "4c0ea99b6dcd56f7f3b7c0b95b548ebbf821538f14bab4750649d127e3cf91a8"
    }
  ],
  "locators": {},
  "gaps": [
    "Tester observation remains in the original tester scope"
  ]
}