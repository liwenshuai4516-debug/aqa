{
  "feature": "permission",
  "scenario": "permission-declared",
  "states": [
    "tester sees Add"
  ],
  "source": {
    "path": "qa/ui/scopes/declaration/fixture.mjs",
    "sha256": "f07cad393d22c4629c771ef7763de96b47d030b6730fbec222fd110da2b89cc5"
  },
  "expected": [
    "viewer cannot see Add",
    "tester can see Add"
  ],
  "observations": [
    {
      "path": "qa/ui/recordings/tester/events/action-29/response.json",
      "sha256": "9e038a85231446a6b522d668bde9fcc3cdbc4ff26a90d9020fd15a5c697107d7"
    }
  ],
  "locators": {
    "query": "getByRole('textbox', { name: 'Query' })",
    "search": "getByRole('button', { name: 'Search' })",
    "reset": "getByRole('button', { name: 'Reset' })",
    "add": "getByRole('button', { name: 'Add' })",
    "name": "getByRole('textbox', { name: 'Name' })",
    "cancel": "getByRole('button', { name: 'Cancel' })",
    "save": "getByRole('button', { name: 'Save' })"
  },
  "gaps": [
    "viewer context not observed in tester scope"
  ]
}