{
  "feature": "details",
  "scenario": "details-declared",
  "states": [
    "about selected",
    "details expanded",
    "details collapsed"
  ],
  "source": {
    "path": "qa/ui/scopes/declaration/fixture.mjs",
    "sha256": "f07cad393d22c4629c771ef7763de96b47d030b6730fbec222fd110da2b89cc5"
  },
  "expected": [
    "tab selection changes panel",
    "details expansion changes visibility"
  ],
  "observations": [
    {
      "path": "qa/ui/recordings/tester/events/action-41/response.json",
      "sha256": "9276e42c921e60219ad7e8d00cbff6b35450024e51cd5c5696ff6f9c9f11c00b"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-44/response.json",
      "sha256": "a65bc587a514f9b4df12ab91fa9a3fe4f1b2c4e2e1e1beadc1e28c3c24a027db"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-46/response.json",
      "sha256": "f69d2f9c274d0bf4d7fb2fabec26831f64dc532c561bad818e305d05c729a6ab"
    }
  ],
  "locators": {
    "query": "getByRole('textbox', { name: 'Query' })",
    "search": "getByRole('button', { name: 'Search' })",
    "reset": "getByRole('button', { name: 'Reset' })",
    "add": "getByRole('button', { name: 'Add' })",
    "name": "getByRole('textbox', { name: 'Name' })",
    "cancel": "getByRole('button', { name: 'Cancel' })",
    "save": "getByRole('button', { name: 'Save' })",
    "next": "getByRole('button', { name: 'Next' })",
    "previous": "getByRole('button', { name: 'Previous' })",
    "about": "getByRole('tab', { name: 'About' })",
    "details": "getByText('Details')"
  },
  "gaps": []
}