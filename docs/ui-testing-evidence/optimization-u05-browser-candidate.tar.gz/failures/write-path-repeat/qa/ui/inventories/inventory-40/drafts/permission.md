{
  "feature": "permission",
  "scenario": "permission-declared",
  "states": [
    "tester sees Add",
    "seed confirms viewer Add hidden in a separate closed context"
  ],
  "source": {
    "path": "qa/ui/scopes/declaration/fixture.mjs",
    "sha256": "f07cad393d22c4629c771ef7763de96b47d030b6730fbec222fd110da2b89cc5"
  },
  "expected": [
    "viewer cannot see Add",
    "tester can see Add"
  ],
  "observations": [
    {
      "path": "qa/ui/recordings/tester/events/action-29/response.json",
      "sha256": "c2c532ba8f873dde82b33b64faee20b56fe1bc5bfe343ba907b8879dd5591c96"
    },
    {
      "path": "qa/ui/recordings/tester/viewer-observation.json",
      "sha256": "b0d51dc596c61a490850e187a415e042f377d28c1c068781b3f22fbf2c4f70fe"
    }
  ],
  "locators": {
    "query": "getByRole('textbox', { name: 'Query' })",
    "search": "getByRole('button', { name: 'Search' })",
    "reset": "getByRole('button', { name: 'Reset' })",
    "add": "getByRole('button', { name: 'Add' })",
    "name": "getByRole('textbox', { name: 'Name' })",
    "cancel": "getByRole('button', { name: 'Cancel' })",
    "save": "getByRole('button', { name: 'Save' })"
  },
  "gaps": []
}