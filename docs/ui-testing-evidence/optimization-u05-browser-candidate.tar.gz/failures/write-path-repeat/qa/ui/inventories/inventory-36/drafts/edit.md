{
  "feature": "edit",
  "scenario": "edit-declared",
  "states": [
    "dialog open",
    "filled then cancelled",
    "saved once",
    "one persisted name after reload"
  ],
  "source": {
    "path": "qa/ui/scopes/declaration/fixture.mjs",
    "sha256": "f07cad393d22c4629c771ef7763de96b47d030b6730fbec222fd110da2b89cc5"
  },
  "expected": [
    "dialog opens and cancels without writes",
    "saved name survives reload"
  ],
  "observations": [
    {
      "path": "qa/ui/recordings/tester/events/action-12/response.json",
      "sha256": "1cdb7c5bf38bd00d519cab21c9cc36f6bf84faa06aa73fc4ae96a45708cac0a2"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-17/response.json",
      "sha256": "f18cbf2704cd4ff18237bc65def7168eed339d381e692804b60e30553c29f3b9"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-19/response.json",
      "sha256": "33becaf10d9ea41e876168122ca52b5258d10f9bebc96b6b252781984101d8b0"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-24/response.json",
      "sha256": "61de60f4b68c31b73de0906a145a15d877ac5105afa00a3d124fa7217ce474e8"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-27/response.json",
      "sha256": "d6969c806acdf9e48a8a08493776c5ad45b46c59e58e67d220a48a11f881d343"
    }
  ],
  "locators": {
    "query": "getByRole('textbox', { name: 'Query' })",
    "search": "getByRole('button', { name: 'Search' })",
    "reset": "getByRole('button', { name: 'Reset' })",
    "add": "getByRole('button', { name: 'Add' })",
    "name": "getByRole('textbox', { name: 'Name' })",
    "cancel": "getByRole('button', { name: 'Cancel' })",
    "save": "getByRole('button', { name: 'Save' })"
  },
  "gaps": []
}