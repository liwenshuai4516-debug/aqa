{
  "feature": "paging",
  "scenario": "paging-declared",
  "states": [
    "first page",
    "last page",
    "query retained across next and previous",
    "both page boundaries"
  ],
  "source": {
    "path": "qa/ui/scopes/declaration/fixture.mjs",
    "sha256": "f07cad393d22c4629c771ef7763de96b47d030b6730fbec222fd110da2b89cc5"
  },
  "expected": [
    "two rows per page",
    "next and previous retain query"
  ],
  "observations": [
    {
      "path": "qa/ui/recordings/tester/events/action-32/response.json",
      "sha256": "310dfd3b5f1af9136b3265500396fc6e23664d6df9376a46601947155d399e12"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-35/response.json",
      "sha256": "48930b9053fabb9c213bc669a4721fca4301713d46c3df04bb6921dd28688e63"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-38/response.json",
      "sha256": "6dd71cb12f7a8c230baedd01d13d60623c56a869c4386fa7a9b7117486cd2aca"
    }
  ],
  "locators": {
    "query": "getByRole('textbox', { name: 'Query' })",
    "search": "getByRole('button', { name: 'Search' })",
    "reset": "getByRole('button', { name: 'Reset' })",
    "add": "getByRole('button', { name: 'Add' })",
    "name": "getByRole('textbox', { name: 'Name' })",
    "cancel": "getByRole('button', { name: 'Cancel' })",
    "save": "getByRole('button', { name: 'Save' })",
    "next": "getByRole('button', { name: 'Next' })",
    "previous": "getByRole('button', { name: 'Previous' })"
  },
  "gaps": []
}