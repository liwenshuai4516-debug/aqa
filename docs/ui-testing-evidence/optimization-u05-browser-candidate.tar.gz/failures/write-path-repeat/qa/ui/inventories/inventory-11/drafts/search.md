{
  "feature": "search",
  "scenario": "search-declared",
  "states": [
    "query matches Gamma"
  ],
  "source": {
    "path": "qa/ui/scopes/declaration/fixture.mjs",
    "sha256": "f07cad393d22c4629c771ef7763de96b47d030b6730fbec222fd110da2b89cc5"
  },
  "expected": [
    "query filters names",
    "reset restores first page"
  ],
  "observations": [
    {
      "path": "qa/ui/recordings/tester/events/action-1/response.json",
      "sha256": "afa36ab200e84596383e0ddf62a38be1a31488a084fc2ed05bc299be640f1288"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-6/response.json",
      "sha256": "a13f1adeeb57ebe18e2bc4b37c326866e3b4512313442d44e7c5fc5b6c0f5807"
    }
  ],
  "locators": {
    "query": "getByRole('textbox', { name: 'Query' })",
    "search": "getByRole('button', { name: 'Search' })"
  },
  "gaps": [
    "Reset not observed yet"
  ]
}