{
  "feature": "paging",
  "scenario": "paging-declared",
  "states": [
    "first page",
    "last page",
    "query retained across next and previous",
    "both page boundaries"
  ],
  "source": {
    "path": "qa/ui/scopes/declaration/fixture.mjs",
    "sha256": "f07cad393d22c4629c771ef7763de96b47d030b6730fbec222fd110da2b89cc5"
  },
  "expected": [
    "two rows per page",
    "next and previous retain query"
  ],
  "observations": [
    {
      "path": "qa/ui/recordings/tester/events/action-32/response.json",
      "sha256": "e31e4607f64f44fcad2f57f8e4211b824c5985fdf4fe388f1b5b7573abd92a22"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-35/response.json",
      "sha256": "ff724dbfe1a62a519f306d5f0e548635aac1d8cbdf1d03c24cc237c8e185879f"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-38/response.json",
      "sha256": "bab823cfd89bbadbde482df202cd35b7c93e62e8666acaa03386431051814a1b"
    }
  ],
  "locators": {
    "query": "getByRole('textbox', { name: 'Query' })",
    "search": "getByRole('button', { name: 'Search' })",
    "reset": "getByRole('button', { name: 'Reset' })",
    "add": "getByRole('button', { name: 'Add' })",
    "name": "getByRole('textbox', { name: 'Name' })",
    "cancel": "getByRole('button', { name: 'Cancel' })",
    "save": "getByRole('button', { name: 'Save' })",
    "next": "getByRole('button', { name: 'Next' })",
    "previous": "getByRole('button', { name: 'Previous' })"
  },
  "gaps": []
}