{
  "feature": "edit",
  "scenario": "edit-declared",
  "states": [
    "dialog open",
    "filled then cancelled",
    "saved once",
    "one persisted name after reload"
  ],
  "source": {
    "path": "qa/ui/scopes/declaration/fixture.mjs",
    "sha256": "f07cad393d22c4629c771ef7763de96b47d030b6730fbec222fd110da2b89cc5"
  },
  "expected": [
    "dialog opens and cancels without writes",
    "saved name survives reload"
  ],
  "observations": [
    {
      "path": "qa/ui/recordings/tester/events/action-12/response.json",
      "sha256": "bc89f34d18036b98a9b1bb4495e58ae3eb36be5ab76402076e6fc61266465167"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-17/response.json",
      "sha256": "6dfa1495c33f0d79e5074799dc4fcafe8419855d23281a07ed5bf9b7262d7006"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-19/response.json",
      "sha256": "ea2a7474ea3e92ab71ed713265b2e507f7b7d8e947ad74c6349ea003d979530f"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-24/response.json",
      "sha256": "38f671fcef5147ef1e1bf2532fd19ff68e0e566918753bfd9dad6ed1f9b00438"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-27/response.json",
      "sha256": "2bcedc82671128cb17e37b2c089beda4f1645d184fb76ddafcb740e01e8a5e77"
    }
  ],
  "locators": {
    "query": "getByRole('textbox', { name: 'Query' })",
    "search": "getByRole('button', { name: 'Search' })",
    "reset": "getByRole('button', { name: 'Reset' })",
    "add": "getByRole('button', { name: 'Add' })",
    "name": "getByRole('textbox', { name: 'Name' })",
    "cancel": "getByRole('button', { name: 'Cancel' })",
    "save": "getByRole('button', { name: 'Save' })"
  },
  "gaps": []
}