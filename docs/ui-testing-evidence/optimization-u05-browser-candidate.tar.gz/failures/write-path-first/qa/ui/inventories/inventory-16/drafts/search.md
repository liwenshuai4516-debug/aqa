{
  "feature": "search",
  "scenario": "search-declared",
  "states": [
    "filtered",
    "reset"
  ],
  "source": {
    "path": "qa/ui/scopes/declaration/fixture.mjs",
    "sha256": "f07cad393d22c4629c771ef7763de96b47d030b6730fbec222fd110da2b89cc5"
  },
  "expected": [
    "query filters names",
    "reset restores first page"
  ],
  "observations": [
    {
      "path": "qa/ui/recordings/tester/events/action-1/response.json",
      "sha256": "c3914b6967e32486648e592e9253aa303ff7f95cfddef6379c756e86771f10d0"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-6/response.json",
      "sha256": "a3cc3419556e222aec8204808589c66bb63c1cfb8cedbeafc7401b4c18ec8ed1"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-9/response.json",
      "sha256": "0e4fa4aa5ea56b33d2e0ad43d7d3d1f5767635469f089f88b0f0e00ce6b4e28d"
    }
  ],
  "locators": {
    "query": "getByRole('textbox', { name: 'Query' })",
    "search": "getByRole('button', { name: 'Search' })",
    "reset": "getByRole('button', { name: 'Reset' })"
  },
  "gaps": []
}