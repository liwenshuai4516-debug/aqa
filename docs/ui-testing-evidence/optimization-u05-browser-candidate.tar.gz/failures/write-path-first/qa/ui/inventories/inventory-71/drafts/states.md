{
  "feature": "states",
  "scenario": "states-declared",
  "states": [
    "loading with no rows precedes ready data in seed",
    "empty",
    "error"
  ],
  "source": {
    "path": "qa/ui/scopes/declaration/fixture.mjs",
    "sha256": "f07cad393d22c4629c771ef7763de96b47d030b6730fbec222fd110da2b89cc5"
  },
  "expected": [
    "loading precedes data",
    "no matches shows empty",
    "failure shows error"
  ],
  "observations": [
    {
      "path": "qa/ui/recordings/tester/loading-observation.json",
      "sha256": "edd4189199ba911abc216f8998545f4c21dc5f543df905d6d3dc1b6f95dbb414"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-51/response.json",
      "sha256": "a83e1fc61d3f0248e210decf8ba65a99dfbc20fecb7d39fc43e6eca189160cf7"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-54/response.json",
      "sha256": "3026d88a6298534bf721b785c0d37b104b2c59368c3f9d5229ba9d94392ac1d6"
    }
  ],
  "locators": {
    "query": "getByRole('textbox', { name: 'Query' })",
    "search": "getByRole('button', { name: 'Search' })",
    "reset": "getByRole('button', { name: 'Reset' })",
    "add": "getByRole('button', { name: 'Add' })",
    "name": "getByRole('textbox', { name: 'Name' })",
    "cancel": "getByRole('button', { name: 'Cancel' })",
    "save": "getByRole('button', { name: 'Save' })",
    "next": "getByRole('button', { name: 'Next' })",
    "previous": "getByRole('button', { name: 'Previous' })",
    "about": "getByRole('tab', { name: 'About' })",
    "details": "getByText('Details')",
    "list": "getByRole('tab', { name: 'List' })",
    "error": "getByRole('button', { name: 'Simulate error' })"
  },
  "gaps": []
}