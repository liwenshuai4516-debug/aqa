import { createServer } from "node:http";
import { optimizationPage } from "./ui-optimization-page.mjs";
import { probes, probePage } from "./ui-multifunction-probes.mjs";
export const browserProbes = [...probes.map(probe => ({...probe, id: probe.assertionId})), {
 assertionId: "A-edit-1", id: "A-edit-1-memory", caseId: "C-edit",
 description: "Cancel incorrectly appends only to memory; reload would hide the defect",
 before: "$('#cancel').onclick=()=>$('dialog').close()",
 after: "$('#cancel').onclick=()=>{names.push($('[name=name]').value);$('dialog').close()}"
}];
export function browserProbePage(id, caseId) {
 if (id !== "A-edit-1-memory") return probePage(id, caseId);
 const probe=browserProbes.at(-1), original=optimizationPage();
 if (caseId !== probe.caseId) return original;
 if (original.split(probe.before).length !== 2) throw new Error("Memory mutation source changed");
 return original.replace(probe.before, probe.after);
}
export function createProbeServer(id) {
 if (id !== "positive" && !browserProbes.some(p => (p.id ?? p.assertionId) === id)) throw new Error("Unknown probe");
 return createServer((request, response) => {
  if (request.method !== "GET" || new URL(request.url, "http://fixture").pathname !== "/") {
   response.writeHead(404).end(); return;
  }
  response.writeHead(200, { "content-type": "text/html", "cache-control": "no-store" });
  response.end(browserProbePage(id, request.headers["x-u05-case"]));
 });
}
