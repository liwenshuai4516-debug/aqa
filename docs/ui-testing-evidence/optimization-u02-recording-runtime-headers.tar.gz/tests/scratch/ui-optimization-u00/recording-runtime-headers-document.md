# U02 私密录制：运行时认证头采集对照（阶段记录）

2026-10-26；Electron 权威项目“项目管理系统”；本轮使用自有合成站点、隔离 SDK、Playwright Test 1.62.1 MCP、原生 pi-ui-testing 0.1.13。未录制真实 PMS 业务。产品私密 record 仍 unsupported，整体计划未完成。

## 结果

- 运行中 HttpOnly cookie：公开父工具响应前，以原生 ctx.executeTool 调用固定 browser_run_code_unsafe，完成私有 trace chunk 后复用原生 PrivateEvidence.process 收集认证头。5 个业务工具步骤、额外 4 次私有采集，原生 complete / 1 脚本 / gaps=[]，公开草稿与原生字节一致；已知初始和新增合成秘密未出现在公开响应、SDK 长输出、工作区，媒体块为 0。
- cookie 设置后立即清除：seed 先确认 cookie 存在，再请求清除并确认不存在，DOM 仍反射旧值。私有 trace 保留历史 Set-Cookie，公开扫描通过。首次及增加 SDK 归属记录后的两轮均保留。
- writer 阶段的 trace 损坏：固定故障钩子破坏自有 trace，原生过滤器拒绝处理，父响应/公开草稿阻断；私有原生草稿保留。录制 partial / 0 脚本，保留 private-authentication-trace-corrupt 等缺口。
- 私有采集响应到达时取消原 signal：公开草稿不存在、私有原生草稿保留；partial / 0 脚本，保留 private-authentication-capture-cancelled 等缺口。browser_close 仍由 SDK 实际调用成功，不自动重放业务。
- 新 localStorage 反例：页面仅写入新的 runtime-token，不通过 Cookie/Authorization 头传递；即便完成 4 次 trace 采集，新值仍出现在 setup/snapshot、SDK 长输出。原生 complete / 1 脚本，但隐私验证失败。初始 JSON token 仍被过滤。不能据 cookie 对照宣称动态认证收集完整。

SDK tool_call/tool_result 的真实事件保存工具 ID、parentToolCallId 及错误状态，确认采集属于当前业务工具；未记录参数/原始返回。较早两轮只有采集计量与执行源码，不能追认为具备后来增加的 SDK 事件。ctx 工具上下文本身没有 toolCallId 字段，早期自报 parentToolCallId=null；以 SDK 事件为归属依据。

## 边界与预算

原型仅单会话串行，不接受任意用户代码。固定 unsafe 工具只进行 trace stopChunk/startChunk；该工具具备执行任意代码能力，不应直接作为通用认证能力开放。当前相对路径依赖已知私有 mirror 布局，尚无通用路径证明、并发替换或关闭时凭据收集保证。trace 采集需要从 seed 开始启用，完成采集后才过滤父响应，不以当前 cookie 列表替代历史网络。

原 scope 明确允许最多 8 次固定私有采集、max_tool_calls=30；原生录制 max_steps=10。本轮正常实际 5 个业务工具 + 4 个采集工具，共 9 次 MCP 调用。原生 steps 不计额外采集，不能混用口径。每轮模型调用、正式测试批次、真实业务写入均 0。PMS 剩余 2 次设计额度不变，用户拒绝转结果评审，report-2 不交付。

所有原始合成私密 payload、SDK 临时输出与自有进程已按归属清理。localStorage 泄露反例不保留公开 QA 原文，只保留减少内容后的指标、精确源码和无秘密草稿；其 manifest 引用明确未保留。其他轮保留公开 QA 与校验引用。私有 trace 只保留摘要和字节数，不声称原始 trace 可回读。

证据归档：仓库 docs/ui-testing-evidence/optimization-u02-recording-runtime-headers.json / .tar.gz。本文及公开快照保存到 Electron 项目文档目录，0700/0600、逐文件回读；不写 store.json。文件保存不表示应用文档列表显示或正式结果入库。

下一步：解决新 localStorage 与跨 frame/storage 生命周期收集，明确底层工具额外预算、调用归属和路径契约，再收敛内部适配、接入实际 Electron 产品链。通用输入闭包、协议结构冲突、完整重连续录、真实角色/租户/数据、U00 成对计量、U03/U07、M1/M2 仍未完成。

补充失败样本：增加 SDK 归属记录后的首次 ephemeral-sdk 轮，在 writer 阶段出现 45 秒 MCP request aborted，未执行 finish，不能算 complete、partial 或通过。原生错误响应和当时精确源码已保留；当时 harness 在异常前未汇出 SDK 事件/私有采集指标，部分私有配置输入随归属清理不可回读，索引列明缺失引用。未知动作不自动续跑；确认本轮仅自有合成数据、原始目录已清理后，另起独立合成轮补归属验证，成功记录不能覆盖失败历史。取消/损坏对照与重试轮不是完整稳定性验收。
