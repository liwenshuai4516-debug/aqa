from pathlib import Path
import hashlib,json,tarfile,io,os,shutil
repo=Path.cwd();scratch=repo/'tests/scratch/ui-optimization-u00';sha=lambda b:hashlib.sha256(b).hexdigest()
names={'rotation':'runtime-header-rotated.log','ephemeral':'runtime-header-ephemeral.log','corrupt':'runtime-header-corrupt.log','cancel':'runtime-header-cancel-capture.log','storage':'runtime-header-storage.log','ephemeral-sdk':'runtime-header-ephemeral-sdk.log','sdk-timeout':'runtime-header-ephemeral-sdk-timeout.log'}
records={n:json.loads((scratch/f).read_text()) for n,f in names.items()}
for n,r in records.items():
 if n=='sdk-timeout':
  assert r.get('errorClass')=='AssertionError' and 'MCP request aborted' in r['errorSummary'];continue
 assert not r.get('errorSummary'),(n,r.get('errorSummary'))
 assert r['modelCalls']==r['formalRuns']==r['businessWrites']==0 and r['ownedRawOutputsRemoved']
 if n in ['corrupt','cancel']:
  assert r['recordingStatus']=='partial' and not r['publicDraftExists'] and r['privateNativeDraftExists']
 else:assert r['recordingStatus']=='complete' and r['publicScriptEqualsNative']
 if n!='storage':assert all(not t['containsSyntheticSecret'] and not t['mediaBlocks'] for t in r['tools']) and not any(f.get('containsSyntheticSecret') for f in r['findings'])
assert records['storage']['runtimeStorageLeakDespiteHeaderCapture']
assert records['cancel']['cancelledAtPrivateCapture'] and records['corrupt']['corruptTraceRejected']
assert records['ephemeral']['ephemeralCookieClearedInSeed'] and records['ephemeral-sdk']['ephemeralCookieClearedInSeed']
sdk=records['ephemeral-sdk']['sdkEvents'];calls=[e for e in sdk if e['kind']=='tool_call'];helpers=[e for e in calls if e['toolName'].endswith('__browser_run_code_unsafe')]
assert len(calls)==9 and len(helpers)==4
for e in helpers:
 parent=next(p for p in calls if p['toolCallId']==e['parentToolCallId']);assert not parent['toolName'].endswith('__browser_run_code_unsafe')
 end=next(x for x in sdk if x['kind']=='tool_result' and x['toolCallId']==e['toolCallId']);assert not end['isError']
 assert sdk.index(end)<next(i for i,x in enumerate(sdk) if x['kind']=='tool_result' and x['toolCallId']==parent['toolCallId'])
verified=0;unretained=[]
files={}
for n,r in records.items():
 d=Path(r['output']);(d/'.cleanup-keep').write_text('Retain reduced public evidence; owned raw synthetic payload removed.\n')
 if (d/'seed.spec.ts').exists():
  (d/'tests').mkdir(exist_ok=True);(d/'tests/seed.spec.ts').write_bytes((d/'seed.spec.ts').read_bytes());(d/'package.json').write_text('{"type":"module"}')
 def walk(v):
  global verified
  if isinstance(v,dict):
   if isinstance(v.get('path'),str) and isinstance(v.get('sha256'),str):
    p=Path(v['path']);assert not p.is_absolute() and '..' not in p.parts
    if n=='sdk-timeout' and not (d/p).exists():unretained.append({'run':n,**v});return
    assert sha((d/p).read_bytes())==v['sha256'],str(d/p);verified+=1
   for x in v.values():walk(x)
  elif isinstance(v,list):
   for x in v:walk(x)
 for p in (d/'qa').rglob('*.json'):walk(json.loads(p.read_text()))
 walk(r['snapshot']['receipt']['inputs'])
 if n not in ['storage','sdk-timeout']:walk(r['recordingRef']);walk(r.get('generatedScriptRef'))
 elif n=='storage':assert not (d/'qa').exists()
 for p in d.rglob('*'):
  assert not p.is_symlink()
  if p.is_file():files[str(p.relative_to(repo))]=p.read_bytes()
for f in [*names.values(),'probe-recording-runtime-headers.mjs','runtime-header-recording-prototype.mjs','recording-runtime-headers-document.md','archive-recording-runtime-headers.py']:
 p=scratch/f;files[str(p.relative_to(repo))]=p.read_bytes()
ledgerNames=['u05-authorized-review-budget.json','pms-anonymous-authorized-review-budget.json'];ledgers={n:sha((scratch/n).read_bytes()) for n in ledgerNames}
assert ledgers==json.loads((repo/'docs/ui-testing-evidence/optimization-u02-recording-json.json').read_text())['ledgerSha256']
docdir=Path.home()/'Library/Application Support/Pi Agent Desktop/data/data-space/project-documents/e2f5d42d-2781-4e68-a452-4c87c7d1d346';store=docdir.parent.parent/'store.json';before=store.read_bytes()
snap=docdir/('recording-runtime-headers-'+Path(records['ephemeral-sdk']['output']).name);snap.mkdir(mode=0o700)
for n,r in records.items():shutil.copytree(Path(r['output']),snap/n)
persisted=[]
for p in snap.rglob('*'):
 assert not p.is_symlink();os.chmod(p,0o700 if p.is_dir() else 0o600)
 if p.is_file():
  n,*parts=p.relative_to(snap).parts;assert p.read_bytes()==(Path(records[n]['output'])/Path(*parts)).read_bytes();persisted.append({'path':str(p.relative_to(snap)),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size})
doc=docdir/'OperationContract-recording-runtime-headers-2026-10-26.md';text=(scratch/'recording-runtime-headers-document.md').read_text()
with doc.open('x') as f:f.write(text)
os.chmod(doc,0o600);assert doc.read_text()==text and store.read_bytes()==before
archive=repo/'docs/ui-testing-evidence/optimization-u02-recording-runtime-headers.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for n,b in sorted(files.items()):
  m=tarfile.TarInfo(n);m.size=len(b);m.mtime=0;t.addfile(m,io.BytesIO(b))
with tarfile.open(archive) as t:
 assert set(t.getnames())==set(files)
 for m in t:assert t.extractfile(m).read()==files[m.name]
index={'date':'2026-10-26','status':'COOKIE_HEADER_CAPTURE_PROTOTYPE_VERIFIED_RUNTIME_STORAGE_STILL_LEAKS','plan_complete':False,'product_private_recording':'unsupported','current_runs':records,'refsVerified':verified,'modelCalls':0,'formalRuns':0,'businessWrites':0,'ledgerSha256':ledgers,'sdkOwnership':{'source':'actual tool_call/tool_result events','verifiedRun':'ephemeral-sdk','mcpCalls':len(calls),'privateCaptures':len(helpers),'parentResultAfterCaptureResult':True},'unretainedRefs':{'timeoutInputs':unretained,'storage':records['storage']['recordingRef'],'reason':'Synthetic secret leak in public QA; removed with owned raw payload, source and reduced metrics retained; raw trace hashes are observations, not retained FileRefs'},'document':{'path':str(doc),'sha256':sha(doc.read_bytes()),'storeUnchanged':True},'snapshot':{'path':str(snap),'files':persisted},'limits':['Internal serial synthetic prototype only; no product entry, dependency or personal configuration changes','Runtime localStorage still leaks despite trace header capture; native complete is not privacy approval','Fixed unsafe helper only; relative trace path assumes known private mirror layout','No concurrency/filesystem race, close-time credential or cross-frame storage proof','No new Electron business/visibility run; previous Electron evidence not counted as this round'], 'archive':{'path':str(archive.relative_to(repo)),'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'files':len(files),'roundtrip_verified':True},'files':[{'path':n,'sha256':sha(b),'bytes':len(b)} for n,b in sorted(files.items())]}
(repo/'docs/ui-testing-evidence/optimization-u02-recording-runtime-headers.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'files':len(files),'refs':verified,'snapshotFiles':len(persisted),'archiveBytes':archive.stat().st_size}))
