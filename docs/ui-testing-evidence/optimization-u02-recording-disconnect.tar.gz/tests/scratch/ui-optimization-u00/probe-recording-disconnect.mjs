/** Synthetic privacy reproduction through the actual SDK nested MCP pipeline. Never uses real identity or model. */
import assert from 'node:assert/strict';
import {McpClient,StdioTransport} from '@earendil-works/pi-mcp';
import {resolvePlaywrightRuntime} from '../../../.pi/skills/ui-testing-workflow/assets/playwright-runtime.mjs';
import {pathToFileURL} from 'node:url';
import {controls} from './recording-disconnect-control.mjs';
import {randomBytes} from 'node:crypto';
import {createServer} from 'node:http';
import {readFile,writeFile,mkdir,mkdtemp,rm,readdir,realpath,symlink,cp} from 'node:fs/promises';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
import {createAgentSessionFromServices,createAgentSessionServices,ModelRuntime,SessionManager,SettingsManager} from '@earendil-works/pi-coding-agent';
import {enableUiTesting} from '../../../scripts/enable-ui-testing.mjs';
import {preparePrivateRecordingWorkspace} from '../../../.pi/skills/ui-testing-workflow/assets/private-recording-workspace.mjs';
import {createPrivateBrowserStates} from '../../../plugins/data-space/private-browser-state.mjs';
import {ArtifactStore,authState,sha256} from 'pi-ui-testing';
import {CHROME_PATH} from '../../lib/chrome.mjs';
const protectedMode=true,lateMode=process.argv.find(a=>a.startsWith('--late='))?.slice(7),baseline=process.argv.includes('--baseline'),renewParent=process.argv.includes('--renew-parent'),staleMirror=process.argv.includes('--stale-mirror'),existingOutput=process.argv.includes('--existing-output'),symlinkOutput=process.argv.includes('--symlink-output');
const faulty=!!lateMode||renewParent||staleMirror||existingOutput||symlinkOutput,outputFile=symlinkOutput?'tests/publish/generated.spec.ts':'tests/generated.spec.ts';
const repo=process.cwd(),output=join(repo,'tests/scratch/ui-recording-disconnect',String(Date.now()));await mkdir(output,{recursive:true});
const root=await realpath(await mkdtemp(join(tmpdir(),'private-recording-probe-'))),workspace=join(root,'work'),agentDir=join(root,'agent'),statePath=join(root,'state.json');
for(const p of [workspace,agentDir,join(workspace,'tests')])await mkdir(p,{recursive:true,mode:0o700});
const secret='synthetic-recording+/'+randomBytes(24).toString('base64');const variants=[secret,encodeURI(secret),encodeURIComponent(secret),Buffer.from(secret).toString('base64')];
const contains=b=>variants.some(v=>b.includes(v));
const mediaCount=v=>!v||typeof v!=='object'?0:(['image','audio'].includes(v.type)||v.type==='resource'&&v.resource?.blob?1:0)+Object.values(v).reduce((n,x)=>n+mediaCount(x),0);
const result={protectedPrototype:protectedMode,status:'blocked',modelCalls:0,formalRuns:0,businessWrites:0,fixtureRequests:0,tools:[],findings:[],limits:['Synthetic fixture only; not a PMS business recording or generic privacy proof','Existing runtime reproduction; no recording gate or approval is bypassed for real data']};
let session,server,manager,prepared,managed,rawRoot;const tempFiles=new Set();
try{
 await symlink(join(repo,'node_modules'),join(workspace,'node_modules'),'dir');await writeFile(join(workspace,'package.json'),'{"type":"module"}');await writeFile(join(agentDir,'auth.json'),'{}');
 server=createServer((req,res)=>{result.fixtureRequests++;res.setHeader('Content-Type','text/html');res.end('<html><body><h1>Privacy fixture</h1>'+Array.from({length:1800},(_,i)=>'<p>marker '+i+' '+secret+'</p>').join('')+'</body></html>');});await new Promise(r=>server.listen(18983,'127.0.0.1',r));
 const dataDir=join(root,'data');await mkdir(dataDir,{mode:0o700});
 const syntheticStore={revision:1,systems:[{id:'s'}],envs:[{id:'e',systemId:'s',baseUrl:'http://127.0.0.1:18983',params:[{key:'token',value:secret,secret:true}]}]};
 manager=createPrivateBrowserStates({dataDir,store:()=>syntheticStore});
 managed=await manager.prepare(workspace,{engine:'ui',mode:'execute',systemId:'s',envId:'e',targetUrl:'http://127.0.0.1:18983/',privateBindings:[{parameterKey:'token',storageKey:'token'}]});
 const environment={auth:managed.auth,base_url:'http://127.0.0.1:18983/'};
 const parentPath=await authState(environment,workspace),parentBytes=await readFile(parentPath);
 await writeFile(join(workspace,'playwright.config.mjs'),`export default {testDir:'./tests',timeout:30000,workers:1,use:{headless:true,storageState:process.env[${JSON.stringify(managed.auth.reference)}],baseURL:'http://127.0.0.1:18983',launchOptions:${JSON.stringify(CHROME_PATH?{executablePath:CHROME_PATH}:{})}},projects:[{name:'chromium'}]};`);
 await writeFile(join(workspace,'tests/seed.spec.ts'),`import {test,expect} from '@playwright/test';import {authState} from 'pi-ui-testing';test('privacy seed',async({page})=>{expect(await authState(${JSON.stringify(environment)},process.cwd())).toBeTruthy();await page.goto('/');expect(await page.evaluate(()=>!!localStorage.getItem('token'))).toBeTruthy();});`);

 await enableUiTesting(repo,agentDir);
 const inputFiles=['package.json','playwright.config.mjs','tests/seed.spec.ts'];
 const inputHashes={};for(const name of inputFiles)inputHashes[name]=sha256(await readFile(join(workspace,name)));
 const authority=join(root,'authority');await mkdir(authority,{mode:0o700});
 prepared=await preparePrivateRecordingWorkspace({workspace,authority,environment,inputRefs:inputFiles.map(path=>({path,sha256:inputHashes[path]}))});rawRoot=prepared.workspace;
 await assert.rejects(authState(environment,rawRoot));
 result.snapshot={inputFiles,inputHashes,byteIdentical:true,sharedDependencyLink:true,receipt:prepared.receipt,parentScopeRejectsMirror:true};

 if(protectedMode){
  const privateExtension=join(root,'guarded-extension.mjs');controls.snapshot=prepared;await writeFile(privateExtension,`import {controls} from ${JSON.stringify(new URL('./recording-disconnect-control.mjs',import.meta.url).href)};import {probeExtension} from ${JSON.stringify(new URL('./disconnect-recording-prototype.mjs',import.meta.url).href)};export default probeExtension({...${JSON.stringify({rawRoot,statePath:parentPath,workspace,outputFile,inputFiles,inputHashes,childEnv:prepared.childEnv,authority,baseline})},snapshot:controls.snapshot,beforePublication:()=>controls.beforePublication?.(),connection:controls.connection});`);
  const path=join(agentDir,'settings.json'),s=JSON.parse(await readFile(path,'utf8'));s.extensions=s.extensions.filter(e=>!e.endsWith('mcp-extension.mjs'));s.extensions.push(privateExtension);await writeFile(path,JSON.stringify(s));
 }

 const runtime=await ModelRuntime.create({authPath:join(agentDir,'auth.json'),modelsPath:null,modelsStorePath:join(agentDir,'models-cache.json'),refreshOnCreate:false});for(const method of ['stream','streamSimple','complete','completeSimple'])runtime[method]=()=>{result.modelCalls++;throw Error('No model calls permitted');};
 const services=await createAgentSessionServices({cwd:workspace,agentDir,modelRuntime:runtime,settingsManager:SettingsManager.create(workspace,agentDir,{projectTrusted:true})});assert.deepEqual(services.resourceLoader.getExtensions().errors,[]);
 ({session}=await createAgentSessionFromServices({services,sessionManager:SessionManager.create(workspace,join(agentDir,'sessions'))}));await session.bindExtensions({});
 let prefix;for(let i=0;i<500;i++){prefix=session.getAllTools().find(t=>t.name.endsWith('__generator_setup_page'))?.name.replace(/generator_setup_page$/,'');if(prefix)break;await new Promise(r=>setTimeout(r,50));}assert.ok(prefix);
 const store=new ArtifactStore(workspace),envelope=(kind,id,data)=>({schema_version:'1.0',kind,id,created_at:new Date().toISOString(),data});let seq=0;
 const invoke=async(request,expectedStatus='completed')=>{const tool=session.agent.state.tools.find(t=>t.name==='ui_discover_record');assert.ok(tool);const controller=new AbortController();if(request.operation==='action'&&request.tool==='generator_write_test'&&lateMode){controls.beforePublication=async()=>{result.nativeWriterReplyObservedBeforeInterruption=true;if(lateMode==='cancel')controller.abort();else if(lateMode==='renew')await writeFile(parentPath,JSON.stringify({...JSON.parse(parentBytes),origins:[]}));else if(lateMode==='close')await prepared.revoke();else if(lateMode==='disconnect'){await controls.connection.disconnect();result.physicalCloseObserved=controls.connection.closeObserved===true;assert.equal(result.physicalCloseObserved,true);await assert.rejects(prepared.assertCurrent());result.disconnectedSnapshotRejected=true;}};}const id='handoff-'+seq++,args={request};session.agent.state.messages=[{role:'assistant',content:[{type:'toolCall',id,name:tool.name,arguments:args}]}];const outcome=await tool.execute(id,args,controller.signal);const response=JSON.parse(outcome.content.filter(c=>c.type==='text').map(c=>c.text).join('\n'));assert.equal(response.status,expectedStatus,JSON.stringify(response));return response;};
 const declaration=await store.putFile('qa/ui/scopes/privacy/fixture.json',JSON.stringify({oracle_type:'declaration',text:'Local fixture displays the Privacy fixture heading. Managed localStorage values are synthetic and must never be published.',initial:'New context from external private synthetic storageState',data:'No server business data; close owned context'}));
 const scope=await store.put(envelope('scope','privacy-mirror',{project_id:'synthetic-private-recording',environment_id:'synthetic-private-fixture',role:'synthetic-managed-context',goal:'Observe local fixture heading using private synthetic state, preserving all source/recording gates',base_url:'http://127.0.0.1:18983',allowed_actions:['Read-only same-origin navigation, snapshot, native log/draft, close; no business input'],sources:[{source_id:'fixture-declaration',oracle_type:'declaration',ref:declaration,statement:'Local fixture has Privacy fixture heading'}],budget:{max_review_rounds:3,max_tool_calls:10}}));
 const inventory=envelope('inventory','privacy-mirror-initial',{scope_ref:scope,features:[{module_id:'privacy',feature_id:'heading',name:'Local synthetic heading',entry:'/',role:'synthetic-managed-context',actions:['Observe fixture heading without exposing private state'],scenarios:[{scenario_id:'heading-observation',title:'Private fixture heading is observed'}],coverage:'discovered',discovery:'source',source_refs:[declaration],source_locations:[{ref:declaration,symbol:'text',line:1}],priority:'P0',states:[],gaps:['Not yet observed in native recording']}],unexplored:['Real PMS behavior','Business roles and data']});
 let response=await invoke({operation:'inventory',inventory}),inventoryRef=response.artifact_refs[0];
 const initial=await store.putFile('qa/ui/scopes/privacy/initial.json',JSON.stringify({cookie:'External synthetic cookie recreated by owned host; seed checks presence',context:'new independent browser context'}));
 const rules=await store.putFile('qa/ui/scopes/privacy/data.json',JSON.stringify({server_data:[],cleanup:'Close owned context; no server rows created'}));
 response=await invoke({operation:'start',configuration:{id:'privacy-mirror',scope_ref:scope,inventory_ref:inventoryRef,initial_state_ref:initial,data_rules_ref:rules,seed_ref:{path:'tests/seed.spec.ts',sha256:sha256(await readFile(join(workspace,'tests/seed.spec.ts')))},backend:prefix,project:'chromium',output_file:outputFile,max_steps:10,max_duration_ms:120000,max_no_progress:3,test_data:[]}});const recordingRef=response.artifact_refs[0];
 const temps=new Set();const findPaths=async v=>{if(!v||typeof v!=='object')return;for(const[k,x]of Object.entries(v)){if(k==='fullOutputPath'&&typeof x==='string'){tempFiles.add(x);temps.add(x);const b=await readFile(x,'utf8');result.findings.push({surface:'sdk-full-output-file',containsSyntheticSecret:contains(b),bytes:Buffer.byteLength(b)});}else if(typeof x==='object')await findPaths(x);}};
 const action=async(name,input={},expectedFailure=false)=>{if(name!=='browser_close'&&!(staleMirror&&name==='generator_write_test'))await prepared.assertCurrent();response=await invoke({operation:'action',session_ref:recordingRef,operation_id:'step-'+seq++,tool:name,input:name==='browser_close'?{...input,intent:'Close owned synthetic context'}:input,intent:'Observe synthetic fixture only; preserve private state and sources'},expectedFailure?'blocked':'completed');const serialized=JSON.stringify(response);result.tools.push({name,error:response.status==='blocked'||(response.output?.isError??false),containsSyntheticSecret:contains(serialized),mediaBlocks:mediaCount(response),bytes:Buffer.byteLength(serialized)});assert.equal(result.tools.at(-1).error,expectedFailure);await findPaths(response);return response;};
 await prepared.assertCurrent();
 await action('generator_setup_page',{seedFile:'tests/seed.spec.ts',project:'chromium',plan:'Observe local fixture heading with synthetic private cookie; no input or business writes'});
 const snapshot=await action('browser_snapshot');assert.ok(JSON.stringify(snapshot).includes('Privacy fixture'));
 inventory.id='privacy-mirror-observed';Object.assign(inventory.data.features[0],{coverage:'explored',discovery:'browser',source_refs:[declaration,...snapshot.artifact_refs],states:['Synthetic managed token present checked by seed','Privacy fixture heading observed'],gaps:[]});response=await invoke({operation:'inventory',inventory});inventoryRef=response.artifact_refs[0];
 await action('generator_read_log');
 const generated="import {test,expect} from '@playwright/test';test('fixture heading',async({page})=>{await page.goto('/');await expect(page.getByRole('heading',{name:'Privacy fixture'})).toBeVisible();});\n";
 if(staleMirror)await writeFile(join(rawRoot,'tests/seed.spec.ts'),(await readFile(join(rawRoot,'tests/seed.spec.ts'),'utf8'))+'\n// changed private snapshot\n');
 if(existingOutput)await writeFile(join(workspace,outputFile),'existing draft preserved\n');
 if(symlinkOutput){await mkdir(join(root,'outside'),{mode:0o700});await symlink(join(root,'outside'),join(workspace,'tests/publish'),'dir');}
 if(renewParent){await writeFile(parentPath,JSON.stringify({...JSON.parse(parentBytes),origins:[]}));await assert.rejects(prepared.assertCurrent());await assert.rejects(readFile(prepared.childEnv[managed.auth.reference]),{code:'ENOENT'});result.parentRenewalRevokedBeforeWriter=true;}
 else {let settled;const publication=new Promise(resolve=>{settled=resolve;});controls.connection.publicationSettled=settled;await action('generator_write_test',{fileName:outputFile,code:generated},faulty);if(lateMode==='disconnect')await Promise.race([publication,new Promise((_,reject)=>{const timer=setTimeout(()=>reject(Error('Late publication processing did not finish')),10000);timer.unref();})]);}

 if(lateMode){result.publicDraftExists=await readFile(join(workspace,outputFile)).then(()=>true,()=>false);result.privateNativeDraftExists=await readFile(join(rawRoot,outputFile)).then(b=>b.toString()===generated,()=>false);if(baseline){assert.equal(result.publicDraftExists,true);result.baselineLatePublicationReproduced=true;}else{assert.equal(result.publicDraftExists,false);assert.equal(result.privateNativeDraftExists,true);}}
 if(!faulty)assert.ok((await readFile(join(rawRoot,outputFile))).equals(await readFile(join(workspace,outputFile))));
 else if(!lateMode){
  await assert.rejects(readFile(join(rawRoot,outputFile)),{code:'ENOENT'});
  if(existingOutput){assert.equal(await readFile(join(workspace,outputFile),'utf8'),'existing draft preserved\n');result.existingOutputPreserved=true;}
  else await assert.rejects(readFile(join(workspace,outputFile)),{code:'ENOENT'});
  if(symlinkOutput){await assert.rejects(readFile(join(root,'outside/generated.spec.ts')),{code:'ENOENT'});result.symlinkOutsideWritePrevented=true;await rm(join(workspace,'tests/publish'));}
  if(staleMirror)result.staleSnapshotBlockedBeforeNativeWrite=true;
 }


 if(lateMode==='disconnect'){
  const runtime=resolvePlaywrightRuntime(rawRoot),reconnected=new McpClient({name:'synthetic-disconnected-snapshot-check',version:'1.0',roots:[{uri:pathToFileURL(rawRoot).href,name:'private-recording'}]});
  try{
   await reconnected.connect(new StdioTransport({command:process.execPath,args:[runtime.cli,'run-test-mcp-server','--headless','-c',runtime.config],cwd:rawRoot,env:prepared.childEnv,stderr:'pipe'}));
   result.newConnectionInitialized=true;result.newConnectionToolCount=(await reconnected.listTools()).length;assert.ok(result.newConnectionToolCount>0);
   let staleDispatched=false;await assert.rejects(async()=>{const operation=await prepared.beginOperation(new AbortController().signal);operation.assertActive();staleDispatched=true;await reconnected.callTool('generator_setup_page',{seedFile:'tests/seed.spec.ts',project:'chromium'});});assert.equal(staleDispatched,false);result.oldSnapshotRejectedBeforeNewConnectionBrowserDispatch=true;
  }finally{await reconnected.close();}
 }
 if(lateMode!=='disconnect')await action('browser_close');else result.closeActionNotReplayedAfterDisconnect=true;
 response=await invoke({operation:'finish',session_ref:recordingRef,inventory_ref:inventoryRef,initial_state:'Owned host recreates external synthetic managed token and new context; exact seed checks native authState and localStorage presence',completion:{initial_state_rebuildable:true,replaceable_data:true,stable_locators:true,assertion_sources:true,cleanup_owned:true},goal_reached:!faulty,gaps:faulty?[lateMode?'late-'+lateMode+'-publication-blocked':renewParent?'parent-authentication-changed':staleMirror?'private-mirror-snapshot-changed':existingOutput?'existing-output-preserved':'symlink-output-rejected']:[]});
 const final=await store.load(response.artifact_refs[0]);assert.equal(final.data.status,faulty?'partial':'complete',JSON.stringify(final.data.gaps));if(!faulty){assert.deepEqual(final.data.gaps,[]);assert.equal(final.data.script_refs.length,1);}else{assert.ok(final.data.gaps.includes(lateMode?'late-'+lateMode+'-publication-blocked':renewParent?'parent-authentication-changed':staleMirror?'private-mirror-snapshot-changed':existingOutput?'existing-output-preserved':'symlink-output-rejected'));assert.equal(final.data.script_refs.length,0);}
 assert.equal(process.env[managed.auth.reference],parentPath);if(!renewParent&&lateMode!=='renew')assert.ok((await readFile(parentPath)).equals(parentBytes));result.hostParentReferenceUnchanged=true;
 result.recordingStatus=final.data.status;result.recordingRef=response.artifact_refs[0];result.nativeRecordingSteps=final.data.steps.length;result.generatedScriptRef=final.data.script_refs[0];result.finishGaps=final.data.gaps;result.publicScriptEqualsNative=faulty?null:true;
 await cp(join(workspace,'qa'),join(output,'qa'),{recursive:true});if(!faulty)await cp(join(workspace,outputFile),join(output,'generated.spec.ts'));await cp(join(workspace,'playwright.config.mjs'),join(output,'playwright.config.mjs'));await cp(join(workspace,'tests/seed.spec.ts'),join(output,'seed.spec.ts'));
 async function inspect(path,label){for(const e of await readdir(path,{withFileTypes:true})){if(e.isSymbolicLink())continue;const p=join(path,e.name),rel=label+'/'+e.name;if(e.isDirectory())await inspect(p,rel);else{const b=await readFile(p);if(contains(b.toString()))result.findings.push({surface:'workspace-file',path:rel,containsSyntheticSecret:true,bytes:b.length});if(/\.(png|jpeg)$/.test(e.name))result.findings.push({surface:'workspace-media',path:rel,bytes:b.length});}}}
 await inspect(workspace,'work');
 if(protectedMode){
  assert.ok(result.tools.filter(t=>!['generator_write_test'].includes(t.name)).every(t=>!t.error));
  assert.ok(result.tools.every(t=>!t.containsSyntheticSecret&&t.mediaBlocks===0));
  assert.ok(!result.findings.some(f=>f.containsSyntheticSecret||f.surface==='workspace-media'));
  assert.ok(contains(await readFile(join(rawRoot,'protocol.ndjson'),'utf8')));result.rawProtocolRetainedPrivately=true;
  result.rawSnapshotRetainedPrivately='Protocol capture contains original setup/snapshot; no filename requested';
  result.nativeDraftPublication=faulty?'not-published-failure-preserved':'native-recording-finish-complete-byte-identical-exclusive-publication';
  result.status=faulty?(lateMode?(baseline?'BASELINE_LATE_PUBLICATION_REPRODUCED':'LATE_'+lateMode.toUpperCase()+'_PUBLICATION_BLOCKED_PRIVATE_NATIVE_DRAFT_RETAINED'):renewParent?'PARENT_RENEWAL_REVOKED_NATIVE_PARTIAL_RETAINED':staleMirror?'STALE_MIRROR_BLOCKED_NATIVE_PARTIAL_RETAINED':existingOutput?'EXISTING_OUTPUT_BLOCKED_NATIVE_PARTIAL_RETAINED':'SYMLINK_OUTPUT_BLOCKED_NATIVE_PARTIAL_RETAINED'):'PRIVATE_MIRROR_NATIVE_RECORDING_HANDOFF_COMPLETE_NOT_PRODUCT_DELIVERY';
 }else{
  assert.ok(result.tools.some(t=>t.containsSyntheticSecret),'Expected actual secret reflection through current MCP path');
  assert.ok(result.findings.some(f=>f.surface==='sdk-full-output-file'&&f.containsSyntheticSecret),'Expected SDK pre-hook temporary-output leak');
  assert.ok(result.findings.some(f=>f.surface==='workspace-file'&&f.containsSyntheticSecret),'Expected raw MCP file in public workspace');
  result.status='SYNTHETIC_PRIVATE_RECORDING_LEAK_REPRODUCED';
 }

}catch(error){result.errorClass=error.name;result.errorSummary=String(error.message).replaceAll(secret,'[SYNTHETIC]');process.exitCode=1;}
finally{
 if(session){await session.extensionRunner?.emit({type:'session_shutdown',reason:'shutdown'}).catch(()=>{});session.dispose();}
 try{await cp(join(workspace,'qa'),join(output,'qa'),{recursive:true});}catch{result.publicArtifactCopy='not-created-or-unavailable';}
 if(prepared)await prepared.revoke();if(manager)manager.dispose();
 if(server)await new Promise(r=>server.close(r));delete process.env.PI_UI_PRIVATE_RECORDING_PROBE;
 for(const path of tempFiles)await rm(path,{force:true});await rm(root,{recursive:true,force:true});result.ownedRawOutputsRemoved=true;
 await cp(new URL(import.meta.url),join(output,'harness.mjs'));await cp(join(repo,'.pi/skills/ui-testing-workflow/assets/private-recording-workspace.mjs'),join(output,'workspace-adapter.mjs'));await cp(new URL('./recording-disconnect-control.mjs',import.meta.url),join(output,'lifecycle-control.mjs'));if(protectedMode)await cp(new URL('./disconnect-recording-prototype.mjs',import.meta.url),join(output,'mirror-prototype.mjs'));await writeFile(join(output,'result.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({output,...result},null,2));
}
