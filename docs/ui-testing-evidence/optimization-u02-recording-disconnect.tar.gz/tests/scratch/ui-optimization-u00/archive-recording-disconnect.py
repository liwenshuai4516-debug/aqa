from pathlib import Path
import hashlib,json,tarfile,io,os,shutil
repo=Path.cwd();root=repo/'tests/scratch/ui-recording-disconnect';logs=repo/'tests/scratch/ui-optimization-u00'
sha=lambda b:hashlib.sha256(b).hexdigest()
names=['disconnect-guarded.log','disconnect-reconnect-guarded.log','disconnect-normal-control.log','disconnect-reconnect-guarded-v2.log','disconnect-normal-control-v2.log']
records={n:json.loads((logs/n).read_text()) for n in names}
late=records['disconnect-reconnect-guarded-v2.log'];normal=records['disconnect-normal-control-v2.log']
assert late['physicalCloseObserved'] and late['disconnectedSnapshotRejected'] and late['newConnectionInitialized'] and late['newConnectionToolCount']==87 and late['oldSnapshotRejectedBeforeNewConnectionBrowserDispatch']
assert not late['publicDraftExists'] and late['privateNativeDraftExists'] and late['recordingStatus']=='partial' and 'browser-cleanup-not-confirmed' in late['finishGaps']
assert normal['recordingStatus']=='complete' and normal['publicScriptEqualsNative'] and normal['finishGaps']==[]
for r in records.values():
 assert r['modelCalls']==r['formalRuns']==r['businessWrites']==0 and r['ownedRawOutputsRemoved']
 assert all(not t['containsSyntheticSecret'] and t['mediaBlocks']==0 for t in r['tools'])
verified=0
for d in root.iterdir():
 if not d.is_dir():continue
 (d/'.cleanup-keep').write_text('Retain physical disconnect evidence and harness preparation failures.\n')
 if (d/'seed.spec.ts').exists():
  (d/'tests').mkdir(exist_ok=True);(d/'tests/seed.spec.ts').write_bytes((d/'seed.spec.ts').read_bytes());(d/'package.json').write_bytes(b'{"type":"module"}')
 def walk(v):
  global verified
  if isinstance(v,dict):
   if isinstance(v.get('path'),str) and isinstance(v.get('sha256'),str):
    p=Path(v['path']);assert not p.is_absolute() and '..' not in p.parts
    assert sha((d/p).read_bytes())==v['sha256'],str(d/p);verified+=1
   for x in v.values():walk(x)
  elif isinstance(v,list):
   for x in v:walk(x)
 for p in (d/'qa').rglob('*.json'):walk(json.loads(p.read_text()))
 if (d/'seed.spec.ts').exists():walk(json.loads((d/'result.json').read_text()))
ledger_names=['u05-authorized-review-budget.json','pms-anonymous-authorized-review-budget.json']
ledgers={n:sha((logs/n).read_bytes()) for n in ledger_names}
assert ledgers[ledger_names[0]]=='34aaec3d27776ad96474be83f0be5a4eebe001fb41467afc69a4372c2b7e31ec'
text='''# 私密录制物理断连与新连接拒绝旧快照

2026-10-26，Electron权威项目“项目管理系统”的工程阶段证据。仅本机合成目标，模型调用、正式批次、真实业务写入均0。剩余2次PMS设计评审额度保留，未用于结果评审。

在真实SDK嵌套工具管线和Playwright 1.62.1 MCP中，原生generator_write_test成功响应到达、尚未公开发布时，直接关闭本轮StdioTransport。实际onClose已观察，私有受管快照随连接关闭撤销。等待原有异步响应处理结束后，公开草稿不存在、私有原生草稿字节与请求一致；未改草稿、未放宽writer。

新建另一真实MCP子进程连接，初始化及listTools成功（87工具），但旧快照beginOperation在浏览器工具派发前拒绝，未向新连接发送setup或重放旧动作。该新连接只验证握手/目录与旧身份失效，不是恢复原录制会话或业务上下文。

原生finish保留partial、4步骤、0脚本，缺口包括late-disconnect-publication-blocked、missing-generated-script、browser-cleanup-not-confirmed、goal-not-reached、tool-error-or-cancelled。未在断连后伪造browser_close成功。传输关闭及自有进程清理不替代原生浏览器清理确认。

独立正常对照使用新工作区/父身份/快照与新SDK会话，原生5步complete、gaps为空、1脚本，公开与原生草稿逐字节一致。这是独立正常对照，不是断线原会话续录证明。

准备历史两轮在扩展加载阶段失败：临时生成扩展误带仅适用于仓库位置的裸模块导入，模块无法解析，没有开始录制。保留当时源码及失败摘要；修正临时生成内容后才取得最终正反证据。首个物理关闭轮也保留，不以新轮覆盖。

公开响应、SDK长输出及工作区未检出本轮已知合成秘密和编码变体，媒体块0；私有原始协议含原值，结束时只清理本轮自有原始合成payload与进程。公开raw-log是过滤后的减少内容证据，不代表完整原始捕获。

当前仍为内部模块+隔离原型，产品record仍unsupported。未证明任意输入闭包、新凭据/嵌套JSON、所有协议分支、异常进程崩溃、完整重连续录、文件系统并发替换或Electron接入。整体计划继续active，PMS正式失败及report-2未独立结果评审状态不变。
'''
docdir=Path.home()/'Library/Application Support/Pi Agent Desktop/data/data-space/project-documents/e2f5d42d-2781-4e68-a452-4c87c7d1d346'
store=docdir.parent.parent/'store.json';before=store.read_bytes();snap=docdir/('recording-disconnect-'+Path(late['output']).name);snap.mkdir(mode=0o700)
for n,r in [('disconnect',late),('normal',normal)]:shutil.copytree(Path(r['output']),snap/n)
persisted=[]
for p in snap.rglob('*'):
 assert not p.is_symlink()
 os.chmod(p,0o700 if p.is_dir() else 0o600)
 if p.is_file():
  n,*parts=p.relative_to(snap).parts;original=Path((late if n=='disconnect' else normal)['output'])/Path(*parts)
  assert p.read_bytes()==original.read_bytes();persisted.append({'path':str(p.relative_to(snap)),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size})
doc=docdir/'OperationContract-recording-disconnect-2026-10-26.md'
with doc.open('x') as f:f.write(text)
os.chmod(doc,0o600);assert doc.read_text()==text and store.read_bytes()==before
files={}
for p in sorted(root.rglob('*')):
 if p.is_file():assert not p.is_symlink();files[str(p.relative_to(repo))]=p.read_bytes()
for n in [*names,'probe-recording-disconnect.mjs','disconnect-recording-prototype.mjs','recording-disconnect-control.mjs','archive-recording-disconnect.py']:
 p=logs/n;files[str(p.relative_to(repo))]=p.read_bytes()
n='.pi/skills/ui-testing-workflow/assets/private-recording-workspace.mjs';files[n]=(repo/n).read_bytes()
archive=repo/'docs/ui-testing-evidence/optimization-u02-recording-disconnect.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for n,b in sorted(files.items()):
  m=tarfile.TarInfo(n);m.size=len(b);m.mtime=0;t.addfile(m,io.BytesIO(b))
with tarfile.open(archive) as t:
 assert set(t.getnames())==set(files)
 for m in t:assert t.extractfile(m).read()==files[m.name]
index={'date':'2026-10-26','status':'PHYSICAL_DISCONNECT_LATE_PUBLICATION_BLOCKED_NEW_CONNECTION_REJECTS_OLD_SNAPSHOT_NORMAL_CONTROL_COMPLETE','plan_complete':False,'product_private_recording':'unsupported','modelCalls':0,'formalRuns':0,'businessWrites':0,'ledgerSha256':ledgers,'current_runs':{'disconnect':late,'normal':normal},'historical_runs':{n:r for n,r in records.items() if r not in [late,normal]},'refsVerified':verified,'document':{'path':str(doc),'sha256':sha(doc.read_bytes()),'storeUnchanged':True},'snapshot':{'path':str(snap),'files':persisted},'limits':['New connection only initialized/listed tools; no original-session recording recovery','Normal control is an independent new workspace/identity/session','Native browser-cleanup-not-confirmed gap retained','No product/Electron/private record enablement; generic privacy and filesystem races unproven','Raw synthetic payloads removed; public logs reduced'],'archive':{'path':str(archive.relative_to(repo)),'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'files':len(files),'roundtrip_verified':True},'files':[{'path':n,'sha256':sha(b),'bytes':len(b)} for n,b in sorted(files.items())]}
(repo/'docs/ui-testing-evidence/optimization-u02-recording-disconnect.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'files':len(files),'refs':verified,'snapshotFiles':len(persisted),'archiveBytes':archive.stat().st_size}))
