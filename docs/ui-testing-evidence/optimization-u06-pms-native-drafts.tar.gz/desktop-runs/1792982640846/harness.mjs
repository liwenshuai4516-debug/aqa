/** Connect the actual selected Data Space through Electron's normal authenticated renderer.
 * Temporary UI/agent profile; selected Data Space remains at its real location. No model calls.
 */
import assert from "node:assert/strict";
import { readFile, writeFile, mkdir, cp, readdir, lstat, access } from "node:fs/promises";
import { join } from "node:path";
import { homedir } from "node:os";
import { fileURLToPath } from "node:url";
import electron from "electron";
import { sha256 } from "pi-ui-testing";
import { ensureBuild } from "./lib/ensure-build.mjs";
import { portUp } from "./lib/port-utils.mjs";
import { launchNativeApp } from "./desktop/native-app.mjs";

assert.ok(process.argv.includes("--connect-selected-data"), "Explicit selected-data connection required");
assert.equal(process.env.PI_WEB_SMOKE_PREBUILT, "1", "Never rebuild inside this entry");
const repo = fileURLToPath(new URL("..", import.meta.url));
ensureBuild(repo, "pms-desktop-connection");
const output = join(repo, "tests/scratch/ui-pms-desktop-connection", String(Date.now()));
await mkdir(output, { recursive: true });
await cp(fileURLToPath(import.meta.url), join(output, "harness.mjs"));
const dataDir = join(homedir(), "Library/Application Support/Pi Agent Desktop/data");
const storePath = join(dataDir, "data-space/store.json"),
	before = await readFile(storePath);
// A new UI profile must not resume unrelated tasks from the selected data directory.
await assert.rejects(access(join(dataDir, "scheduler-tasks.json")), { code: "ENOENT" });
const pluginVersions = [];
for (const id of await readdir(join(dataDir, "plugins"))) {
	const directory = join(dataDir, "plugins", id);
	let source, installed;
	try {
		source = JSON.parse(await readFile(join(repo, "plugins", id, "manifest.json")));
		installed = JSON.parse(await readFile(join(directory, "manifest.json")));
	} catch {
		throw new Error("Plugin manifests require explicit reconciliation");
	}
	const linked = (await lstat(directory)).isSymbolicLink();
	assert.ok(
		linked || source.version.localeCompare(installed.version, undefined, { numeric: true }) <= 0,
		"Preserve installed plugin versions",
	);
	try {
		const schedule = JSON.parse(await readFile(join(directory, "schedules.json")));
		assert.equal(
			Array.isArray(schedule) ? schedule.length : (schedule.tasks ?? schedule.schedules ?? []).length,
			0,
			"Do not start saved plugin schedules",
		);
	} catch (error) {
		if (error.code !== "ENOENT") throw error;
	}
	pluginVersions.push({ id, installed: installed.version, source: source.version, linked });
}
const port = 18979;
assert.equal(await portUp(port), false, "Preserve existing listener");
const env = { ...process.env };
for (const key of Object.keys(env))
	if (
		/(API_KEY|AUTH_TOKEN|ACCESS_TOKEN|SECRET_ACCESS_KEY|SESSION_TOKEN)$/.test(key) ||
		/^(AWS_|GOOGLE_|GCLOUD_|AZURE_|PI_)/.test(key) ||
		["ELECTRON_RUN_AS_NODE", "NODE_OPTIONS"].includes(key)
	)
		delete env[key];
Object.assign(env, {
	PI_DESKTOP_USER_DATA: join(output, "ui-profile"),
	PI_CODING_AGENT_DIR: join(output, "agent"),
	PI_WEB_DATA_DIR: dataDir,
	PI_WEB_CWD: repo,
	PI_WEB_PORT: String(port),
	PI_WEB_PLUGIN_CATALOG_URL: "off",
	PI_WEB_SDK: "bundled",
});
const result = {
	status: "blocked",
	modelCalls: 0,
	nativeCaseImports: 0,
	selectedStoreModified: false,
	pluginVersions,
	actualDataDirectory: dataDir,
	temporaryUiAgentProfile: true,
	prebuiltServerSha256: sha256(await readFile(join(repo, "dist/server/index.js"))),
	prebuiltDesktopSha256: sha256(await readFile(join(repo, "dist/desktop/main.js"))),
};
await writeFile(join(output, "plan.json"), JSON.stringify(result, null, 2));
let app;
try {
	app = await launchNativeApp({ executablePath: electron, packaged: false, env });
	const page = await app.firstWindow();
	await page.waitForLoadState("domcontentloaded");
	result.renderer = await page.evaluate(() => ({
		protocol: location.protocol,
		rootPresent: !!document.querySelector("#root"),
		appPresent: !!document.querySelector(".app"),
		bodyChildTags: Array.from(document.body.children).map((node) => node.tagName),
		fixedSentinels: Object.fromEntries(
			["Cannot GET", "Not Found", "Cannot find module", "设置", "初始化", "WebSocket", "无法", "工作区", "登录"].map(
				(text) => [text, document.body.textContent.includes(text)],
			),
		),
		scriptPaths: Array.from(document.scripts).map((script) => (script.src ? new URL(script.src).pathname : "inline")),
	}));
	result.nativeState = await page.evaluate(async () => {
		let response;
		for (let attempt = 0; attempt < 20; attempt++) {
			response = await fetch("/plugins-api/data-space/state", { credentials: "same-origin" });
			if (response.status !== 404) break;
			await new Promise((resolve) => setTimeout(resolve, 250));
		}
		if (!response.ok || !response.headers.get("content-type")?.includes("application/json"))
			return {
				httpStatus: response.status,
				jsonResponse: response.headers.get("content-type")?.includes("application/json") ?? false,
				selectedProjectMatched: false,
			};
		const data = await response.json();
		const project = data.systems?.find((p) => p.id === "e2f5d42d-2781-4e68-a452-4c87c7d1d346");
		const environment = data.envs?.find(
			(e) => e.id === "f46a32da-2eac-43ca-86b8-2fa5eca5385c" && e.systemId === project?.id,
		);
		return {
			httpStatus: response.status,
			ok: data.ok,
			selectedProjectMatched: project?.name === "项目管理系统",
			selectedEnvironmentMatched: !!environment,
			revision: data.revision,
			modules: (data.modules ?? []).filter((x) => x.systemId === project?.id).length,
			features: (data.features ?? []).filter((x) => x.systemId === project?.id).length,
			cases: (data.cases ?? []).filter((x) => x.systemId === project?.id).length,
		};
	});
	result.status =
		result.nativeState.httpStatus === 200 &&
		result.nativeState.selectedProjectMatched &&
		result.nativeState.selectedEnvironmentMatched
			? "selected-desktop-native-connection-verified"
			: "native-connection-blocked";
} catch (error) {
	result.errorCategory = /Execution context was destroyed|navigation/i.test(error.message)
		? "renderer-navigation"
		: /closed|disposed/i.test(error.message)
			? "renderer-closed"
			: /Timeout/i.test(error.message)
				? "readiness-timeout"
				: /JSON|Unexpected token/i.test(error.message)
					? "response-not-json"
					: "other-runtime-error";
	result.runtimeDiagnostic = app
		? Object.fromEntries(
				[
					"Cannot find module",
					"ERR_MODULE_NOT_FOUND",
					"EADDRINUSE",
					"Failed to load",
					"401",
					"permission denied",
					"window loaded",
				].map((marker) => [marker, app.getLogs().includes(marker)]),
			)
		: undefined;
	result.blocker = "native-app-or-authenticated-renderer-unavailable";
} finally {
	if (app) {
		await app.close();
		result.ownedAppClosed = true;
	}
	result.selectedStoreModified = sha256(before) !== sha256(await readFile(storePath));
	await writeFile(join(output, "result.json"), JSON.stringify(result, null, 2));
}
console.log(JSON.stringify({ output, ...result }, null, 2));
assert.equal(result.selectedStoreModified, false, "Reconcile changes before any selected-store write");
assert.equal(result.status, "selected-desktop-native-connection-verified");
