# 经营合同：已入库原生用例草稿

状态：三条原生用例已录入 Electron 数据空间，全部为“草稿”、未评审、未绑定、未执行。

日期：2026-10-26；项目：项目管理系统（e2f5d42d-2781-4e68-a452-4c87c7d1d346）；环境：f46a32da-2eac-43ca-86b8-2fa5eca5385c。原生入库后revision10，重开桌面确认1模块、3功能、3条草稿及3个“草稿”状态标签。

本批依据为已冻结公开源码声明，不是确认后的业务需求；浏览器实际加载五份来源脚本的摘要核对已通过。不能用草稿入库替代设计批准、诊断或正式测试。

## 源码草稿：成功登录后的私有认证状态

台账ID：348a9dd2-d126-4751-a231-667865346ef6；功能ID：pms-source-authentication；原生ID：PMS-source-authentication。

前置条件：

- 未评审、未执行；仅由公开源码声明生成，不能用于正式运行。
- Private adapter and same-browser account match exist; generalized recording bridge still pending
- Future authorized successful login and single-tenant initialization; no credentials in case text

步骤及预期：

- 操作：在后续受控浏览器会话中复用私有登录配置，核对登录成功后的认证状态存在；只记录布尔值，不记录 token。
- 预期声明：private browser token presence after the declared successful login initialization toEqual true

## 源码草稿：账号与业务类型的草稿命名空间

台账ID：5dfda722-8021-4d9f-bf8f-cfbf9a3b92aa；功能ID：pms-source-drafts；原生ID：PMS-source-drafts。

前置条件：

- 未评审、未执行；仅由公开源码声明生成，不能用于正式运行。
- Source function hre constructs pms-business-drafts:${username}:${entityType}
- Actual OperationContract draft interaction, two owned account/entity inputs and cleanup remain unprepared

步骤及预期：

- 操作：准备隔离且归属明确的账号/业务类型组合；在后续受控草稿交互中核对存储命名空间分别包含该账号和该业务类型。当前不创建草稿。
- 预期声明：declared draft namespace varies with account and entity type toEqual {"accountScoped":true,"entityTypeScoped":true}

## 源码草稿：经营合同状态显示映射

台账ID：bcf63bd4-fdba-4507-9c6a-aef1ce8e05e8；功能ID：pms-source-contract-state；原生ID：PMS-source-contract-state。

前置条件：

- 未评审、未执行；仅由公开源码声明生成，不能用于正式运行。
- Source function RS maps contractStatus SIGNED to 已完成 before other branches
- DRAFT row must have no SIGNED or TERMINATED contractStatus; role and isolated controlled rows unprepared

步骤及预期：

- 操作：在后续隔离受控列表中分别提供无冲突的 DRAFT 和 SIGNED 记录，核对各自状态文本；当前不修改真实合同状态。
- 预期声明：state labels of isolated DRAFT and SIGNED contract rows toEqual {"DRAFT":"草稿","SIGNED":"已完成"}

## 来源及限制

原生cases引用：qa/ui/cases/pms-source-case-drafts-v2/manifest.json；SHA256：031a0574bd22758fdb0e96919e7aba6f716337b262ee1f14e8569b3f39a1e3e9。原生来源工作区保留.cleanup-keep，完整8文件公开快照另存于本项目source-drafts-031a0574bd22目录；没有迁移或改写台账原生来源。

账号已在临时浏览器核对且匿名对照跳转登录页，但业务角色、隔离测试数据、可靠清理及真实正常/错误诊断副本仍待准备。三条用例没有脚本候选或独立设计批准，不能直接执行。重复导入新增0、复用3，三个功能显式映射完整；环境配置摘要未变，没有登记执行结果。

本文保存为数据空间项目文件；应用目前没有文档索引实体，本文尚不在应用文档列表登记。三条用例则已在实际用例库显示。本次没有付费模型调用，也没有修改业务合同。
