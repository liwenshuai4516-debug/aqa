{
  "feature": "details",
  "scenario": "details-declared",
  "states": [
    "about selected",
    "details expanded",
    "details collapsed"
  ],
  "source": {
    "path": "qa/ui/scopes/declaration/fixture.mjs",
    "sha256": "f07cad393d22c4629c771ef7763de96b47d030b6730fbec222fd110da2b89cc5"
  },
  "expected": [
    "tab selection changes panel",
    "details expansion changes visibility"
  ],
  "observations": [
    {
      "path": "qa/ui/recordings/tester/events/action-41/response.json",
      "sha256": "9ceeac02c5339303334448494ae329d7763daa6424158442253020b053bc5f5f"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-44/response.json",
      "sha256": "7322f517ceb8b5f3bea354dbe65ddc54267709c2cd694e408c2f968a1e0ea9a4"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-46/response.json",
      "sha256": "079f0ff5fe1bc370b96a8c6af9ae11368b1d461a960588a5c26bacbfebc869a9"
    }
  ],
  "locators": {
    "query": "getByRole('textbox', { name: 'Query' })",
    "search": "getByRole('button', { name: 'Search' })",
    "reset": "getByRole('button', { name: 'Reset' })",
    "add": "getByRole('button', { name: 'Add' })",
    "name": "getByRole('textbox', { name: 'Name' })",
    "cancel": "getByRole('button', { name: 'Cancel' })",
    "save": "getByRole('button', { name: 'Save' })",
    "next": "getByRole('button', { name: 'Next' })",
    "previous": "getByRole('button', { name: 'Previous' })",
    "about": "getByRole('tab', { name: 'About' })",
    "details": "getByText('Details')"
  },
  "gaps": []
}