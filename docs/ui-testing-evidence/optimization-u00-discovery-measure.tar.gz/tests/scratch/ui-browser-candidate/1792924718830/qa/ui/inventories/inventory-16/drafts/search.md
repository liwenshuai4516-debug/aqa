{
  "feature": "search",
  "scenario": "search-declared",
  "states": [
    "filtered",
    "reset"
  ],
  "source": {
    "path": "qa/ui/scopes/declaration/fixture.mjs",
    "sha256": "f07cad393d22c4629c771ef7763de96b47d030b6730fbec222fd110da2b89cc5"
  },
  "expected": [
    "query filters names",
    "reset restores first page"
  ],
  "observations": [
    {
      "path": "qa/ui/recordings/tester/events/action-1/response.json",
      "sha256": "7df72f08893fd7b158937a3aec0663cac3fd61fa4382ab29b4afb86f71a2cc6f"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-6/response.json",
      "sha256": "794ff22dda67a8cd6dc355113382e6777497fb541e8f30c140a4af3fc127c21c"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-9/response.json",
      "sha256": "f8e39b693618bda4e215b7901271f3aa46df32dd565c95a0a00783cd58dd5a2a"
    }
  ],
  "locators": {
    "query": "getByRole('textbox', { name: 'Query' })",
    "search": "getByRole('button', { name: 'Search' })",
    "reset": "getByRole('button', { name: 'Reset' })"
  },
  "gaps": []
}