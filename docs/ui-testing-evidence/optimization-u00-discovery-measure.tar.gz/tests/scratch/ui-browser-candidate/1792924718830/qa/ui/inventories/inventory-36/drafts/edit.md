{
  "feature": "edit",
  "scenario": "edit-declared",
  "states": [
    "dialog open",
    "filled then cancelled",
    "saved once",
    "one persisted name after reload"
  ],
  "source": {
    "path": "qa/ui/scopes/declaration/fixture.mjs",
    "sha256": "f07cad393d22c4629c771ef7763de96b47d030b6730fbec222fd110da2b89cc5"
  },
  "expected": [
    "dialog opens and cancels without writes",
    "saved name survives reload"
  ],
  "observations": [
    {
      "path": "qa/ui/recordings/tester/events/action-12/response.json",
      "sha256": "b7c41b427abc769a48fa85f5df2d0a505c6bb7351aa6562b2b1518213ee09983"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-17/response.json",
      "sha256": "005c8fb05b1b54114729d625651ae58bb15a44f3a673354c4aedf576d7a941ae"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-19/response.json",
      "sha256": "466e047978f8cce5d2663d1ce9db48ad74f2521b69bda502b10059ddde6310c1"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-24/response.json",
      "sha256": "64f66a8fdcb9330dcc036832f9b50cd813b8785ee2073e1f67dc02b31ee01ac3"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-27/response.json",
      "sha256": "18a6259cc67020b5b02bb1ad8d6135663fcd59e6d7e264cfe73725a62da58772"
    }
  ],
  "locators": {
    "query": "getByRole('textbox', { name: 'Query' })",
    "search": "getByRole('button', { name: 'Search' })",
    "reset": "getByRole('button', { name: 'Reset' })",
    "add": "getByRole('button', { name: 'Add' })",
    "name": "getByRole('textbox', { name: 'Name' })",
    "cancel": "getByRole('button', { name: 'Cancel' })",
    "save": "getByRole('button', { name: 'Save' })"
  },
  "gaps": []
}