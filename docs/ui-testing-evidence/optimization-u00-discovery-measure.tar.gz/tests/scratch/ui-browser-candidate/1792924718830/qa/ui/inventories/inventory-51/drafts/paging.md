{
  "feature": "paging",
  "scenario": "paging-declared",
  "states": [
    "first page",
    "last page",
    "query retained across next and previous",
    "both page boundaries"
  ],
  "source": {
    "path": "qa/ui/scopes/declaration/fixture.mjs",
    "sha256": "f07cad393d22c4629c771ef7763de96b47d030b6730fbec222fd110da2b89cc5"
  },
  "expected": [
    "two rows per page",
    "next and previous retain query"
  ],
  "observations": [
    {
      "path": "qa/ui/recordings/tester/events/action-32/response.json",
      "sha256": "07b6bac9e1f756049438b47ad7b321ded6f67327a1b0bceb080a1edb4e412185"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-35/response.json",
      "sha256": "fc565954daa5c37931f080b0bb271069ca836e512b4c0fb26f3297f41c3ab39e"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-38/response.json",
      "sha256": "34c6d5593edaaaeab8e982ad2d7dab0236b621b8204fff456612a6305495297a"
    }
  ],
  "locators": {
    "query": "getByRole('textbox', { name: 'Query' })",
    "search": "getByRole('button', { name: 'Search' })",
    "reset": "getByRole('button', { name: 'Reset' })",
    "add": "getByRole('button', { name: 'Add' })",
    "name": "getByRole('textbox', { name: 'Name' })",
    "cancel": "getByRole('button', { name: 'Cancel' })",
    "save": "getByRole('button', { name: 'Save' })",
    "next": "getByRole('button', { name: 'Next' })",
    "previous": "getByRole('button', { name: 'Previous' })"
  },
  "gaps": []
}