import json,hashlib,tarfile,io
from pathlib import Path
repo=Path.cwd();folder='tests/scratch/ui-browser-candidate/1792924718830';root=repo/folder
sha=lambda b:hashlib.sha256(b).hexdigest()
r=json.loads((root/'result.json').read_text());m=json.loads((root/'measurement.json').read_text());plan=json.loads((root/'measurement-plan.json').read_text());nested=json.loads((root/'nested-calls.json').read_text())
assert r['status']=='PASS' and r['actions']==58 and r['staticIssues']==[]
assert r['modelCalls']==r['formalRunnerCalls']==r['businessRequests']==0
assert len(m['invocations'])==78 and len(nested)==58
assert plan['harness_sha256']==sha((root/'harness.mjs').read_bytes())==sha((repo/'tests/ui-function-discovery-test.mjs').read_bytes())
assert plan['observer_sha256']==sha((root/'observer.mjs').read_bytes())==sha((repo/'tests/lib/ui-discovery-measure.mjs').read_bytes())
refs={};historical={}
source_index=json.loads((repo/'docs/ui-testing-evidence/optimization-u05-source-candidate.json').read_text());source_archive=repo/source_index['evidence']['archive']
assert sha(source_archive.read_bytes())==r['sourceArchiveSha256']
source_tar=tarfile.open(source_archive)
def walk(v):
 if isinstance(v,dict):
  if isinstance(v.get('path'),str) and isinstance(v.get('sha256'),str):
   p=root/v['path']
   if p.is_file():assert sha(p.read_bytes())==v['sha256'],str(p);refs[v['path']]=v['sha256']
   else:
    assert sha(source_tar.extractfile(v['path']).read())==v['sha256'];historical[v['path']]=v['sha256']
  for item in v.values():walk(item)
 elif isinstance(v,list):
  for item in v:walk(item)
walk(r)
for p in (root/'qa').rglob('*.json'):walk(json.loads(p.read_text()))
assert json.loads((root/r['taskRef']['path']).read_text())['data']['state']=='blocked'
priorpath=repo/'docs/ui-testing-evidence/optimization-u05-approved-run.json';prior=json.loads(priorpath.read_text());ledger='tests/scratch/ui-optimization-u00/u05-authorized-review-budget.json'
assert sha((repo/ledger).read_bytes())==next(f['sha256'] for f in prior['files'] if f['path']==ledger)
files={}
def add(p):
 assert not p.is_symlink();n=str(p.relative_to(repo));assert not any(v in n.split('/') for v in ['ui-review-authority','private-authority','auth.json','models.json','node_modules']);files[n]=p.read_bytes()
for p in root.rglob('*'):
 if p.is_file():add(p)
for p in (repo/'tests/scratch').glob('u00-discovery-*'):
 if p.is_file() and p.name!='u00-discovery-archive.log':add(p)
for n in ['tests/ui-function-discovery-test.mjs','tests/lib/ui-discovery-measure.mjs','tests/scratch/ui-optimization-u00/archive-u00-discovery-measure.py']:add(repo/n)
a=repo/'docs/ui-testing-evidence/optimization-u00-discovery-measure.tar.gz'
with tarfile.open(a,'w:gz') as t:
 for n,b in sorted(files.items()):
  item=tarfile.TarInfo(n);item.size=len(b);item.mtime=0;t.addfile(item,io.BytesIO(b))
with tarfile.open(a) as t:
 assert set(t.getnames())==set(files)
 for item in t:assert t.extractfile(item).read()==files[item.name]
start,end=m['milestones'];endpoint_count=next(i+1 for i,v in enumerate(m['invocations']) if v['operation']=='candidate')
index={'date':'2026-10-25','status':'FIRST_DISCOVERY_TO_STATIC_CANDIDATE_MEASURED_FULL_BASELINE_PENDING','plan_complete':False,'evidence_root':folder,'model_calls':0,'fee_ledger_unchanged':True,'formal_runs':0,'cases':6,'sourced_assertions':13,'recording_actions':r['actions'],'mcp_action_counts':r['counts'],'host_tool_calls_through_candidate':endpoint_count,'host_tool_calls_with_gate_readback':len(m['invocations']),'milestones':m['milestones'],'discovery_to_candidate_ms':end['elapsed_ms']-start['elapsed_ms'],'discovery_to_candidate_host_fs':{k:end['fs_promises'][k]-start['fs_promises'][k] for k in end['fs_promises']},'candidate_static_check':next(v for v in m['invocations'] if v['operation']=='candidate'),'source_refs':refs,'historical_source_refs_verified_in_original_archive':historical,'direct_children':m['directChildren'],'validation':{'calibration':'Actual host read=1; caught throw retained without body; original restored','typecheck':'passed','vitest':'51 passed / 3 files','lint':'passed','protocol':'structure passed; no-tag history skipped','clean':'preview only, no deletion'},'limits':plan['unmeasured']+['Host async FS wrappers only; sync/native/OS I/O not measured','Direct host child starts are not complete nested MCP browser counts','New v1 synthesis remains blocked at design review, independent of old approved v4','One current-version engineering sample; no measured before/after benefit','U00/U02 and full Electron/OperationContract acceptance remain incomplete'],'archive':{'path':str(a.relative_to(repo)),'sha256':sha(a.read_bytes()),'bytes':a.stat().st_size,'files':len(files),'roundtrip_verified':True},'files':[{'path':n,'sha256':sha(b),'bytes':len(b)} for n,b in sorted(files.items())]}
(repo/'docs/ui-testing-evidence/optimization-u00-discovery-measure.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'files':len(files),'refs':len(refs),'bytes':a.stat().st_size,'endpoint_tool_calls':endpoint_count}))
