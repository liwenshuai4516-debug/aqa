import json,hashlib,tarfile,io
from pathlib import Path
repo=Path.cwd();root=repo/'tests/scratch/ui-browser-candidate/1792809587795';files={};refs={};sha=lambda b:hashlib.sha256(b).hexdigest()
def add(p):
 p=Path(p);assert not p.is_symlink();n=str(p.relative_to(repo));assert not any(v in n.split('/') for v in ['ui-review-authority','private-authority','auth.json','model-cache.json','node_modules']);files[n]=p.read_bytes()
def tree(p):
 for f in p.rglob('*'):
  if f.is_file():add(f)
def verify(ref):
 assert sha((root/ref['path']).read_bytes())==ref['sha256'],ref['path'];refs[ref['path']]=ref['sha256']
priors={}
for name in ['optimization-u05-approved-run','optimization-u00-approved-baseline']:
 p=repo/f'docs/ui-testing-evidence/{name}.json';prior=json.loads(p.read_text());assert sha((repo/prior['archive']['path']).read_bytes())==prior['archive']['sha256'];add(p);priors[name]=prior['archive']
ledger='tests/scratch/ui-optimization-u00/u05-authorized-review-budget.json';p=json.loads((repo/'docs/ui-testing-evidence/optimization-u05-approved-run.json').read_text());assert sha((repo/ledger).read_bytes())==next(f['sha256'] for f in p['files'] if f['path']==ledger)
samples=[]
for folder in ['1792923067121','1792923148938']:
 output=repo/f'tests/scratch/ui-approved-baseline/{folder}';r=json.loads((output/'result.json').read_text());assert r['status']=='PASS';assert r['results']['data']['counts']['passed']==6;assert r['results']['details']['assertion_reached_attempt_count']==13;assert r['nestedBrowserStarts']==1
 ids={p['pid'] for p in r['childProcesses']};nodes=[c for p in r['childProcesses'] for c in p['children'] if c['kind']=='node' and c['started']];assert len(ids)==2 and all(c['pid'] in ids for c in nodes);assert all(p['exit_code']==0 for p in r['childProcesses'])
 formal=next(s for s in r['samples'] if s['operation']=='existing-asset-to-run-terminal');assert sum(c['kind']=='browser' and c['started'] for c in formal['directChildren'])==1;assert all(c['pid'] in ids for c in formal['directChildren'] if c['kind']=='playwright-cli')
 for ref in r['immutable_refs']+[r['execution']['run_ref'],r['results']['results_ref'],r['task']['task_ref']]+r['execution']['run']['data']['output_refs']:verify(ref)
 tree(root/Path(r['execution']['run_ref']['path']).parent);tree(output);add(root/r['task']['task_ref']['path'])
 samples.append({'run_ref':r['execution']['run_ref'],'counts':r['results']['data']['counts'],'assertions_reached':13,'formal_elapsed_ms':formal['elapsed_ms'],'host_reads':sum(formal['files']['readFile'].values()),'host_scans':sum(formal['files']['readdir'].values()),'direct_children':formal['directChildren'],'nested_browser_starts':1,'node_records':r['childProcesses'],'task_state':r['task']['task']['data']['state'],'plan':r['plan']})
for folder in ['1792922994434','1792923040645']:tree(repo/f'tests/scratch/ui-child-observer-calibration/{folder}')
for name in ['tests/ui-approved-baseline-measure.mjs','tests/lib/ui-baseline-child-observer.mjs','tests/scratch/ui-optimization-u00/u00-child-observer-calibration.mjs','tests/scratch/ui-optimization-u00/archive-u00-child-observer.py']:add(repo/name)
for p in (repo/'tests/scratch/ui-optimization-u00').glob('u00-child-observer-*.log'):add(p)
archive=repo/'docs/ui-testing-evidence/optimization-u00-child-observer.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for n,b in sorted(files.items()):
  m=tarfile.TarInfo(n);m.size=len(b);m.mtime=0;t.addfile(m,io.BytesIO(b))
with tarfile.open(archive) as t:
 assert set(t.getnames())==set(files)
 for m in t:assert t.extractfile(m).read()==files[m.name]
index={'date':'2026-10-25','status':'NESTED_NODE_BROWSER_AND_ASYNC_FS_OBSERVED_FULL_BASELINE_INCOMPLETE','plan_complete':False,'model_calls':0,'fee_ledger_unchanged':True,'calibration':{'initial':'Failed: Node publishes diagnostic event before spawnargs are populated; raw records retained','fixed':'Classify after confirmed spawn; nested Node exactly one known readFile and one actual Chromium launch passed','raw_source_limit':'Initial failed observer source was not frozen separately; raw process records and failure log retained, no source reconstruction claimed'},'samples':samples,'prior_archives_verified':priors,'public_refs_verified':refs,'limits':['Per-process four async fs/promises APIs only; no OS-wide/synchronous I/O claim','Observed browser starts across host and inherited Node workers; navigation/snapshot counts still missing','Two samples with different history/observer checks; not optimization pairs','Node process intervals overlap; do not sum as end-to-end or CPU time','Fresh generation, old failure full analysis/recovery, full paired comparison and real Electron business acceptance remain incomplete','New regression tasks stop at run terminal, retain analyze blockers and do not inherit old report approval'],'validation':{'typecheck':'passed','vitest':'51 passed in 3 files','lint':'passed','protocol':'structure passed; no-tag history skip','desktop':'not run; observer-only test change','size':'passed','clean':'preview only; no deletion'},'archive':{'path':str(archive.relative_to(repo)),'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'files':len(files),'roundtrip_verified':True},'files':[{'path':n,'sha256':sha(b),'bytes':len(b)} for n,b in sorted(files.items())]}
(repo/'docs/ui-testing-evidence/optimization-u00-child-observer.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'files':len(files),'refs':len(refs),'bytes':archive.stat().st_size}))
