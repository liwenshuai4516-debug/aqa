from pathlib import Path
import hashlib,json,tarfile,io,os,shutil
repo=Path.cwd();root=repo/'tests/scratch/ui-recording-json';logs=repo/'tests/scratch/ui-optimization-u00';sha=lambda b:hashlib.sha256(b).hexdigest()
names={'baseline':'recording-json-baseline.log','normal':'recording-json-native-filter.log','cancel':'recording-json-native-cancel.log','rotation':'recording-json-rotation.log','encoded':'recording-json-native-encoded.log'}
records={n:json.loads((logs/l).read_text()) for n,l in names.items()}
assert records['baseline']['nestedStorageLeakReproduced']
assert records['rotation']['runtimeAuthenticationLeakReproduced'] and records['rotation']['nativeFilterReused']
assert all(not t['containsInitialSecret'] for t in records['rotation']['tools']) and any(t['containsRotatedSecret'] for t in records['rotation']['tools'])
for n in ['normal','encoded']:
 assert records[n]['recordingStatus']=='complete' and records[n]['publicScriptEqualsNative'] and records[n]['finishGaps']==[]
assert records['encoded']['allFixtureEncodingVariantsObservedPrivately']
assert records['cancel']['recordingStatus']=='partial' and not records['cancel']['publicDraftExists'] and records['cancel']['privateNativeDraftExists']
for n,r in records.items():
 assert r['modelCalls']==r['formalRuns']==r['businessWrites']==0 and r['ownedRawOutputsRemoved']
 if n not in ['baseline','rotation']:assert all(not t['containsSyntheticSecret'] and not t['mediaBlocks'] for t in r['tools'])
verified=0
for d in root.iterdir():
 if not d.is_dir():continue
 (d/'.cleanup-keep').write_text('Retain privacy regression summaries and reduced public evidence; raw synthetic payload removed.\n')
 if (d/'seed.spec.ts').exists():
  (d/'tests').mkdir(exist_ok=True);(d/'tests/seed.spec.ts').write_bytes((d/'seed.spec.ts').read_bytes());(d/'package.json').write_bytes(b'{"type":"module"}')
 def walk(v):
  global verified
  if isinstance(v,dict):
   if isinstance(v.get('path'),str) and isinstance(v.get('sha256'),str):
    p=Path(v['path']);assert not p.is_absolute() and '..' not in p.parts;assert sha((d/p).read_bytes())==v['sha256'],str(d/p);verified+=1
   for x in v.values():walk(x)
  elif isinstance(v,list):
   for x in v:walk(x)
 for p in (d/'qa').rglob('*.json'):walk(json.loads(p.read_text()))
 r=json.loads((d/'result.json').read_text());walk(r['snapshot']['receipt']['inputs'])
 if (d/'qa').exists():walk(r['recordingRef']);walk(r.get('generatedScriptRef'))
ledger_names=['u05-authorized-review-budget.json','pms-anonymous-authorized-review-budget.json'];ledgers={n:sha((logs/n).read_bytes()) for n in ledger_names}
assert ledgers==json.loads((repo/'docs/ui-testing-evidence/optimization-u02-recording-adapter.json').read_text())['ledgerSha256']
text=(logs/'recording-json-document.md').read_text()
docdir=Path.home()/'Library/Application Support/Pi Agent Desktop/data/data-space/project-documents/e2f5d42d-2781-4e68-a452-4c87c7d1d346';store=docdir.parent.parent/'store.json';before=store.read_bytes();snap=docdir/('recording-json-'+Path(records['normal']['output']).name);snap.mkdir(mode=0o700)
for n,r in records.items():shutil.copytree(Path(r['output']),snap/n)
persisted=[]
for p in snap.rglob('*'):
 assert not p.is_symlink();os.chmod(p,0o700 if p.is_dir() else 0o600)
 if p.is_file():
  n,*parts=p.relative_to(snap).parts;assert p.read_bytes()==(Path(records[n]['output'])/Path(*parts)).read_bytes();persisted.append({'path':str(p.relative_to(snap)),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size})
doc=docdir/'OperationContract-recording-json-2026-10-26.md'
with doc.open('x') as f:f.write(text)
os.chmod(doc,0o600);assert doc.read_text()==text and store.read_bytes()==before
files={}
for p in root.rglob('*'):
 if p.is_file():assert not p.is_symlink();files[str(p.relative_to(repo))]=p.read_bytes()
for n in [*names.values(),'probe-recording-json.mjs','probe-recording-json-rotation.mjs','json-recording-prototype.mjs','recording-disconnect-control.mjs','archive-recording-json.py','recording-json-document.md','recording-json-unit.log','recording-json-sdk-integration.log','recording-json-desktop-visibility.log']:
 p=logs/n;files[str(p.relative_to(repo))]=p.read_bytes()
for n in ['bundle-manifest.json','assets/runtime/src/index.ts','assets/runtime/src/private-evidence.ts','assets/runtime/package.json']:
 p=logs/'u02-recording-json-export'/n;files[str(p.relative_to(repo))]=p.read_bytes()
visibility=json.loads((logs/'recording-json-desktop-visibility.log').read_text());assert visibility['status']=='PASS'
for p in Path(visibility['evidence']).rglob('*'):
 if p.is_file():files[str(p.relative_to(repo))]=p.read_bytes()
archive=repo/'docs/ui-testing-evidence/optimization-u02-recording-json.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for n,b in sorted(files.items()):
  m=tarfile.TarInfo(n);m.size=len(b);m.mtime=0;t.addfile(m,io.BytesIO(b))
with tarfile.open(archive) as t:
 assert set(t.getnames())==set(files)
 for m in t:assert t.extractfile(m).read()==files[m.name]
bundle=repo/'.pi/skills/ui-testing-workflow/assets/pi-ui-testing-0.1.13.tgz';upstream=json.loads((logs/'u02-recording-json-export/bundle-manifest.json').read_text())
with tarfile.open(bundle) as t:assert t.extractfile('package/src/private-evidence.ts').read()==(logs/'u02-recording-json-export/assets/runtime/src/private-evidence.ts').read_bytes()
index={'date':'2026-10-26','status':'NESTED_JSON_LEAK_REPRODUCED_NATIVE_FILTER_REUSED_ROTATED_COOKIE_STILL_LEAKS','plan_complete':False,'product_private_recording':'unsupported','current_runs':records,'refsVerified':verified,'modelCalls':0,'formalRuns':0,'businessWrites':0,'ledgerSha256':ledgers,'runtime':{'version':'0.1.13','path':str(bundle.relative_to(repo)),'sha256':sha(bundle.read_bytes()),'sourceCommit':upstream['source_commit'],'upstreamPushed':False,'privatePolicyUnchangedFrom012':True},'verification':{'nativeTests':'14 private-evidence/environment tests passed; observed tool output, raw log not saved','typecheck':'all five configs passed','vitest':'6 files 34 tests passed','sdkIntegration':'passed','desktopVisibility':visibility,'lint':'passed','protocol':'passed; tag heuristic unavailable','size':'passed'},'unretainedRefs':{'baseline':records['baseline']['recordingRef'],'rotation':records['rotation']['recordingRef'],'reason':'Raw public QA contained synthetic secrets; removed with owned raw payload, only reduced metrics/source retained; refs not claimed resolvable'},'document':{'path':str(doc),'sha256':sha(doc.read_bytes()),'storeUnchanged':True},'snapshot':{'path':str(snap),'files':persisted},'limits':['Native complete does not establish privacy: baseline/rotation remain privacy failures','Runtime Set-Cookie not learned before SDK publication; product record remains unsupported','No real PMS private recording, arbitrary secret/encoding, full protocol or filesystem race proof','Raw synthetic payloads removed, public logs reduced; two leak-run manifests not retained'],'archive':{'path':str(archive.relative_to(repo)),'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'files':len(files),'roundtrip_verified':True},'files':[{'path':n,'sha256':sha(b),'bytes':len(b)} for n,b in sorted(files.items())]}
(repo/'docs/ui-testing-evidence/optimization-u02-recording-json.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'files':len(files),'refs':verified,'snapshotFiles':len(persisted),'archiveBytes':archive.stat().st_size}))
