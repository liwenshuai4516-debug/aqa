# 私密录制 JSON 叶值复用与运行中认证缺口

2026-10-26，Electron 权威项目“项目管理系统”的工程阶段证据。仅本机合成目标，模型调用、正式批次、真实业务写入均 0；PMS 剩余 2 次设计评审额度未使用。

旧内部录制原型只过滤完整 cookie/localStorage 存储值。将同一合成 token 放入 JSON 的 session.credentials[0].token，seed 通过原生 authState 检查并将实际 localStorage 子值与页面内容比对，真实 SDK/MCP 的公开 setup/snapshot、SDK 长输出及工作区记录仍出现子值。原生 finish 虽为 complete、1 草稿，不能当隐私验收通过；失败未被删除或改成 partial。

原生 PrivateEvidence 早已有嵌套 JSON 字符串叶值及编码过滤。上游 0.1.13 仅从主入口导出该类，测试改为消费主入口；private-evidence.ts 及其编译 JS 与 0.1.12 逐字节一致，没有复制、改写过滤规则。上游本地提交 f8fad767efddf1f6987c69215e0a66caa5564c32，未推送上游。项目分发包和 e2e 锁定依赖更新到 0.1.13，SHA-256 fd3f902d3828b5f53c6c9de5112d623e319d2d509cb2022b377e506e54f250c4，安装完整性回读一致。

新内部原型在 PrivateEvidence.create 的私有目录内派生受管录制副本，直接复用其 text 过滤；原始 MCP 协议仍先写私有目录，媒体继续隐藏，原生 writer 字节校验和生命周期发布守卫保持。JSON 正常对照 5 步 complete、gaps=[]、1 草稿且公开/原生字节一致，公开响应、SDK 长输出、工作区未检出该合成叶值；取消对照 partial、0 草稿，私有原生草稿保留、公开不存在。额外编码轮将原文、JSON 字符串形式、URI/URL、Base64/Base64URL 变体同时反射（相同变体去重），私有协议确认实际出现，公开面扫描未检出，仍 5 步 complete。

运行中轮换反例：本机响应新增 HttpOnly qa_rotated cookie 并将其反射到页面，seed 检查浏览器确已收到 cookie。已使用原生初始过滤器，公开响应中的初始 JSON token 不再出现，但新 cookie 仍出现在 setup/snapshot 和 SDK 长输出。原生 finish 为 complete，隐私检验明确失败；未把原生 complete 等同安全、未从响应正文任意收集字符串伪造修复、未开放产品私密 record。需要后续在公开输出前可靠收集实际新增认证值。

泄露基线和轮换反例的原始公开 QA、私有协议及 SDK 临时输出在本轮归属清理时删除，只保存减少内容后的结果指标、源码和安全草稿；这两个旧 result 中的原生 manifest 引用不是可重读的完整原始证据。正常、取消和编码轮保存可核验公开 QA，原始合成私密 payload 也按归属清理。所有结果/脚本原文未被改写来制造通过。

原生私密证据及环境测试 14 项通过，完整五配置 typecheck、相关 6 文件 34 项 Vitest、lint、协议和 size 检查通过；协议 tag 启发式无可用 tag 而跳过。真实 SDK 集成 passed、隔离 Electron 可见性 PASS：技能页、快捷入口、禁用/启用及重载持久、MCP 连接与重连均保留通过，未验证真实业务私密录制。复用已有构建，未重启用户应用或修改个人安装。

文档和公开快照保存到权威项目目录，0700/0600、回读一致，store 未写；文件保存不代表应用文档索引显示或正式结果入库。产品 record 仍 unsupported。运行中新凭据实时收集、通用输入闭包、协议结构冲突、文件系统竞态、完整重连续录、Electron 业务全链和真实角色/租户/数据仍待完成，整体计划继续 active。
