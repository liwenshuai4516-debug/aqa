# 经营合同：预期依据草稿（源码声明）

状态：未评审、未执行。仅登记公开部署源码声明，不代替产品需求或真实浏览器验收。

项目：项目管理系统（Electron 桌面数据空间）
项目 ID：e2f5d42d-2781-4e68-a452-4c87c7d1d346
环境 ID：f46a32da-2eac-43ca-86b8-2fa5eca5385c
读取版本：revision 8
目标：http://192.168.90.224:8238/pms/OperationContract
日期：2026-10-26
授权依据：用户确认以 Electron 桌面数据空间为准，后续预期与用例保存到该项目。

## 已登记的声明依据

| 编号 | 功能 | 声明中的预期 | 来源 | 当前验证状态 |
| --- | --- | --- | --- | --- |
| PMS-SRC-01 | 登录与权限初始化 | 登录响应读取 data.token；通过 token 请求头发送认证。登录后初始化租户、客户端及 authorized-resource 权限资源。 | public-source/app.js.json、login.js.json、auth.js.json、tenant.js.json、permission.js.json | 真实登录及权限接口已返回成功；私有引用可被原生 authState 解析；浏览器身份与角色尚未验证 |
| PMS-SRC-02 | 草稿隔离 | 草稿存储键包含 pms-business-drafts、当前账号 username 和业务实体；不可将其他账号/实体的草稿当本功能草稿。 | public-source/app.js.json 中 function hre(e) | 仅源码发现；逐功能保存、恢复和清理尚未录制 |
| PMS-SRC-03 | 合同状态 | DRAFT 映射为“草稿”；SIGNED 映射为“已完成”。具体状态转换需另有操作与服务端结果证据。 | public-source/app.js.json 中 function RS(e) | 仅源码发现；真实状态转换未执行 |

源码摘录及完整资源 SHA256：仓库 docs/ui-testing-evidence/optimization-real-target-source-admission.json 与同名 tar.gz。
原生范围：qa/ui/scopes/operation-contract-source-admission/manifest.json。
原生功能清单：qa/ui/inventories/operation-contract-source-admission/manifest.json。
上述引用位于 source-only 证据归档内；研究项目/环境标签不冒充本数据空间 ID。

## 待补齐的真实依据

- 尚未找到产品需求文档：必填规则、金额边界、审批完成状态及错误文案不得沿用旧版示例。
- 当前账号具有哪些实际角色、可访问功能以及可写业务对象尚未通过浏览器核验。
- 权限隐藏、加载/空/错误状态、查询/分页和逐功能草稿需要真实页面证据。
- 正常/错误诊断副本、隔离测试数据及归属清理方式未验证，正式执行尚未放行。
- 项目专用私有认证适配器不等于数据空间插件已具备通用浏览器凭据桥接；录制证据隐私仍待完成。

## 存储与交接说明

本文件保存于所选数据空间的 project-documents 项目目录；当前数据空间没有独立文档索引/编辑入口，所以尚未在应用界面登记为文档，也未录入用例库。没有创建占位用例、自动化绑定或执行结果。后续生成原生用例后，沿用原生 import 及所选环境归档；草稿入库不代表设计批准或测试通过。
