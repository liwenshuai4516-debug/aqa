import json,hashlib,tarfile,io
from pathlib import Path
repo=Path.cwd();root=repo/'tests/scratch/ui-browser-candidate/1792809587795';files={};sha=lambda b:hashlib.sha256(b).hexdigest()
def add(p,name=None):
 p=Path(p);assert not p.is_symlink();files[name or str(p.relative_to(repo))]=p.read_bytes()
revision=json.loads((root/'browser-v4-diagnostics.json').read_text());review=json.loads((root/'native-review-10-authorization4.json').read_text());out=json.loads(review['tool']['content'][0]['text'])['output'];diag=json.loads(json.loads((root/'native-diagnose.json').read_text())['tool']['content'][0]['text'])['output'];formal=json.loads((root/'browser-v4-formal.json').read_text());draft=json.loads((root/'browser-v4-report-draft.json').read_text())
for sub in ['reviews','diagnostics']:
 for p in (root/Path(revision['assetRef']['path']).parent/sub).rglob('*'):
  if p.is_file():add(p)
runpath=root/Path(formal['execution']['run_ref']['path']).parent
for p in runpath.rglob('*'):
 if p.is_file():add(p)
for name in ['authorization4-preflight.json','native-review-10-authorization4.json','native-diagnose.json','browser-v4-formal.json','browser-v4-report-draft.json','authorization4-readback.json','native-result-review-11-authorization4.json','browser-v4-delivery.json','qa/ui/tasks/u05-tester/manifest.json','qa/ui/tasks/u05-browser-v4-execute/manifest.json','qa/ui/tasks/u05-browser-v4-execute/active-run.json']:
 p=root/name
 if p.exists():add(p)
for name in ['tests/ui-multifunction-native-review.mjs','tests/ui-browser-approved-run.mjs','tests/scratch/ui-optimization-u00/u05-authorized-review-budget.json','tests/scratch/ui-optimization-u00/u05-v4-review-preflight.mjs','tests/scratch/ui-optimization-u00/archive-u05-authorization4.py']:add(repo/name)
for p in (repo/'tests/scratch/ui-optimization-u00').glob('u05-authorization4-*.log'):add(p)
for name in ['result.json','desktop.log']:add(repo/'tests/scratch/ui-workflow-visibility/1792917978956'/name)
prior_path=repo/'docs/ui-testing-evidence/optimization-u05-browser-diagnostics.json';prior=json.loads(prior_path.read_text());assert sha((repo/prior['archive']['path']).read_bytes())==prior['archive']['sha256'];add(prior_path)
delivery=json.loads((root/'browser-v4-delivery.json').read_text());result_review=json.loads(json.loads((root/'native-result-review-11-authorization4.json').read_text())['tool']['content'][0]['text'])['output']
assert delivery['completed']['task']['data']['state']=='completed';assert result_review['decision']=='approved'
# Check all public references owned by design approval, diagnosis summary, run outputs and report draft.
roots=[delivery['delivery_ref'],json.loads((root/result_review['review_ref']['path']).read_text()),json.loads((root/out['review_ref']['path']).read_text()),diag,formal['execution']['run'],json.loads((root/draft['report']['report_ref']['path']).read_text())];refs={}
while roots:
 value=roots.pop()
 if isinstance(value,list):roots.extend(value)
 elif isinstance(value,dict):
  if isinstance(value.get('path'),str) and len(value.get('sha256',''))==64:
   p=root/value['path'];assert sha(p.read_bytes())==value['sha256'],value['path'];refs[value['path']]=value['sha256']
  else:roots.extend(value.values())
ledger=json.loads((repo/'tests/scratch/ui-optimization-u00/u05-authorized-review-budget.json').read_text());batch=ledger['attempts'][ledger['authorization_extensions'][-1]['prior_provider_attempts']:];reserve=sum(a['reserved_usd'] for a in batch);assert reserve<=1
archive=repo/'docs/ui-testing-evidence/optimization-u05-approved-run.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for name,data in sorted(files.items()):
  assert not any(x in name.split('/') for x in ['ui-review-authority','private-authority','node_modules','model-cache.json','auth.json'])
  m=tarfile.TarInfo(name);m.size=len(data);m.mtime=0;t.addfile(m,io.BytesIO(data))
with tarfile.open(archive) as t:
 assert set(t.getnames())==set(files)
 for m in t:assert t.extractfile(m).read()==files[m.name]
index={'date':'2026-10-25','status':'SYNTHETIC_FORMAL_PASSED_REPORT_APPROVED_DELIVERED','native_version':'0.1.7','asset_ref':revision['assetRef'],'design_review':out,'provider':'gpt/gpt-6.1-sol','model_usage':[{'usage':a['usage'],'provider_duration_ms':a['duration_ms']} for a in batch],'authorization4':{'authorized_calls':3,'used_calls':len(batch),'remaining_call_scope':'One design-review call only; one authorized report reallocation consumed','remaining_global_native_calls':ledger['max_calls']-len(ledger['native_attempts']),'reserved_usd':reserve,'additional_limit_usd':1,'billing':'Conservative reservation, not invoice; registry zero is not free; original history retained','input_limit_bytes':ledger['max_input_bytes']},'diagnostics':{'summary_ref':diag['summary_ref'],'status':diag['status'],'runtime_ready':diag['runtime_ready'],'rounds':len(diag['rounds']),'positive_cases_passed':6,'fault_probes_detected':14,'distinct_assertion_ids':13,'native_case_attempts':90,'native_passed_attempts':76,'intentional_fault_failures':14,'problems':[p for r in diag['rounds'] for p in r['problems']]},'formal_run':{'run_ref':formal['execution']['run_ref'],'counts':formal['results']['data']['counts'],'assertion_reached_attempt_count':formal['results']['details']['assertion_reached_attempt_count'],'complete':formal['results']['details']['complete'],'issues':formal['results']['details']['issues']},'report_candidate':draft['report'],'report_review':result_review,'delivery_ref':delivery['delivery_ref'],'original_discovery_task':'completed by native checkpoint after trusted review and diagnostics','formal_execution_task':'completed; native checkpoint delivered independently approved complete report','current_private_authority_not_archived':True,'historical_annotation_limit':'Immutable candidate/cases still contain preparation-time unreviewed/no-diagnostic gap text. Current native authority and runtime results prove the later state; original files were not rewritten.','validation':{'typecheck':'passed','vitest':'14 earlier checks; final 51 passed in 3 registration/guard/workflow files','integration':'19 passed','electron':'7 passed; settings/skills/MCP visibility, not full model/business desktop chain','lint':'passed','protocol':'structure passed, history check skipped (no tag)'},'plan_complete':False,'remaining_plan':'Real OperationContract admission/auth mapping; Electron end-to-end and complete U00 baseline/U03/U07/U09 and M1/M2 remain incomplete','prior_candidate_archive_verified':prior['archive'],'public_owned_references_verified':refs,'archive':{'path':str(archive.relative_to(repo)),'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'files':len(files),'roundtrip_verified':True},'files':[{'path':n,'sha256':sha(b),'bytes':len(b)} for n,b in sorted(files.items())]}
(repo/'docs/ui-testing-evidence/optimization-u05-approved-run.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'files':len(files),'archive_bytes':archive.stat().st_size,'public_refs_verified':len(refs),'reserved_usd':reserve}))
