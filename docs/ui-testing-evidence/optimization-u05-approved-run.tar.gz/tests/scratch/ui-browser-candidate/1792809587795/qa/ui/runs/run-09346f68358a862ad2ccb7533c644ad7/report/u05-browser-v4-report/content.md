# UI 测试结果

范围：All frozen assertions evidenced or explicitly blocked.

批次：run-09346f68358a862ad2ccb7533c644ad7；部署：u00-1；角色：tester and viewer in separate contexts

冻结计划：6；实际启动：6；稳定通过率：100.00%

| 状态 | 实例数 |
|---|---:|
| passed | 6 |
| failed | 0 |
| blocked | 0 |
| skipped | 0 |
| cancelled | 0 |
| not-run | 0 |
| flaky | 0 |
| unknown | 0 |

原始结果：[qa/ui/runs/run-09346f68358a862ad2ccb7533c644ad7/report.json](../../report.json)

确定性对账与证据状态：[qa/ui/runs/run-09346f68358a862ad2ccb7533c644ad7/results/u05-browser-v4-results/reconciliation.json](../../results/u05-browser-v4-results/reconciliation.json)

设计评估（仅本批次资产修订）：候选用例 6；通过 6；待修订 0；阻塞 0；结论 approved。

已登记功能清单：6；清单内尚无用例的功能点：无。

未探索范围（不计入上述清单分母）：Other products and undeclared roles。

功能覆盖：冻结用例涉及 6 个功能点，其中 6 个获得执行结论；不代表全产品覆盖。

## 模块、功能与优先级统计

```json
{
  "by_module": {
    "names": {
      "passed": 6,
      "failed": 0,
      "blocked": 0,
      "skipped": 0,
      "cancelled": 0,
      "not-run": 0,
      "flaky": 0,
      "unknown": 0
    }
  },
  "by_feature": {
    "names/search": {
      "passed": 1,
      "failed": 0,
      "blocked": 0,
      "skipped": 0,
      "cancelled": 0,
      "not-run": 0,
      "flaky": 0,
      "unknown": 0
    },
    "names/edit": {
      "passed": 1,
      "failed": 0,
      "blocked": 0,
      "skipped": 0,
      "cancelled": 0,
      "not-run": 0,
      "flaky": 0,
      "unknown": 0
    },
    "names/details": {
      "passed": 1,
      "failed": 0,
      "blocked": 0,
      "skipped": 0,
      "cancelled": 0,
      "not-run": 0,
      "flaky": 0,
      "unknown": 0
    },
    "names/paging": {
      "passed": 1,
      "failed": 0,
      "blocked": 0,
      "skipped": 0,
      "cancelled": 0,
      "not-run": 0,
      "flaky": 0,
      "unknown": 0
    },
    "names/permission": {
      "passed": 1,
      "failed": 0,
      "blocked": 0,
      "skipped": 0,
      "cancelled": 0,
      "not-run": 0,
      "flaky": 0,
      "unknown": 0
    },
    "names/states": {
      "passed": 1,
      "failed": 0,
      "blocked": 0,
      "skipped": 0,
      "cancelled": 0,
      "not-run": 0,
      "flaky": 0,
      "unknown": 0
    }
  },
  "by_priority": {
    "P0": {
      "passed": 6,
      "failed": 0,
      "blocked": 0,
      "skipped": 0,
      "cancelled": 0,
      "not-run": 0,
      "flaky": 0,
      "unknown": 0
    }
  },
  "by_oracle": {
    "requirement": [],
    "declaration": [
      "instance-3676c8b6dd7f5d14900d8ab444ba18a7",
      "instance-a523bb3f36aa0ea9cb84e7996f857270",
      "instance-2f4bd473beddd0519837fb76b7d2f00c",
      "instance-59613436ac54f4165bf739dbe7a2a33b",
      "instance-303d072eb55c2632d3ba7a41676f94ab",
      "instance-2487f9659a29078bc38ed50f720d019b"
    ],
    "baseline": []
  }
}
```

## 观察、解释与下一动作

## 数据清理与残留

```json
[
  {
    "instance_id": "instance-3676c8b6dd7f5d14900d8ab444ba18a7",
    "cleanup": [],
    "evidence_gaps": []
  },
  {
    "instance_id": "instance-a523bb3f36aa0ea9cb84e7996f857270",
    "cleanup": [],
    "evidence_gaps": []
  },
  {
    "instance_id": "instance-2f4bd473beddd0519837fb76b7d2f00c",
    "cleanup": [],
    "evidence_gaps": []
  },
  {
    "instance_id": "instance-59613436ac54f4165bf739dbe7a2a33b",
    "cleanup": [],
    "evidence_gaps": []
  },
  {
    "instance_id": "instance-303d072eb55c2632d3ba7a41676f94ab",
    "cleanup": [],
    "evidence_gaps": []
  },
  {
    "instance_id": "instance-2487f9659a29078bc38ed50f720d019b",
    "cleanup": [],
    "evidence_gaps": []
  }
]
```

## 限制与待处理事项

- 范围仅限冻结计划，不代表全产品或代码覆盖率；attempt 与 case 分开统计
- 候选与设计评估数量仅统计本批次资产修订；不推断其他候选或历史轮次。未登记的信息为不可用，不填零
- 未探索：Other products and undeclared roles
- Candidate synthesis is not execution: seed/browser observations support discovery; all thirteen script assertions require independent review and diagnostics.
- Candidate synthesis is not execution: seed/browser observations support discovery; all thirteen script assertions require independent review and diagnostics.
- 14 probes/13 assertions are HTTP/static preparation only; no trusted review, diagnostic observation or runtime admission. All owned servers stopped.

失败处理：产品问题仅形成待确认缺陷草稿；脚本问题新建修订并重审；环境/数据恢复后新批次执行；证据不足先补证据，不修改历史结果。

后续处理草稿：[缺陷与回归建议](follow-up.json)；未向外部系统提交。
