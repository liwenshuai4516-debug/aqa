# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: qa/ui/assets/u05-browser-candidate/revisions/v4-diagnostics/candidate.spec.ts >> C-search Query and reset
- Location: qa/ui/assets/u05-browser-candidate/revisions/v4-diagnostics/candidate.spec.ts:13:1

# Error details

```
Error: expect(locator).toHaveText(expected) failed

Locator: getByRole('listitem')
Timeout: 5000ms
- Expected  - 2
+ Received  + 1

  Array [
-   "Alpha",
-   "Beta",
+   "Gamma",
  ]

Call log:
  - Expect "toHaveText" with timeout 5000ms
  - waiting for getByRole('listitem')
    3 × locator resolved to 0 elements
    11 × locator resolved to 1 element

```

# Page snapshot

```yaml
- generic [ref=e1]:
  - heading "Names" [level=1] [ref=e2]
  - paragraph [ref=e3]: "Role: tester"
  - generic [ref=e4]:
    - generic [ref=e5]:
      - text: Query
      - textbox "Query" [ref=e6]
    - button "Search" [ref=e7]
    - button "Reset" [active] [ref=e8]
  - button "Add" [ref=e9]
  - tablist [ref=e10]:
    - tab "List" [selected] [ref=e11]
    - tab "About" [ref=e12]
  - tabpanel [ref=e13]:
    - status [ref=e14]: Ready
    - list [ref=e15]:
      - listitem [ref=e16]: Gamma
    - button "Previous" [disabled] [ref=e17]
    - text: "1"
    - button "Next" [disabled] [ref=e18]
  - button "Simulate error" [ref=e19]
```

# Test source

```ts
  1   | import {replayInputs} from "./u05-replay-inputs.ts";
  2   | // U05 source-only candidate. Expectations come from frozen u00-1 declarations.
  3   | // This file is statically checked; review and diagnostic admission are still required.
  4   | import { expect } from "playwright/test";
  5   | import { test } from "./origin.fixture.ts";
  6   | 
  7   | test.beforeEach(async ({ page }) => {
  8   | 	await page.goto("/?role=tester");
  9   | 	await expect(page.locator("#identity")).toHaveText("Role: tester");
  10  | 	await expect(page.getByRole("status")).toHaveText("Ready");
  11  | });
  12  | 
  13  | test("C-search Query and reset", async ({ page }) => {
  14  | 	await test.step("A-search-1 Query filters names", async () => {
  15  | 		await page.getByLabel("Query", { exact: true }).fill(replayInputs.gamma);
  16  | 		await page.getByRole("button", { name: "Search", exact: true }).click();
  17  | 		await expect(page.getByRole("listitem")).toHaveText([replayInputs.gamma]);
  18  | 	});
  19  | 	await test.step("A-search-2 Reset restores first page", async () => {
  20  | 		await page.getByRole("button", { name: "Reset", exact: true }).click();
  21  | 		await expect(page.getByLabel("Query", { exact: true })).toHaveValue("");
> 22  | 		await expect(page.getByRole("listitem")).toHaveText(["Alpha", "Beta"]);
      |                                            ^ Error: expect(locator).toHaveText(expected) failed
  23  | 		await expect(page.locator("#page")).toHaveText("1");
  24  | 	});
  25  | });
  26  | 
  27  | test("C-edit Cancel and persisted save", async ({ page }) => {
  28  | 	const ownedName = replayInputs.owned;
  29  | 	await test.step("A-edit-1 Dialog opens and cancels without writes", async () => {
  30  | 		await page.getByRole("button", { name: "Add", exact: true }).click();
  31  | 		await expect(page.getByRole("dialog")).toBeVisible();
  32  | 		await page.getByLabel("Name", { exact: true }).fill(ownedName);
  33  | 		await page.getByRole("button", { name: "Cancel", exact: true }).click();
  34  | 		await expect(page.getByRole("dialog")).toBeHidden();
  35  | 		// Check current in-memory results before reload can discard an incorrect write.
  36  | 		await page.getByLabel("Query", { exact: true }).fill(ownedName);
  37  | 		await page.getByRole("button", { name: "Search", exact: true }).click();
  38  | 		await expect(page.getByRole("status")).toHaveText("Empty");
  39  | 		await expect(page.getByRole("listitem")).toHaveCount(0);
  40  | 		await page.reload();
  41  | 		await page.getByLabel("Query", { exact: true }).fill(ownedName);
  42  | 		await page.getByRole("button", { name: "Search", exact: true }).click();
  43  | 		await expect(page.getByRole("status")).toHaveText("Empty");
  44  | 		await expect(page.getByRole("listitem")).toHaveCount(0);
  45  | 	});
  46  | 	await test.step("A-edit-2 Saved name survives reload once", async () => {
  47  | 		await page.getByRole("button", { name: "Add", exact: true }).click();
  48  | 		await page.getByLabel("Name", { exact: true }).fill(ownedName);
  49  | 		await page.getByRole("button", { name: "Save", exact: true }).click();
  50  | 		await page.reload();
  51  | 		await page.getByLabel("Query", { exact: true }).fill(ownedName);
  52  | 		await page.getByRole("button", { name: "Search", exact: true }).click();
  53  | 		await expect(page.getByRole("listitem")).toHaveText([ownedName]);
  54  | 	});
  55  | });
  56  | 
  57  | test("C-details Tabs and disclosure", async ({ page }) => {
  58  | 	await test.step("A-details-1 Tab selection changes panel", async () => {
  59  | 		await page.getByRole("tab", { name: "About", exact: true }).click();
  60  | 		await expect(page.getByRole("tab", { name: "About", exact: true })).toHaveAttribute("aria-selected", "true");
  61  | 		await expect(page.getByRole("tab", { name: "List", exact: true })).toHaveAttribute("aria-selected", "false");
  62  | 		await expect(page.locator("#about-panel")).toBeVisible();
  63  | 		await expect(page.locator("#list-panel")).toBeHidden();
  64  | 	});
  65  | 	await test.step("A-details-2 Disclosure changes visibility", async () => {
  66  | 		const version = page.getByText("Fixture version u00-1", { exact: true });
  67  | 		await expect(version).toBeHidden();
  68  | 		await page.getByText("Details", { exact: true }).click();
  69  | 		await expect(version).toBeVisible();
  70  | 		await page.getByText("Details", { exact: true }).click();
  71  | 		await expect(version).toBeHidden();
  72  | 	});
  73  | });
  74  | 
  75  | test("C-paging Filtered page boundaries", async ({ page }) => {
  76  | 	// Add a nonmatching row so retained query is demonstrated by the actual result set.
  77  | 	await page.getByRole("button", { name: "Add", exact: true }).click();
  78  | 	await page.getByLabel("Name", { exact: true }).fill(replayInputs.owned);
  79  | 	await page.getByRole("button", { name: "Save", exact: true }).click();
  80  | 	await page.getByLabel("Query", { exact: true }).fill(replayInputs.query);
  81  | 	await page.getByRole("button", { name: "Search", exact: true }).click();
  82  | 	await test.step("A-paging-1 Two rows on the first page", async () => {
  83  | 		await expect(page.getByRole("listitem")).toHaveText(["Alpha", "Beta"]);
  84  | 		await expect(page.getByRole("button", { name: "Previous", exact: true })).toBeDisabled();
  85  | 		await expect(page.getByRole("button", { name: "Next", exact: true })).toBeEnabled();
  86  | 	});
  87  | 	await test.step("A-paging-2 Next and previous retain query", async () => {
  88  | 		await page.getByRole("button", { name: "Next", exact: true }).click();
  89  | 		await expect(page.getByRole("listitem")).toHaveText([replayInputs.gamma]);
  90  | 		await expect(page.getByLabel("Query", { exact: true })).toHaveValue(replayInputs.query);
  91  | 		await expect(page.getByRole("button", { name: "Next", exact: true })).toBeDisabled();
  92  | 		await page.getByRole("button", { name: "Previous", exact: true }).click();
  93  | 		await expect(page.getByRole("listitem")).toHaveText(["Alpha", "Beta"]);
  94  | 		await expect(page.getByLabel("Query", { exact: true })).toHaveValue(replayInputs.query);
  95  | 		await expect(page.getByRole("button", { name: "Previous", exact: true })).toBeDisabled();
  96  | 	});
  97  | });
  98  | 
  99  | test("C-permission Separate viewer and tester contexts", async ({ page, browser }) => {
  100 | 	await test.step("A-permission-1 Viewer cannot see Add", async () => {
  101 | 		const viewer = await browser.newContext();
  102 | 		try {
  103 | 			const viewerPage = await viewer.newPage();
  104 | 			await viewerPage.goto(new URL("/?role=viewer", page.url()).href);
  105 | 			await expect(viewerPage.locator("#identity")).toHaveText("Role: viewer");
  106 | 			await expect(viewerPage.getByRole("status")).toHaveText("Ready");
  107 | 			await expect(viewerPage.getByRole("button", { name: "Add", exact: true })).toHaveCount(0);
  108 | 			await expect(viewerPage.locator("#add")).toHaveCount(1);
  109 | 			await expect(viewerPage.locator("#add")).toBeHidden();
  110 | 		} finally {
  111 | 			await viewer.close();
  112 | 		}
  113 | 	});
  114 | 	await test.step("A-permission-2 Tester can see Add", async () => {
  115 | 		await expect(page.locator("#identity")).toHaveText("Role: tester");
  116 | 		await expect(page.getByRole("button", { name: "Add", exact: true })).toBeVisible();
  117 | 		await expect(page.getByRole("button", { name: "Add", exact: true })).toBeEnabled();
  118 | 	});
  119 | });
  120 | 
  121 | test("C-states Loading empty and error", async ({ page }) => {
  122 | 	await test.step("A-states-1 Loading precedes data", async () => {
```