import json, hashlib, tarfile, io, shutil, subprocess
from pathlib import Path
repo=Path.cwd(); files={}; refs=0
sha=lambda b:hashlib.sha256(b).hexdigest()
def add(p):
 p=Path(p); assert p.is_file() and not p.is_symlink()
 name=str(p.relative_to(repo)); assert not set(name.split('/')) & {'node_modules','private-reviews','private-evidence','auth.json','models.json','agent'}
 files[name]=p.read_bytes()
def tree(p):
 for f in sorted(p.rglob('*')):
  if f.is_file():add(f)
run=repo/'tests/scratch/ui-private-evidence/1792988776986'
result=json.loads((run/'result.json').read_text());assert result['status']=='PASS' and result['leaks']==[]
assert result['managedReference']=={'prepared':2,'renewedWithoutAssetChanges':True,'changedEnvironmentBlocksBeforeRunner':True}
assert result['formal']['failedCounts']['failed']==1 and result['formal']['passedEvidenceComplete'] is False
public=run/'public'; public.mkdir(exist_ok=True)
if not (public/'qa').exists():shutil.copytree(Path(result['workspace'])/'qa',public/'qa')
def walk(v):
 global refs
 if isinstance(v,dict):
  if isinstance(v.get('path'),str) and isinstance(v.get('sha256'),str):
   p=Path(v['path']);assert not p.is_absolute() and '..' not in p.parts
   f=public/p
   if not f.exists():
    source=Path(result['workspace'])/p
    assert p==Path('requirements.md') and sha(source.read_bytes())==v['sha256'];shutil.copyfile(source,f)
   assert sha(f.read_bytes())==v['sha256'],str(f);refs+=1
  for value in v.values():walk(value)
 elif isinstance(v,list):
  for value in v:walk(value)
for f in (public/'qa').rglob('*.json'):walk(json.loads(f.read_text()))
tree(run)
base=repo/'tests/scratch/ui-optimization-u00'
for f in base.glob('u02-private-bridge-*.log'):add(f)
# Preserve safe failing receipt only, never its known-leaking public workspace.
failed=repo/'tests/scratch/ui-private-evidence/1792988087234/result.json'
assert json.loads(failed.read_text())['status']=='FAIL';add(failed)
desktop=repo/'tests/scratch/data-space-skill-desktop/1792988098121';tree(desktop)
visibility=repo/'tests/scratch/ui-workflow-visibility/1792988400700';tree(visibility)
selected=repo/'tests/scratch/ui-pms-desktop-connection/1792988526143'
add(selected/'result.json');add(selected/'plan.json')
selected_result=json.loads((selected/'result.json').read_text());assert selected_result['selectedStoreModified'] is False and selected_result['environmentsUnchanged']
source=base/'u02-private-bridge-source';source.mkdir(exist_ok=True)
upstream='/Users/liyingjun/Desktop/SW-QA/13-pi/agent-client'
(source/'native-changes.patch').write_bytes(subprocess.check_output(['git','-C',upstream,'diff','00ed830c0ff55797ffbc2e577e3252a8d551cc6b','HEAD','--','packages/ui-testing','tests/ui-testing/environment.test.mjs']))
for name in ['src/environment.ts','src/diagnostics.ts','src/private-evidence.ts','src/fixtures.ts','package.json']:
 p=Path(upstream)/'packages/ui-testing'/name
 target=source/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
shutil.copyfile(Path(upstream)/'tests/ui-testing/environment.test.mjs',source/'environment.test.mjs')
tree(source)
for name in ['plugins/data-space/private-browser-state.mjs','tests/unit/data-space-private-state.test.ts','tests/ui-private-evidence-test.mjs','tests/data-space-skill-desktop-test.mjs','tests/ui-pms-desktop-connection.mjs','tests/fixtures/data-space/ui-design-fixture.mjs','tests/scratch/ui-optimization-u00/archive-u02-private-execution.py']:add(repo/name)
ledger=repo/'tests/scratch/ui-optimization-u00/u05-authorized-review-budget.json'
prior=json.loads((repo/'docs/ui-testing-evidence/optimization-u06-pms-native-drafts.json').read_text());assert sha(ledger.read_bytes())==prior['modelReviewLedgerSha256']
package=repo/'.pi/skills/ui-testing-workflow/assets/pi-ui-testing-0.1.12.tgz'
installed=0
with tarfile.open(package) as t:
 for m in t:
  if m.isfile():assert t.extractfile(m).read()==(repo/'node_modules/pi-ui-testing'/Path(m.name).relative_to('package')).read_bytes();installed+=1
assert installed==95
archive=repo/'docs/ui-testing-evidence/optimization-u02-private-execution.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for name,b in sorted(files.items()):
  m=tarfile.TarInfo(name);m.size=len(b);m.mtime=0;t.addfile(m,io.BytesIO(b))
with tarfile.open(archive) as t:
 assert set(t.getnames())==set(files)
 for m in t:assert t.extractfile(m).read()==files[m.name]
index={'date':'2026-10-26','status':'MANAGED_PRIVATE_EXECUTION_BRIDGE_VERIFIED_FULL_U02_PENDING','plan_complete':False,'native_version':'0.1.12','data_space_version':'0.17.0','upstream_commit':subprocess.check_output(['git','-C',upstream,'rev-parse','HEAD'],text=True).strip(),'upstream_pushed':False,'model_calls':0,'modelReviewLedgerSha256':sha(ledger.read_bytes()),'fee_ledger_unchanged':True,'real_business_requests':0,'review':'Controlled engineering fixtures only; no independent model review or real PMS execution','reproduction':{'native':'6 pass / 1 new failing test before enforcement','browser':'First helper logged unused dummy private path; public scan rejected; corrected to print actual managed reference path and reran','receipt':str(failed.relative_to(repo)),'leaking_workspace_archived':False},'scenario':result,'public_refs_verified':refs,'desktop':json.loads((desktop/'result.json').read_text()),'visibility':json.loads((visibility/'result.json').read_text()),'selected_desktop':selected_result,'validation':{'native':'14 passed / 2 files','upstream_check':'passed','host_typecheck':'passed','host_vitest':'90 passed / 6 files','sdk_mcp':'19 passed','desktop':'10 data-space and 7 UI visibility checks passed','lint':'passed','protocol':'structure passed; history skipped-no-tag','size':'passed','clean':'preview only'},'package':{'path':str(package.relative_to(repo)),'sha256':sha(package.read_bytes()),'installed_equal_files':installed},'limits':['Execution only; explicit fresh parameter-to-localStorage mappings; no cookies, login, refresh or target-specific transformation','Native origin/base URL path/workspace/expiry guards; reference lasts at most five minutes, renewal keeps frozen assets unchanged','Selected desktop proves installation and recording rejection only, not a real authenticated PMS business run','Private recording MCP, PMS role/data/diagnostics and full desktop discovery-to-delivery remain pending','Controlled pass/failure outcomes retain incomplete public media evidence','U00 continuous baseline/pairs, U03/U07, M1/M2 and full plan remain pending'],'archive':{'path':str(archive.relative_to(repo)),'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'files':len(files),'roundtrip_verified':True},'files':[{'path':n,'sha256':sha(b),'bytes':len(b)} for n,b in sorted(files.items())]}
(repo/'docs/ui-testing-evidence/optimization-u02-private-execution.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'files':len(files),'refs':refs,'bytes':archive.stat().st_size,'installed':installed}))
