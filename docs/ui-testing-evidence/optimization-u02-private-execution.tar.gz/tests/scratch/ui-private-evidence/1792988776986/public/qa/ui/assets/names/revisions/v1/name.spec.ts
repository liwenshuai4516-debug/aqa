import {test,expect} from 'playwright/test';

test('C1 Name persists',async({page})=>{
 const key='qa-'+crypto.randomUUID();await page.goto('/');
 const cookie=await page.evaluate(()=>({value:JSON.parse(localStorage.getItem('private-session')).session.credentials[0].token}));
 expect(cookie).toBeTruthy();
 console.log(cookie.value,encodeURIComponent(cookie.value),Buffer.from(cookie.value).toString('base64'));
 const activePrivatePath=process.env[(test.info().project.use as any).uiEnvironment.auth.reference];console.log(activePrivatePath,encodeURI(activePrivatePath));
 await page.evaluate(value=>{const p=document.createElement('p');p.textContent=value;document.body.appendChild(p);},cookie.value);
 await page.getByRole('textbox',{name:'Name'}).fill(key);
 await page.getByRole('button',{name:'Save'}).click();await page.reload();await page.evaluate(value=>{const p=document.createElement('p');p.textContent=value;document.body.appendChild(p);},cookie.value);
 await test.step('A1 Name persists after reload',async()=>{await expect(page.getByRole('listitem')).toHaveText([key]);});
});