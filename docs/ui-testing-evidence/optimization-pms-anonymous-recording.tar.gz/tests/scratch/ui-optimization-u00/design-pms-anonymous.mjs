/** Native static candidate only; does not open a browser or invoke models. */
import assert from 'node:assert/strict';
import {mkdtemp,mkdir,writeFile,readFile,realpath,symlink,cp,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join,dirname} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {ArtifactStore,assetDigest} from 'pi-ui-testing';
const repo=process.cwd(),output=join(repo,'tests/scratch/ui-pms-anonymous-recording/1792989450785'),recorded=JSON.parse(await readFile(join(output,'result.json')));
assert.equal(recorded.status,'RECORDED_UNREVIEWED');
const root=await realpath(await mkdtemp(join(tmpdir(),'pms-anonymous-design-'))),store=new ArtifactStore(root);
let result;
try{
 for(const name of ['qa','tests','playwright.config.mjs'])await cp(join(output,name),join(root,name),{recursive:true});
 await symlink(join(repo,'node_modules'),join(root,'node_modules'),'dir');await writeFile(join(root,'package.json'),'{"type":"module"}');
 const env=(kind,id,data)=>({schema_version:'1.0',kind,id,created_at:new Date().toISOString(),data});
 const scope=await store.load(recorded.scopeRef),base='qa/ui/assets/pms-anonymous-redirect/revisions/v1';
 const rules=await store.putFile(base+'/data-rules.json',JSON.stringify({createdServerData:[],cleanup:'Close owned empty context; do not create, modify or delete server data',initial:'storageState empty; same-origin GET/HEAD only',replay:'No credentials or generated input values; baseURL from frozen config',recording_ref:recorded.recordingRef}));
 const code=`import {test,expect} from '@playwright/test';
test.use({storageState:{cookies:[],origins:[]},serviceWorkers:'block',acceptDownloads:false});
test('anonymous OperationContract redirect baseline',async({page,context,baseURL})=>{
 if(!baseURL)throw new Error('Missing scoped baseURL');
 const origin=new URL(baseURL).origin;
 await context.route('**/*',route=>new URL(route.request().url()).origin===origin&&['GET','HEAD'].includes(route.request().method())?route.continue():route.abort('blockedbyclient'));
 await page.goto('/pms/OperationContract');
 await test.step('A-anonymous-redirect protected route resolves to scoped login baseline',async()=>{
  await expect(page).toHaveURL(url=>url.origin===origin&&url.pathname==='/login');
 });
});\n`;
 const script=await store.putFile(base+'/candidate.spec.ts',code);
 const config=await store.putFile(base+'/playwright.config.mjs',await readFile(join(root,'playwright.config.mjs')));
 const lineage=await store.putFile(base+'/lineage.json',JSON.stringify({recording_ref:recorded.recordingRef,oracle:'historical anonymous baseline corroborated by current MCP snapshot; not a confirmed product requirement',synthesis:'Candidate adds one sourced test.step assertion and explicit empty storageState/same-origin network guard; not byte-for-byte MCP export',notExecuted:['independent design review','positive/negative diagnostic','formal regression','Electron Agent discovery chain']}));
 const cases=await store.put(env('cases','pms-anonymous-redirect-v1',{scope_ref:recorded.scopeRef,sources:scope.data.sources,data_rules_ref:rules,gaps:['Unreviewed baseline candidate; diagnostics and formal run not performed'],cases:[{case_id:'PMS-anonymous-redirect',module_id:'pms-access',feature_id:'anonymous-redirect',scenario_id:'anonymous-redirect-baseline',title:'未登录经营合同入口跳转至登录页（行为基线）',priority:'P0',preconditions:['Frozen selected PMS baseURL; no private storageState, cookies or credentials','Anonymous behavior baseline only; not approved for formal execution'],steps:[{step_id:'S-anonymous-navigate',action:'Use fresh empty context to navigate to /pms/OperationContract, permitting same-origin GET/HEAD only',assertion_ids:['A-anonymous-redirect']}],assertions:[{assertion_id:'A-anonymous-redirect',step_id:'S-anonymous-navigate',source_id:'anonymous-baseline',oracle_type:'baseline',target:'Page URL after anonymous protected-route navigation',comparison:'toHaveURL: scoped origin and /login pathname',expected:{origin:scope.data.base_url,pathname:'/login'},observation:'Historical anonymous browser receipt and current native navigation/snapshot show /login; candidate replay itself has not run',evidence_required:true}],cleanup:'Close owned empty browser context; no business data created',data_row_id:'anonymous-no-business-data',browser_project:'chromium'}]}));
 const version=JSON.parse(await readFile(join(repo,'node_modules/@playwright/test/package.json'))).version;
 const asset=env('asset','pms-anonymous-redirect',{revision:'v1',module_ids:['pms-access'],scope_ref:recorded.scopeRef,inventory_ref:recorded.inventoryRef,cases_ref:cases,recording_refs:[recorded.recordingRef],files:[script,config,rules,lineage],bindings:[{case_id:'PMS-anonymous-redirect',script_ref:script,test_title:'anonymous OperationContract redirect baseline',assertion_ids:['A-anonymous-redirect']}],dependencies:[{name:'@playwright/test',version}],readiness:'design-only',gaps:['Independent design review and controlled diagnostics pending'],content_sha256:'0'.repeat(64)});asset.data.content_sha256=assetDigest(asset);
 const tools=new Map(),installed=dirname(fileURLToPath(import.meta.resolve('pi-ui-testing')));
 const {registerDesignTools}=await import(pathToFileURL(join(installed,'design-extension.js')));registerDesignTools({registerTool:tool=>tools.set(tool.name,tool)});
 const response=await tools.get('ui_case_design').execute('pms-anonymous-candidate',{request:{operation:'candidate',asset}},new AbortController().signal,undefined,{cwd:root});
 result=JSON.parse(response.content.filter(c=>c.type==='text').map(c=>c.text).join('\n'));assert.equal(result.status,'completed',JSON.stringify(result));assert.deepEqual(result.output.issues,[],JSON.stringify(result));
 for(const name of ['qa'])await cp(join(root,name),join(output,name),{recursive:true});
 await writeFile(join(output,'candidate-result.json'),JSON.stringify({status:'STATIC_CHECK_PASSED_UNREVIEWED',modelCalls:0,browserLaunches:0,formalRuns:0,response:result},null,2)+'\n');
 await cp(new URL(import.meta.url),join(output,'design-harness.mjs'));console.log(JSON.stringify(result,null,2));
}finally{await rm(root,{recursive:true,force:true});}
