from pathlib import Path
import json,hashlib,tarfile,io,os,shutil
repo=Path.cwd();out=repo/'tests/scratch/ui-pms-anonymous-recording/1792989450785';files={};refs=0
sha=lambda b:hashlib.sha256(b).hexdigest()
recorded=json.loads((out/'result.json').read_text());candidate=json.loads((out/'candidate-result.json').read_text());asset=candidate['response']['output']['asset_ref']
assert recorded['status']=='RECORDED_UNREVIEWED' and recorded['storeUnchanged']
assert candidate['response']['output']['issues']==[] and candidate['response']['output']['design_approved'] is False
requests=json.loads((out/'qa/ui/recordings/pms-anonymous/requests.json').read_text());assert requests=={'allowedRead':79,'blockedWrite':0,'blockedForeign':0,'context':'fresh-anonymous','noAuthState':True}
def walk(v):
 global refs
 if isinstance(v,dict):
  if isinstance(v.get('path'),str) and isinstance(v.get('sha256'),str):
   p=Path(v['path']);assert not p.is_absolute() and '..' not in p.parts
   f=out/p;assert sha(f.read_bytes())==v['sha256'],str(f);refs+=1
  for value in v.values():walk(value)
 elif isinstance(v,list):
  for value in v:walk(value)
for f in (out/'qa').rglob('*.json'):walk(json.loads(f.read_text()))
for f in (out/'qa').rglob('*.json'):
 d=json.loads(f.read_text())
 if f.name=='response.json':
  for c in d.get('content',[]):
   if c.get('type')=='text':
    import re
    for rel in re.findall(r'\((\.playwright-mcp/[^)#]+)',c['text']):assert (out/rel).is_file(),rel
system='e2f5d42d-2781-4e68-a452-4c87c7d1d346'
docdir=Path.home()/'Library/Application Support/Pi Agent Desktop/data/data-space/project-documents'/system
docdir.mkdir(parents=True,exist_ok=True)
snapshot=docdir/('anonymous-redirect-'+asset['sha256'][:12]);snapshot.mkdir(mode=0o700)
for name in ['qa','tests','playwright.config.mjs','.playwright-mcp','result.json','candidate-result.json']:
 src=out/name;dst=snapshot/name
 if src.is_dir():shutil.copytree(src,dst)
 else:shutil.copyfile(src,dst)
for f in snapshot.rglob('*'):
 if f.is_file():os.chmod(f,0o600)
 elif f.is_dir():os.chmod(f,0o700)
text=f'''# 经营合同：未登录入口跳转预期（行为基线，未评审）

- 项目：项目管理系统；项目 ID：{system}
- 环境 ID：{recorded['envId']}；目标：{recorded['target']}
- 范围：全新匿名浏览器上下文，仅同源 GET/HEAD；不输入账号密码、不登录、不操作业务数据。
- 预期依据：历史匿名浏览器观察及本轮原生 MCP 录制；分类为 baseline，不是已确认产品需求。
- 初态：无 Cookie、无 localStorage token、无私密认证配置；seed 已检查。
- 步骤：访问 /pms/OperationContract。
- 断言 A-anonymous-redirect：跳转后的 URL 保持所选环境 origin，pathname 为 /login。
- 本轮观察：原生浏览器导航及快照显示 /login，登录表单可见；登录表单内容未纳入候选断言。
- 数据与清理：未创建服务端业务数据；只关闭自有浏览器上下文。79 次同源只读请求，写请求与外域请求均为 0。
- 状态：录制完成；候选原生静态检查无阻断；设计未批准、未诊断、未正式执行。录制成功不等于正式测试通过。
- 原有三条源码草稿及台账均未改动；本候选保存为项目文档快照，未入用例列表、未绑定、未执行。
- 资产：{asset['path']}；SHA-256：{asset['sha256']}
- 原生相对路径均在同目录 {snapshot.name}/ 内保留；真实登录后的身份结构、角色、数据、经营合同业务及 Electron Agent 全链仍待验收。
'''
doc=docdir/'OperationContract-anonymous-redirect-baseline-2026-10-26.md'
with doc.open('x') as f:f.write(text)
os.chmod(doc,0o600);assert doc.read_text()==text
persisted=[]
for f in sorted(snapshot.rglob('*')):
 if f.is_file():
  rel=f.relative_to(snapshot);assert f.read_bytes()==(out/rel).read_bytes();persisted.append({'path':str(rel),'sha256':sha(f.read_bytes()),'bytes':f.stat().st_size})
receipt={'document':{'path':str(doc),'sha256':sha(doc.read_bytes()),'bytes':doc.stat().st_size,'mode':oct(doc.stat().st_mode&0o777)},'snapshot':{'path':str(snapshot),'files':persisted},'application_document_index':'unsupported','case_store_modified':False,'new_case_imports':0}
(out/'data-space-documents.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
def add(f):
 assert not f.is_symlink();name=str(f.relative_to(repo));assert not set(name.split('/'))&{'node_modules','agent','auth.json','models.json','private-reviews','private-evidence'};files[name]=f.read_bytes()
for f in sorted(out.rglob('*')):
 if f.is_file():add(f)
failures=[]
for run in ['1792989256617','1792989301610','1792989342123','1792989399713']:
 p=repo/'tests/scratch/ui-pms-anonymous-recording'/run;d=json.loads((p/'result.json').read_text());assert d['status']=='FAIL' and d['storeUnchanged'];failures.append({'path':str(p.relative_to(repo)),'status':'FAIL','formalRuns':0})
 for f in sorted(p.rglob('*')):
  if f.is_file():add(f)
for f in (repo/'tests/scratch/ui-optimization-u00').glob('pms-anonymous-*.log'):add(f)
for name in ['record-pms-anonymous.mjs','design-pms-anonymous.mjs','archive-pms-anonymous.py']:add(repo/'tests/scratch/ui-optimization-u00'/name)
ledger=repo/'tests/scratch/ui-optimization-u00/u05-authorized-review-budget.json';prior=json.loads((repo/'docs/ui-testing-evidence/optimization-u06-pms-native-drafts.json').read_text());assert sha(ledger.read_bytes())==prior['modelReviewLedgerSha256']
archive=repo/'docs/ui-testing-evidence/optimization-pms-anonymous-recording.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for n,b in sorted(files.items()):m=tarfile.TarInfo(n);m.size=len(b);m.mtime=0;t.addfile(m,io.BytesIO(b))
with tarfile.open(archive) as t:
 assert set(t.getnames())==set(files)
 for m in t:assert t.extractfile(m).read()==files[m.name]
index={'date':'2026-10-26','status':'REAL_PMS_ANONYMOUS_RECORDED_STATIC_CANDIDATE_UNREVIEWED','plan_complete':False,'modelCalls':0,'formalRuns':0,'modelReviewLedgerSha256':sha(ledger.read_bytes()),'ledger_unchanged':True,'recording':recorded,'candidate':candidate,'requests':requests,'public_refs_verified':refs,'durable_project_documents':receipt,'failed_attempts':failures,'failure_causes':['Seed helper registered afterAll inside test body','MCP browser_navigate/close require nested intent','MCP browser_snapshot rejects additional intent','Helper regex applied to entire snapshot instead of extracting URL line'],'limitations':['Baseline oracle only; independent design review and diagnostic pending','Not an Electron Agent discovery-to-delivery chain','Existing 3 source-only cases unchanged; new candidate not imported or bound','No authenticated role, business data or contract operations tested'],'archive':{'path':str(archive.relative_to(repo)),'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'files':len(files),'roundtrip_verified':True},'files':[{'path':n,'sha256':sha(b),'bytes':len(b)}for n,b in sorted(files.items())]}
(repo/'docs/ui-testing-evidence/optimization-pms-anonymous-recording.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'files':len(files),'refs':refs,'bytes':archive.stat().st_size,'persistent_files':len(persisted)},ensure_ascii=False))
