/** Real anonymous navigation recording; no login, private state, model or formal runner. */
import assert from 'node:assert/strict';
import {mkdtemp,mkdir,writeFile,readFile,realpath,symlink,cp,rm} from 'node:fs/promises';
import {tmpdir,homedir} from 'node:os';
import {join,resolve} from 'node:path';
import {ArtifactStore,sha256} from 'pi-ui-testing';
import {createAgentSessionFromServices,createAgentSessionServices,ModelRuntime,SessionManager,SettingsManager} from '@earendil-works/pi-coding-agent';
import {enableUiTesting} from '../../../scripts/enable-ui-testing.mjs';
import {CHROME_PATH} from '../../lib/chrome.mjs';
const repo=process.cwd(), output=resolve('tests/scratch/ui-pms-anonymous-recording',String(Date.now()));
await mkdir(output,{recursive:true});
const root=await realpath(await mkdtemp(join(tmpdir(),'pms-anonymous-recording-'))),project=join(root,'project'),agentDir=join(root,'agent');
await mkdir(project);await mkdir(agentDir);await mkdir(join(project,'tests'));
await symlink(join(repo,'node_modules'),join(project,'node_modules'),'dir');
await writeFile(join(project,'package.json'),'{"type":"module"}');
const storeFile=join(homedir(),'Library/Application Support/Pi Agent Desktop/data/data-space/store.json');
const original=await readFile(storeFile),data=JSON.parse(original),systemId='e2f5d42d-2781-4e68-a452-4c87c7d1d346',envId='f46a32da-2eac-43ca-86b8-2fa5eca5385c';
const env=data.envs.find(e=>e.id===envId&&e.systemId===systemId);assert.ok(env);
const target=new URL('/pms/OperationContract',env.baseUrl),base=target.origin;
await writeFile(join(project,'playwright.config.mjs'),`export default {testDir:'./tests',timeout:30000,workers:1,use:{headless:true,baseURL:${JSON.stringify(base)},serviceWorkers:'block',acceptDownloads:false,launchOptions:${JSON.stringify(CHROME_PATH?{executablePath:CHROME_PATH}:{})}},projects:[{name:'chromium',use:{browserName:'chromium'}}]};`);
const seedCode=`import {test,expect} from '@playwright/test';
import {writeFile} from 'node:fs/promises';
const counts={allowedRead:0,blockedWrite:0,blockedForeign:0};
test.afterAll(async()=>{await writeFile('qa/ui/recordings/pms-anonymous/requests.json',JSON.stringify({...counts,context:'fresh-anonymous',noAuthState:true}));});
test('anonymous navigation seed',async({page,context})=>{
 expect(await context.cookies()).toEqual([]);
 await context.route('**/*',async route=>{const r=route.request();if(new URL(r.url()).origin!==${JSON.stringify(base)}){counts.blockedForeign++;return route.abort('blockedbyclient');}if(!['GET','HEAD'].includes(r.method())){counts.blockedWrite++;return route.abort('blockedbyclient');}counts.allowedRead++;return route.continue();});
 await page.goto('/pms/OperationContract');
 await expect(page).toHaveURL(/\\/login(?:[/?#]|$)/);
 expect(await page.evaluate(()=>localStorage.getItem('token'))).toBeNull();
});`;
await writeFile(join(project,'tests/anonymous.seed.spec.ts'),seedCode);
const store=new ArtifactStore(project),envelope=(kind,id,data)=>({schema_version:'1.0',kind,id,created_at:new Date().toISOString(),data});
const text=r=>r.content.filter(c=>c.type==='text').map(c=>c.text).join('\n');
const result={status:'FAIL',systemId,envId,target:target.href,modelCalls:0,formalRuns:0,storeWrites:0,privateAuthentication:false,limitations:['Native SDK/MCP anonymous recording, not an Electron Agent end-to-end test','Baseline oracle only; no requirement or independent design approval','No authenticated business role, data or contract operation tested']};
let session,recording,inventoryRef,finished=false,sequence=0;
let invoke,call;
try{
 await writeFile(join(agentDir,'auth.json'),'{}');await enableUiTesting(repo,agentDir);
 const runtime=await ModelRuntime.create({authPath:join(agentDir,'auth.json'),modelsPath:null,modelsStorePath:join(agentDir,'models-cache.json'),refreshOnCreate:false});
 for(const method of ['stream','streamSimple','complete','completeSimple'])runtime[method]=()=>{result.modelCalls++;throw Error('No model authorization for this recording');};
 const services=await createAgentSessionServices({cwd:project,agentDir,modelRuntime:runtime,settingsManager:SettingsManager.create(project,agentDir,{projectTrusted:true})});
 assert.deepEqual(services.resourceLoader.getExtensions().errors,[]);
 ({session}=await createAgentSessionFromServices({services,sessionManager:SessionManager.create(project,join(agentDir,'sessions'))}));await session.bindExtensions({});
 let backend;const deadline=Date.now()+30000;
 while(Date.now()<deadline){backend=session.getAllTools().find(t=>t.name.startsWith('mcp__')&&t.name.endsWith('generator_setup_page'))?.name.slice(0,-'generator_setup_page'.length);if(backend)break;await new Promise(r=>setTimeout(r,50));}assert.ok(backend);
 invoke=async request=>{const tool=session.agent.state.tools.find(t=>t.name==='ui_discover_record');const id='anonymous-'+sequence++;const args={request};session.agent.state.messages=[{role:'assistant',content:[{type:'toolCall',id,name:tool.name,arguments:args}]}];return JSON.parse(text(await tool.execute(id,args,new AbortController().signal)));};
 const previousPath=join(repo,'tests/scratch/ui-pms-browser-preparation/1792981439071/result.json'),previous=JSON.parse(await readFile(previousPath));
 const anonymous=previous.contexts.find(c=>c.authenticatedReference===false);assert.equal(anonymous.atLoginRoute,true);
 const baseline=await store.putFile('qa/ui/scopes/pms-anonymous/baseline.json',JSON.stringify({oracle_type:'baseline',priorReceipt:{path:previousPath,sha256:sha256(await readFile(previousPath))},observation:anonymous,limit:'Historical observation of same selected deployment; not a requirement'}));
 const scopeRef=await store.put(envelope('scope','pms-anonymous',{project_id:systemId,environment_id:envId,role:'anonymous',goal:'Record anonymous navigation from OperationContract to login route, without credentials or form submission',base_url:base,allowed_actions:['GET/HEAD same-origin navigation and snapshots only; no form input, login or business writes'],sources:[{source_id:'anonymous-baseline',oracle_type:'baseline',ref:baseline,statement:'Previous fresh anonymous context redirected to login; no protected business role established'}],budget:{max_review_rounds:3,max_tool_calls:10}}));
 const inventory=envelope('inventory','pms-anonymous-initial',{scope_ref:scopeRef,features:[{module_id:'pms-access',feature_id:'anonymous-redirect',name:'未登录经营合同入口跳转',entry:target.pathname,role:'anonymous',actions:['Navigate to protected route and observe login URL'],scenarios:[{scenario_id:'anonymous-redirect-baseline',title:'Anonymous navigation follows previously observed login redirect'}],coverage:'discovered',discovery:'source',source_refs:[baseline],source_locations:[{ref:baseline,symbol:'observation.atLoginRoute',line:1}],priority:'P0',states:[],gaps:['Current native recording not yet observed']}],unexplored:['Authenticated contract features, login submission, permissions and test data']});
 let response=await invoke({operation:'inventory',inventory});assert.equal(response.status,'completed',JSON.stringify(response));inventoryRef=response.artifact_refs[0];
 const initial=await store.putFile('qa/ui/recordings/pms-anonymous/initial.json',JSON.stringify({context:'new empty browser context',auth:'none',cookies:'empty checked by seed',token:'absent checked by seed',navigation:target.href}));
 const rules=await store.putFile('qa/ui/recordings/pms-anonymous/data.json',JSON.stringify({createdBusinessData:[],cleanup:'close owned context; no server data created',forbidden:['login','input','non-GET/HEAD requests','foreign origins']}));
 response=await invoke({operation:'start',configuration:{id:'pms-anonymous',scope_ref:scopeRef,inventory_ref:inventoryRef,initial_state_ref:initial,data_rules_ref:rules,seed_ref:{path:'tests/anonymous.seed.spec.ts',sha256:sha256(seedCode)},backend,project:'chromium',output_file:'tests/anonymous.recorded.spec.ts',max_steps:10,max_duration_ms:120000,max_no_progress:3,test_data:[]}});assert.equal(response.status,'completed',JSON.stringify(response));recording=response.artifact_refs[0];
 call=async(tool,input={})=>{if(tool.startsWith('browser_'))input={...input,intent:'Observe or close owned anonymous context only'};const r=await invoke({operation:'action',session_ref:recording,operation_id:'anonymous-action-'+sequence++,tool,input,intent:'Observe anonymous same-origin navigation without input or authentication'});assert.equal(r.status,'completed',JSON.stringify(r));return r;};
 await call('generator_setup_page',{seedFile:'tests/anonymous.seed.spec.ts',project:'chromium',plan:'Observe anonymous redirect only; no input, login or mutation'});
 const navigation=await call('browser_navigate',{url:target.href});
 const snapshot=await call('browser_snapshot');
 // URL expectation is the documented baseline oracle; no guessed element locator is introduced.
 assert.match(text(snapshot.output),/\/login(?:[/?#]|$)/);
 inventory.id='pms-anonymous-observed';Object.assign(inventory.data.features[0],{coverage:'explored',discovery:'browser',source_refs:[baseline,...navigation.artifact_refs,...snapshot.artifact_refs],states:['fresh anonymous context','login URL observed after protected navigation'],gaps:[]});
 response=await invoke({operation:'inventory',inventory,drafts:[{name:'anonymous-redirect.md',content:'Current native navigation/snapshot follows the historical anonymous login URL baseline. Navigation-only; no form interactions or element locator assertions. Login page content remains outside this candidate.'}]});assert.equal(response.status,'completed',JSON.stringify(response));inventoryRef=response.artifact_refs[0];
 await call('generator_read_log');
 const code=`import {test,expect} from '@playwright/test';\ntest('anonymous OperationContract redirect baseline',async({page,context})=>{\n expect(await context.cookies()).toEqual([]);\n await context.route('**/*',r=>new URL(r.request().url()).origin===new URL(test.info().project.use.baseURL).origin&&['GET','HEAD'].includes(r.request().method())?r.continue():r.abort('blockedbyclient'));\n await page.goto('/pms/OperationContract');\n await expect(page).toHaveURL(/\\/login(?:[/?#]|$)/);\n expect(await page.evaluate(()=>localStorage.getItem('token'))).toBeNull();\n});\n`;
 await call('generator_write_test',{fileName:'tests/anonymous.recorded.spec.ts',code});await call('browser_close');
 response=await invoke({operation:'finish',session_ref:recording,inventory_ref:inventoryRef,initial_state:'Fresh empty context; anonymous seed checks no cookies/token; GET/HEAD same-origin only',completion:{initial_state_rebuildable:true,replaceable_data:true,stable_locators:true,assertion_sources:true,cleanup_owned:true},goal_reached:true,gaps:[]});assert.equal(response.status,'completed',JSON.stringify(response));finished=true;
 const final=await store.load(response.artifact_refs[0]);assert.equal(final.data.status,'complete',JSON.stringify(final.data.gaps));
 result.recordingRef=response.artifact_refs[0];result.recordingStatus=final.data.status;result.inventoryRef=inventoryRef;result.scopeRef=scopeRef;result.status='RECORDED_UNREVIEWED';
}catch(error){result.error=error.stack;process.exitCode=1;
 if(recording&&!finished&&call){try{await call('browser_close').catch(e=>{result.closeError=e.message});result.partial=await invoke({operation:'finish',session_ref:recording,inventory_ref:inventoryRef,initial_state:'Inspect seed and retained actions',completion:{initial_state_rebuildable:true,replaceable_data:true,stable_locators:false,assertion_sources:true,cleanup_owned:true},goal_reached:false,gaps:['Anonymous recording failed; no authenticated operations attempted']});}catch(cleanup){result.cleanupError=cleanup.message;}}
}finally{
 if(session){await session.extensionRunner?.emit({type:'session_shutdown',reason:'shutdown'}).catch(()=>{});session.dispose();}
 for(const name of ['qa','tests','playwright.config.mjs']){try{await cp(join(project,name),join(output,name),{recursive:true});}catch(e){result.copyError=e.message;process.exitCode=1;}}
 result.storeUnchanged=(await readFile(storeFile)).equals(original);assert.ok(result.storeUnchanged);
 result.workspace=project;result.evidence=output;await writeFile(join(output,'result.json'),JSON.stringify(result,null,2)+'\n');
 await cp(new URL(import.meta.url),join(output,'harness.mjs'));await rm(root,{recursive:true,force:true});console.log(JSON.stringify(result,null,2));
}
