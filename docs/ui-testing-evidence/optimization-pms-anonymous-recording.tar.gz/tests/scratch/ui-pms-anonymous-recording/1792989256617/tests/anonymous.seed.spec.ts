import {test,expect} from '@playwright/test';
import {writeFile} from 'node:fs/promises';
test('anonymous navigation seed',async({page,context})=>{
 const counts={allowedRead:0,blockedWrite:0,blockedForeign:0};
 expect(await context.cookies()).toEqual([]);
 await context.route('**/*',async route=>{const r=route.request();if(new URL(r.url()).origin!=="http://192.168.90.224:8238"){counts.blockedForeign++;return route.abort('blockedbyclient');}if(!['GET','HEAD'].includes(r.method())){counts.blockedWrite++;return route.abort('blockedbyclient');}counts.allowedRead++;return route.continue();});
 await page.goto('/pms/OperationContract');
 await expect(page).toHaveURL(/\/login(?:[/?#]|$)/);
 expect(await page.evaluate(()=>localStorage.getItem('token'))).toBeNull();
 test.afterAll(async()=>{await writeFile('qa/ui/recordings/pms-anonymous/requests.json',JSON.stringify({...counts,context:'fresh-anonymous',noAuthState:true}));});
});