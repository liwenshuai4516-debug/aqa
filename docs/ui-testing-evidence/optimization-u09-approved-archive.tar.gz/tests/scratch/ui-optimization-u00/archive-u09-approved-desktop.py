import json,hashlib,tarfile,io
from pathlib import Path
repo=Path.cwd();source=repo/'tests/scratch/ui-browser-candidate/1792809587795';files={};sha=lambda b:hashlib.sha256(b).hexdigest()
def add(p):
 p=Path(p);assert not p.is_symlink();n=str(p.relative_to(repo));assert not any(v in n.split('/') for v in ['ui-review-authority','private-authority','auth.json','models.json','model-cache.json','node_modules']);files[n]=p.read_bytes()
def tree(p):
 for f in p.rglob('*'):
  if f.is_file():add(f)
priorpath=repo/'docs/ui-testing-evidence/optimization-u05-approved-run.json';prior=json.loads(priorpath.read_text());assert sha((repo/prior['archive']['path']).read_bytes())==prior['archive']['sha256'];add(priorpath)
ledger='tests/scratch/ui-optimization-u00/u05-authorized-review-budget.json';assert sha((repo/ledger).read_bytes())==next(f['sha256'] for f in prior['files'] if f['path']==ledger)
samples=[]
for folder in ['1792924067382','1792924122498']:
 output=repo/f'tests/scratch/ui-approved-archive-desktop/{folder}';r=json.loads((output/'result.json').read_text());store=json.loads((output/'store.json').read_text());runs=json.loads((output/'runs.json').read_text())['runs']
 assert len(store['cases'])==6 and len(runs)==6;assert len({v['automation']['key'] for v in runs})==6;assert all(v['verdict']=='通过' for v in runs);assert {v['featureId'] for v in store['cases']}=={'desktop-'+v for v in ['search','edit','details','paging','permission','states']}
 for ref in r['source_refs']:
  assert sha((source/ref['path']).read_bytes())==ref['sha256'];assert sha((Path(r['workspace'])/ref['path']).read_bytes())==ref['sha256']
 tree(output)
 samples.append({'status':r['status'],'checks':r['checks'],'error':r.get('error'),'case_count':6,'passed_result_count':6,'distinct_result_keys':6,'source_refs':r['source_refs'],'projection':'Public qa only, no original tasks/catalog, only selected formal run, no private approval authority; empty-authority gate rejected','workspace':r['workspace']})
assert samples[0]['status']=='FAIL' and 'workspace' in samples[0]['error'];assert samples[1]['status']=='PASS';assert len(samples[1]['checks'])==5
final=repo/'tests/scratch/ui-approved-archive-desktop/1792924122498';assert sha((final/'harness.mjs').read_bytes())==sha((repo/'tests/ui-approved-archive-desktop-test.mjs').read_bytes());delivery=json.loads((final/'delivery.json').read_text());assert json.loads((final/'delivery-validation.json').read_text())['ok'];assert len(delivery['results'])==6
for p in (repo/'tests/scratch/ui-optimization-u00').glob('u09-approved-archive-*.log'):add(p)
for name in ['tests/ui-approved-archive-desktop-test.mjs','tests/scratch/ui-optimization-u00/archive-u09-approved-desktop.py']:add(repo/name)
archive=repo/'docs/ui-testing-evidence/optimization-u09-approved-archive.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for n,b in sorted(files.items()):
  m=tarfile.TarInfo(n);m.size=len(b);m.mtime=0;t.addfile(m,io.BytesIO(b))
with tarfile.open(archive) as t:
 assert set(t.getnames())==set(files)
 for m in t:assert t.extractfile(m).read()==files[m.name]
index={'date':'2026-10-25','status':'ELECTRON_APPROVED_SIX_FEATURE_ARCHIVE_AND_RESTART_PASSED_FULL_WORKFLOW_PENDING','plan_complete':False,'versions':{'native':'0.1.7','data_space':'0.16.0','desktop':'macOS arm64 unpackaged Electron; reused verified build, not rebuilt by smoke'},'model_calls':0,'new_target_executions':0,'fee_ledger_unchanged':True,'samples':samples,'source_independent_approval':'Original DesignReviewService/ResultReviewService gates passed before public projection; never cloned authority','original_approved_archive_verified':prior['archive'],'delivery':{'cases':6,'complete_evidence':True,'report_review':delivery['reportReview'],'format_validation':'passed; consistency check only, independent approval and byte integrity checked separately','cross_project_contradiction':'rejected'},'validation':{'typecheck':'passed','vitest':'72 passed in 5 files; first unmatched shell glob did not run tests, log retained','lint':'passed','protocol':'structure passed; no-tag history skip','desktop':'5 checks passed after realpath correction; first failure retained','size':'passed','clean':'preview only; no deletion'},'limits':['Only archival/mapping/binding/sync/query/restart stages executed in Electron','Discovery/design/independent review/original formal target run came from earlier native entries, not a new desktop full chain','Public projection has no execution approval authority; archival does not grant execute permission','Initial path-normalization failure source was not frozen separately; actual logs, persisted data and images retained','Original U00/U02 gates, real OperationContract conditions, U03/U07 and M1/M2 remain incomplete'],'archive':{'path':str(archive.relative_to(repo)),'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'files':len(files),'roundtrip_verified':True},'files':[{'path':n,'sha256':sha(b),'bytes':len(b)} for n,b in sorted(files.items())]}
(repo/'docs/ui-testing-evidence/optimization-u09-approved-archive.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'files':len(files),'bytes':archive.stat().st_size,'cases':6,'checks':5}))
