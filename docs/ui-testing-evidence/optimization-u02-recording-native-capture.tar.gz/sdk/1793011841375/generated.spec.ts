import {test,expect} from '@playwright/test';test('fixture heading',async({page})=>{await page.goto('/');await expect(page.getByRole('heading',{name:'Privacy fixture'})).toBeVisible();});
