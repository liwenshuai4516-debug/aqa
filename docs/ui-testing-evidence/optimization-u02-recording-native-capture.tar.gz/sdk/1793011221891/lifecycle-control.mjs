export const controls = { snapshot: null, beforePublication: null, connection: {} };
