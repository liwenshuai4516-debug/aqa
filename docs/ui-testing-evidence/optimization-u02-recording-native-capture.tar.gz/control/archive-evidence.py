from pathlib import Path
import base64,hashlib,json,tarfile,shutil,subprocess
from datetime import datetime,timezone
repo=Path.cwd()
stage=repo/'tests/scratch/ui-optimization-u00/recording-native-capture'
target=stage/'archive-final'
target.mkdir()
hashof=lambda b:hashlib.sha256(b).hexdigest()
members=[]
def copy(src,rel):
 src=Path(src)
 if src.is_symlink() or not src.is_file(): raise RuntimeError(str(src))
 dst=target/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
 b=dst.read_bytes();members.append({'path':str(rel),'sha256':hashof(b),'bytes':len(b)})
for p in sorted(stage.glob('*.log')):copy(p,Path('logs')/p.name)
for p in sorted(stage.glob('*.txt')):copy(p,Path('logs')/p.name)
for name in ['export-manifest.json','export-final-manifest.json','capture-ancestor-before.ts','capture-ancestor-control.test.mjs']:
 copy(stage/name,Path('control')/name)
copy(stage/'export-diagnostic/bundle-manifest.json','control/export-diagnostic-manifest.json')
copy(stage/'export/assets/pi-ui-testing-0.1.16.tgz','control/pi-ui-testing-0.1.16.tgz')
copy(stage/'export-diagnostic/assets/pi-ui-testing-0.1.17.tgz','control/pi-ui-testing-0.1.17-diagnostic.tgz')
copy(stage/'archive-evidence.py','control/archive-evidence.py')
native=Path('/Users/liyingjun/Desktop/SW-QA/13-pi/agent-client')
for name in ['packages/ui-testing/src/recording-capture.ts','packages/ui-testing/src/recording-fixtures.ts','packages/ui-testing/src/private-recording-storage-events.ts','packages/ui-testing/src/index.ts','packages/ui-testing/src/fixtures.ts','packages/ui-testing/src/environment.ts','packages/ui-testing/package.json','packages/ui-testing/README.md','tests/ui-testing/recording-capture.test.mjs','tests/ui-testing/recording-private-binding.test.mjs','tests/ui-testing/private-evidence.test.mjs']:
 copy(native/name,Path('native')/name)
hostFiles=['docs/ui-testing-optimization-plan.md','docs/ui-testing-optimization-execution.md','.pi/skills/ui-testing-workflow/SKILL.md','.pi/skills/ui-testing-workflow/assets/private-recording-storage-events.mjs','.pi/skills/ui-testing-workflow/assets/private-recording-connection.mjs','.pi/skills/ui-testing-workflow/assets/private-recording-transport.mjs','.pi/skills/ui-testing-workflow/assets/private-recording-session.mjs','.pi/skills/ui-testing-workflow/assets/private-recording-workspace.mjs','tests/unit/ui-private-recording-storage-events.test.ts','tools/e2e/package.json','tools/e2e/package-lock.json']
for name in hostFiles:copy(repo/name,Path('host')/name)
runs=[]
for r in sorted((repo/'tests/scratch/ui-recording-native-capture').iterdir()):
 if not (r/'result.json').is_file():continue
 d=json.loads((r/'result.json').read_text())
 for f in sorted(r.rglob('*')):
  if f.is_file(): copy(f,Path('sdk')/r.name/f.relative_to(r))
 runs.append({'id':r.name,'status':d['status'],'recordingStatus':d.get('recordingStatus'),'steps':d.get('nativeRecordingSteps'),'helpers':len(d.get('sdkCaptureReceipts',[])),'raw':d})
selected={}
for r in runs:
 d=r['raw']
 key='corrupt' if d.get('corruptStorageEventsRejected') else 'cancel' if d.get('cancelledAtPrivateCapture') else 'page' if d.get('extraPageRejected') else 'cookie' if d.get('ephemeralCookieClearedInSeed') else 'storage' if d.get('recordingStatus')=='complete' else None
 if key and d.get('recordingStatus'):selected[key]=r
assert set(selected)=={'storage','cookie','corrupt','cancel','page'},selected
selectedSummary={}
for key,r in selected.items():
 d=r['raw'];assert d['modelCalls']==d['formalRuns']==d['businessWrites']==0
 assert d['nativeRecordingSteps']==5 and len(d['sdkCaptureReceipts'])==4
 events=d['sdkEvents']; calls=[x for x in events if x['kind']=='tool_call']
 assert len(calls)==9
 helpers=[x for x in calls if x['toolName'].endswith('__browser_run_code_unsafe')]
 assert len(helpers)==4
 for h in helpers:
  assert any(x['toolCallId']==h['parentToolCallId'] for x in calls)
 assert all(not x['containsSyntheticSecret'] and x['mediaBlocks']==0 for x in d['tools'])
 assert not any(f.get('containsSyntheticSecret') or f['surface']=='workspace-media' for f in d['findings'])
 assert d['ownedRawOutputsRemoved']
 if key in ['storage','cookie']:
  assert d['recordingStatus']=='complete' and d['finishGaps']==[] and d['publicScriptEqualsNative']
 else:
  assert d['recordingStatus']=='partial' and not d['publicDraftExists'] and d['privateNativeDraftExists']
 selectedSummary[key]={k:d.get(k) for k in ['status','recordingStatus','recordingRef','nativeRecordingSteps','finishGaps','publicDraftExists','privateNativeDraftExists','publicScriptEqualsNative']}
 selectedSummary[key].update({'run':r['id'],'mcpCalls':9,'fixedHelpers':4,'sdkParentIdentityVerified':True,'knownSecretLeakAssertionsPassed':True,'rawPrivateCapturesRemovedByOwner':True})
electron=repo/'tests/scratch/ui-workflow-visibility/1793012046502'
for p in sorted(electron.rglob('*')):
 if p.is_file():copy(p,Path('electron')/p.relative_to(electron))
tgz=repo/'.pi/skills/ui-testing-workflow/assets/pi-ui-testing-0.1.17.tgz'
bytes=tgz.read_bytes();lock=json.loads((repo/'tools/e2e/package-lock.json').read_text())['packages']['node_modules/pi-ui-testing']
assert lock['version']=='0.1.17'
assert lock['integrity']=='sha512-'+base64.b64encode(hashlib.sha512(bytes).digest()).decode()
export=json.loads((stage/'export-final-manifest.json').read_text());assert export['source_commit']=='96a603d1d498ceb709c7355b1585cbc05bd8ec38'
installation=repo/'tools/e2e/node_modules/pi-ui-testing';installCount=0
for path,digest in export['files'].items():
 if path.startswith('assets/runtime/'):
  installed=installation/path.removeprefix('assets/runtime/')
  assert installed.is_file() and hashof(installed.read_bytes())==digest,path
  installCount+=1
archive=repo/'docs/ui-testing-evidence/optimization-u02-recording-native-capture.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for member in members:tar.add(target/member['path'],arcname=member['path'],recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 stored={m.name:hashof(tar.extractfile(m).read()) for m in tar.getmembers() if m.isfile()}
assert stored=={m['path']:m['sha256'] for m in members}
ledgers={}
for name in ['u05-authorized-review-budget.json','pms-anonymous-authorized-review-budget.json']:
 ledgers[name]=hashof((repo/'tests/scratch/ui-optimization-u00'/name).read_bytes())
assert ledgers['u05-authorized-review-budget.json']=='34aaec3d27776ad96474be83f0be5a4eebe001fb41467afc69a4372c2b7e31ec'
assert ledgers['pms-anonymous-authorized-review-budget.json']=='854cec9cb4cb8574adcdec3163d7fd2953ab1016be4c9799f48a2cfa7bba87c3'
index={'schema_version':'1.0','date':datetime.now(timezone.utc).isoformat(),'stage':'U02 native recording fixture and fixed private capture','status':'NATIVE_CAPTURE_VALIDATED_PRODUCT_BROWSER_RECORDING_STILL_BLOCKED','planComplete':False,'baseCommit':'4e38fdc61ea5b9ac0375f45df1168e623f876362','nativeVersion':'0.1.17','nativeSourceCommit':export['source_commit'],'nativeSourcePushed':False,'nativePackageSha256':hashof(bytes),'installedFilesVerified':installCount,'sdkVersion':'1.2.0','playwrightVersion':'1.62.1','modelCalls':0,'formalRuns':0,'businessWrites':0,
 'nativeTests':{'passed':19,'captureTests':6,'priorVersionPassed':18,'missingFeatureBefore':{'passed':0,'failed':4},'ancestorControlBefore':{'passed':0,'failed':1},'typecheck':'PASS'},
 'unit':{'files':7,'passed':48},'selectedSdkSamples':selectedSummary,
 'allSdkAttempts':[{k:v for k,v in r.items() if k!='raw'} for r in runs],
 'sdkProductRegression':{'checks':21,'passed':True,'privateBrowserActionStillBlocked':True},
 'electron':{'checks':7,'passed':True,'directMcpTools':87,'scope':'isolated Electron discovery, toggles, persistence and reconnect; not PMS business recording'},
 'validation':{'typecheck':'PASS: all five configurations','build':'PASS','lint':'PASS','protocol':'PASS: structure; history heuristic SKIP (no tag)','layout':'PASS','diff':'PASS: task files','size':'PASS before and after initial archive; final archive recheck follows','clean':'preview only, no deletion'},
 'ledgerSha256':ledgers,
 'limits':['Only explicit private mirror and internal capture adapter were exercised; product automatic capture/filter/writer publication is not connected','Multiple frames/targets, arbitrary dependency closure, full reconnect continuation, filesystem races and real PMS role/tenant/data remain unverified','Fixture and CLI require one physical Playwright instance, not merely equal version strings; existing root installations were preserved','Original synthetic private state/events/traces and SDK raw temporary outputs were owner-cleaned; summaries and hashes are not archived original FileRefs','Initial missing-feature tests were later expanded from four to six; the exact first-four test source was not separately saved','Two earlier partial sample nativeDraftPublication labels were inherited incorrectly; original records remain, final corrupt/page selections use corrected harness and are reconciled against status and real files','ctx.toolCallId shortcut is absent in this SDK; real tool_call/tool_result parentToolCallId is authoritative','Project document files do not imply an application document index entity or formal result import'],
 'archive':{'path':str(archive.relative_to(repo)),'sha256':hashof(archive.read_bytes()),'bytes':archive.stat().st_size,'files':len(members),'allMembersReadbackVerified':True},
 'members':members,'projectStorage':{'status':'pending','systemId':'e2f5d42d-2781-4e68-a452-4c87c7d1d346','applicationDocumentIndexCreated':False,'storeModified':False}}
(repo/'docs/ui-testing-evidence/optimization-u02-recording-native-capture.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'files':len(members),'archiveBytes':archive.stat().st_size,'archiveSha256':index['archive']['sha256'],'selectedRuns':{k:v['run'] for k,v in selectedSummary.items()},'installedFilesVerified':installCount},ensure_ascii=False))
