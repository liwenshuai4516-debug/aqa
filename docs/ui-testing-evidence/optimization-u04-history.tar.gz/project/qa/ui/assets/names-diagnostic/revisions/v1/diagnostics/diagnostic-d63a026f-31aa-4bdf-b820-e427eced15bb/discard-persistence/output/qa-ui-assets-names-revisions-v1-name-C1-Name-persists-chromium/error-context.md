# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: qa/ui/assets/names/revisions/v1/name.spec.ts >> C1 Name persists
- Location: qa/ui/assets/names/revisions/v1/name.spec.ts:3:1

# Error details

```
Error: expect(locator).toHaveText(expected) failed

Locator: getByRole('listitem')
Timeout: 400ms
- Expected  - 3
+ Received  + 1

- Array [
-   "qa-ef3728e5-01a4-4df5-8a54-1a9c40a9ed1f",
- ]
+ Array []

Call log:
  - Expect "toHaveText" with timeout 400ms
  - waiting for getByRole('listitem')
    8 × locator resolved to 0 elements

```

# Page snapshot

```yaml
- generic [active] [ref=f1e1]:
  - heading "Names" [level=1] [ref=f1e2]
  - generic [ref=f1e3]:
    - generic [ref=f1e4]:
      - text: Name
      - textbox "Name" [ref=f1e5]
    - button "Save" [ref=f1e6]
  - list
```

# Test source

```ts
  1 | import {test,expect} from 'playwright/test';
  2 | test.use({storageState:{cookies:[],origins:[]}});
  3 | test('C1 Name persists',async({page})=>{
  4 |  const key='qa-'+crypto.randomUUID();await page.goto('/');
  5 |  await page.getByRole('textbox',{name:'Name'}).fill(key);
  6 |  await page.getByRole('button',{name:'Save'}).click();await page.reload();
> 7 |  await test.step('A1 Name persists after reload',async()=>{await expect(page.getByRole('listitem')).toHaveText([key]);});
    |                                                                                                     ^ Error: expect(locator).toHaveText(expected) failed
  8 | });
```