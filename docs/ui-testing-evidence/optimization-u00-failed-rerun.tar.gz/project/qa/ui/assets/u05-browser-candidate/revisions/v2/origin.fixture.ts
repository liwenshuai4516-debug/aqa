import { test as base } from "playwright/test";
import { createServer } from "node:http";
// Copy this authorized synthetic deployment's HTML, including any diagnostic mutation.
// Each test owns a new listening origin; fresh browser contexts provide separate storage too.
const usedPorts = new Set<number>();
export const test = base.extend({
 baseURL: async ({ baseURL }, use) => {
  if (!baseURL) throw new Error("Explicit synthetic source baseURL is required");
  const source = new URL(baseURL);
  if (source.protocol !== "http:" || source.hostname !== "127.0.0.1")
   throw new Error("Only the authorized loopback synthetic source is supported");
  const response = await fetch(source, { redirect: "error", signal: AbortSignal.timeout(10000) });
  if (!response.ok) throw new Error("Synthetic source is unavailable");
  const html = await response.text();
  const server = createServer((_request, reply) => {
   reply.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
   reply.end(html);
  });
  do {
  await new Promise<void>((ready, reject) => {
   server.once("error", reject);
   server.listen(0, "127.0.0.1", () => { server.removeListener("error", reject); ready(); });
  });
  const address=server.address();
  if (!address || typeof address === "string") throw new Error("No owned loopback origin");
  if (usedPorts.has(address.port)) { await new Promise<void>((done, reject) => server.close(error => error ? reject(error) : done())); continue; }
  usedPorts.add(address.port);
  break;
  } while (true);
  const address=server.address();
  if (!address || typeof address === "string") throw new Error("No owned loopback origin");
  try { await use("http://127.0.0.1:" + address.port); }
  finally {
   server.closeAllConnections();
   await new Promise<void>((done, reject) => server.close(error => error ? reject(error) : done()));
  }
 }
});
