{
  "feature": "states",
  "scenario": "states-declared",
  "states": [
    "loading with no rows precedes ready data in seed",
    "empty",
    "error"
  ],
  "source": {
    "path": "qa/ui/scopes/declaration/fixture.mjs",
    "sha256": "f07cad393d22c4629c771ef7763de96b47d030b6730fbec222fd110da2b89cc5"
  },
  "expected": [
    "loading precedes data",
    "no matches shows empty",
    "failure shows error"
  ],
  "observations": [
    {
      "path": "qa/ui/recordings/tester/loading-observation.json",
      "sha256": "edd4189199ba911abc216f8998545f4c21dc5f543df905d6d3dc1b6f95dbb414"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-51/response.json",
      "sha256": "b5212a8b03e5b5e73e02ed61a59edae3c2aba46f003e00c82c9276775f8e6a11"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-54/response.json",
      "sha256": "72bb09b66a7a125456566b5a5c6a4bf626b28a7e6ecf774b90ab33a5def26f8e"
    }
  ],
  "locators": {
    "query": "getByRole('textbox', { name: 'Query' })",
    "search": "getByRole('button', { name: 'Search' })",
    "reset": "getByRole('button', { name: 'Reset' })",
    "add": "getByRole('button', { name: 'Add' })",
    "name": "getByRole('textbox', { name: 'Name' })",
    "cancel": "getByRole('button', { name: 'Cancel' })",
    "save": "getByRole('button', { name: 'Save' })",
    "next": "getByRole('button', { name: 'Next' })",
    "previous": "getByRole('button', { name: 'Previous' })",
    "about": "getByRole('tab', { name: 'About' })",
    "details": "getByText('Details')",
    "list": "getByRole('tab', { name: 'List' })",
    "error": "getByRole('button', { name: 'Simulate error' })"
  },
  "gaps": []
}