{
  "feature": "paging",
  "scenario": "paging-declared",
  "states": [
    "first page",
    "last page",
    "query retained across next and previous",
    "both page boundaries"
  ],
  "source": {
    "path": "qa/ui/scopes/declaration/fixture.mjs",
    "sha256": "f07cad393d22c4629c771ef7763de96b47d030b6730fbec222fd110da2b89cc5"
  },
  "expected": [
    "two rows per page",
    "next and previous retain query"
  ],
  "observations": [
    {
      "path": "qa/ui/recordings/tester/events/action-32/response.json",
      "sha256": "4806c87d1c269988e1789e2b060ed54b3d7cab4bb5021073d9e1977ab95ef1b5"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-35/response.json",
      "sha256": "de86f866c507ca01c312687adea812ab12b46dd7c59ce6e4e6c9c6011f8dcfb6"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-38/response.json",
      "sha256": "adc9939e59aca8c1b800ffbc11f9eb4faf5d428cb938e8ea8be9698b83be1bad"
    }
  ],
  "locators": {
    "query": "getByRole('textbox', { name: 'Query' })",
    "search": "getByRole('button', { name: 'Search' })",
    "reset": "getByRole('button', { name: 'Reset' })",
    "add": "getByRole('button', { name: 'Add' })",
    "name": "getByRole('textbox', { name: 'Name' })",
    "cancel": "getByRole('button', { name: 'Cancel' })",
    "save": "getByRole('button', { name: 'Save' })",
    "next": "getByRole('button', { name: 'Next' })",
    "previous": "getByRole('button', { name: 'Previous' })"
  },
  "gaps": []
}