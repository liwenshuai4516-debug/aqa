{
  "feature": "search",
  "scenario": "search-declared",
  "states": [
    "filtered",
    "reset"
  ],
  "source": {
    "path": "qa/ui/scopes/declaration/fixture.mjs",
    "sha256": "f07cad393d22c4629c771ef7763de96b47d030b6730fbec222fd110da2b89cc5"
  },
  "expected": [
    "query filters names",
    "reset restores first page"
  ],
  "observations": [
    {
      "path": "qa/ui/recordings/tester/events/action-1/response.json",
      "sha256": "07920444a055dc98e1a8b0eb26612031fd128246219357ba662c3e0f39747790"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-6/response.json",
      "sha256": "dfee826ea47f7e9dd8010d5086c85998523dabe5c334e13503e6cb8617b9db9c"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-9/response.json",
      "sha256": "45dc85db54842e40c91fe34c843af436459153f6d6859e2515290abd85ca7d3c"
    }
  ],
  "locators": {
    "query": "getByRole('textbox', { name: 'Query' })",
    "search": "getByRole('button', { name: 'Search' })",
    "reset": "getByRole('button', { name: 'Reset' })"
  },
  "gaps": []
}