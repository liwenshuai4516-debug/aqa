{
  "feature": "details",
  "scenario": "details-declared",
  "states": [
    "about selected",
    "details expanded",
    "details collapsed"
  ],
  "source": {
    "path": "qa/ui/scopes/declaration/fixture.mjs",
    "sha256": "f07cad393d22c4629c771ef7763de96b47d030b6730fbec222fd110da2b89cc5"
  },
  "expected": [
    "tab selection changes panel",
    "details expansion changes visibility"
  ],
  "observations": [
    {
      "path": "qa/ui/recordings/tester/events/action-41/response.json",
      "sha256": "0bf4da47a63357af5e487ccd04bf509470b0c1be043f2ba626ff4f95ceb7687f"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-44/response.json",
      "sha256": "776607cce577f8d454956af7887d9487967fe607ccb7313f4141a693aa1b16e6"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-46/response.json",
      "sha256": "139f441bc7d80990669ce05445552f28a11f205c27501d4b03ec3a61aac2e140"
    }
  ],
  "locators": {
    "query": "getByRole('textbox', { name: 'Query' })",
    "search": "getByRole('button', { name: 'Search' })",
    "reset": "getByRole('button', { name: 'Reset' })",
    "add": "getByRole('button', { name: 'Add' })",
    "name": "getByRole('textbox', { name: 'Name' })",
    "cancel": "getByRole('button', { name: 'Cancel' })",
    "save": "getByRole('button', { name: 'Save' })",
    "next": "getByRole('button', { name: 'Next' })",
    "previous": "getByRole('button', { name: 'Previous' })",
    "about": "getByRole('tab', { name: 'About' })",
    "details": "getByText('Details')"
  },
  "gaps": []
}