{
  "feature": "edit",
  "scenario": "edit-declared",
  "states": [
    "dialog open",
    "filled then cancelled",
    "saved once",
    "one persisted name after reload"
  ],
  "source": {
    "path": "qa/ui/scopes/declaration/fixture.mjs",
    "sha256": "f07cad393d22c4629c771ef7763de96b47d030b6730fbec222fd110da2b89cc5"
  },
  "expected": [
    "dialog opens and cancels without writes",
    "saved name survives reload"
  ],
  "observations": [
    {
      "path": "qa/ui/recordings/tester/events/action-12/response.json",
      "sha256": "90bae53b5e338273c25fe1d1195ac961a019842429a6867483206152cfd6c00c"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-17/response.json",
      "sha256": "2adbcff1b6555e1daec53846a34f870c39a43ff746e4afbf69900ba5b2008afb"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-19/response.json",
      "sha256": "d5c39919f55062fe01409775feb33ed8d45bf7d8822ae44f3e13a46136176d1f"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-24/response.json",
      "sha256": "a0b72df983684560666397d4610770e6077464dfb8ad397315801d965aca8008"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-27/response.json",
      "sha256": "3debef4349d15ba1ed350799d25e7da3ee24e7f933ea21e6c675a7f5dd340b52"
    }
  ],
  "locators": {
    "query": "getByRole('textbox', { name: 'Query' })",
    "search": "getByRole('button', { name: 'Search' })",
    "reset": "getByRole('button', { name: 'Reset' })",
    "add": "getByRole('button', { name: 'Add' })",
    "name": "getByRole('textbox', { name: 'Name' })",
    "cancel": "getByRole('button', { name: 'Cancel' })",
    "save": "getByRole('button', { name: 'Save' })"
  },
  "gaps": []
}