import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import {resolve, join} from 'node:path';
import {ArtifactStore, sha256, verifyReferences} from 'pi-ui-testing';
import {seedStore} from '../../../plugins/data-space/seed.mjs';

const root=resolve('tests/scratch/ui-real-target-admission/source-only');
await fs.mkdir(root,{recursive:true});
const store=new ArtifactStore(root);
const markers={
 'app.js':['yr(zn,"TOKEN","token")','function X3(e)','Ky.defaults.baseURL="/api"','e.headers.token=Qr.get','function hre(e)','function RS(e)'],
 'login.js':['const u=g.data;Q.set(L0.TOKEN,u.token)'],
 'auth.js':['BASE_SERVICE+"/login"','BASE_SERVICE+"/permission"'],
 'tenant.js':['const e=n.length','await g()'],
 'permission.js':['a.set(_.AUTHORIZED_RESOURCES,o)'],
};
const names={'app.js':'index-C3vVbRNe.js','login.js':'index-uGPruASh.js','auth.js':'auth-BqGDvgoe.js','tenant.js':'useTenant-BRl2JReV.js','permission.js':'usePermission-zXACj9X4.js'};
const sources=[];
for(const [file,terms] of Object.entries(markers)){
 const bytes=await fs.readFile(new URL('./'+file,import.meta.url));const content=bytes.toString();
 const excerpts=terms.map(term=>{const offset=content.indexOf(term);assert.ok(offset>=0,term);const start=Math.max(0,offset-100),end=Math.min(content.length,offset+500);return{term,startCharacter:start,endCharacter:end,line:content.slice(0,start).split('\n').length,text:content.slice(start,end)};});
 const evidence={url:'http://192.168.90.224:8238/assets/'+names[file],sha256:sha256(bytes),bytes:bytes.length,excerpts,classification:'declaration',limitations:'Public deployed source; not an observed browser result or product requirement.'};
 const ref=await store.putFile('qa/ui/scopes/public-source/'+file+'.json',JSON.stringify(evidence,null,2)+'\n');sources.push({source_id:'public-'+file.replace('.','-'),oracle_type:'declaration',ref,statement:evidence.limitations});
}
const old=JSON.parse(await fs.readFile('/Users/liyingjun/.pi-web/data-space/store.json','utf8'));const seed=seedStore();
const fields=['featureId','code','title','priority','status','preconditions','note'];
const normalize=c=>({...Object.fromEntries(fields.map(k=>[k,c[k]??null])),steps:c.steps.map(({action,expect})=>({action,expect}))});
const cases=old.cases.filter(c=>['PMS-001','PMS-002','PMS-003','PMS-004'].includes(c.code)).map(c=>{
 const s=seed.cases.find(s=>s.id===c.id);assert.ok(s);return{id:c.id,code:c.code,semanticFieldsMatchSeed:JSON.stringify(normalize(c))===JSON.stringify(normalize(s)),currentType:c.type,seedType:s.type};
});
assert.equal(cases.length,4);assert.ok(cases.every(c=>c.semanticFieldsMatchSeed));
const created_at=new Date().toISOString();const envelope=(kind,id,data)=>({schema_version:'1.0',kind,id,created_at,data});
const scope=await store.put(envelope('scope','operation-contract-source-admission',{
 project_id:'operation-contract-source-research',environment_id:'public-deployment-unverified',role:'anonymous source reader; authenticated role unknown',
 goal:'Source-only admission research. Project aliases are research labels, not selected Data Space IDs. No browser, model review or business execution.',
 base_url:'http://192.168.90.224:8238/pms/OperationContract',allowed_actions:['Read public deployed resources'],sources,budget:{max_review_rounds:1,max_tool_calls:20},
}));
const inventory=await store.put(envelope('inventory','operation-contract-source-admission',{
 scope_ref:scope,features:[
 ['authentication','登录、租户与权限初始化',['login response data.token','account and tenants storage','permission resources'],['private adapter not implemented','current identity and role unverified']],
 ['drafts','按账号与业务类型保存草稿',['pms-business-drafts username namespace'],['real OperationContract draft interaction unrecorded','data lifecycle and cleanup unverified']],
 ['contract-state','经营合同状态声明',['DRAFT maps to 草稿','SIGNED maps to 已完成'],['seed expectations are demo data','business requirements not identified','deployed state transitions unobserved']],
 ].map(([id,name,states,gaps])=>({module_id:'operation-contract',feature_id:id,name,entry:'/pms/OperationContract',role:'unknown; source only',actions:['Inspect deployed public source'],scenarios:[{scenario_id:id+'-source',title:name+'声明核对'}],coverage:'discovered',source_refs:sources.map(s=>s.ref),source_locations:[],discovery:'source',priority:'P1',states,gaps})),
 unexplored:['Authenticated browser behavior','Search/reset','Create/submit/approve','Permissions by role','Real normal and error diagnostic targets'],
}));
await verifyReferences(root,await store.load(scope));await verifyReferences(root,await store.load(inventory));
const receipt={created_at,kind:'source-only-admission',scope_ref:scope,inventory_ref:inventory,sourceRoot:'tests/scratch/ui-real-target-admission/source-only',sourceFiles:sources.map(s=>s.ref),seedComparison:{seedSource:'plugins/data-space/seed.mjs',seedSourceSha256:sha256(await fs.readFile('plugins/data-space/seed.mjs')),fields:[...fields,'steps.action','steps.expect'],cases},dataSpaceSelection:'pending-user-choice',dataSpaceWrites:0,modelCalls:0,browserSessions:0,businessWrites:0,formalRuns:0,validation:'Native schema/store-load and recursive reference hashes passed; not a business test or independent approval'};
await fs.writeFile(join(root,'receipt.json'),JSON.stringify(receipt,null,2)+'\n');
console.log(JSON.stringify(receipt,null,2));
