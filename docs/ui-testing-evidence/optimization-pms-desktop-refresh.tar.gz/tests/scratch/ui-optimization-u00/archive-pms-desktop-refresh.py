from pathlib import Path
import json,hashlib,tarfile,io,os
repo=Path.cwd();out=repo/'tests/scratch/ui-pms-desktop-refresh/1792992083192';sha=lambda b:hashlib.sha256(b).hexdigest();r=json.loads((out/'result.json').read_text())
assert r['status']=='ELECTRON_REFRESH_MANAGED_TOKEN_NATIVE_CONSUMPTION_OBSERVED'
assert r['storeUnchanged'] and r['disconnectRemovedManagedState'] and r['privateRootRemoved'] and r['knownValuesAbsentFromPublicResult']
assert r['modelCalls']==r['formalRuns']==r['businessWrites']==r['selectedStoreWrites']==0
assert r['contexts'][0]['atLogin'] and r['contexts'][1]['atTarget'] and r['contexts'][1]['accountMatched']
assert all(c['pageErrors']==c['httpErrors']==c['blockedWriteRequests']==c['blockedForeignRequests']==0 for c in r['contexts'])
ledger=repo/'tests/scratch/ui-optimization-u00/u05-authorized-review-budget.json';assert sha(ledger.read_bytes())==json.loads((repo/'docs/ui-testing-evidence/optimization-pms-private-comparison.json').read_text())['modelReviewLedgerSha256']
(out/'.cleanup-keep').write_text('Retain actual Electron private-copy refresh evidence; not Agent business acceptance.\n')
sources={}
for name,path in {'plugin-index.mjs':'plugins/data-space/index.mjs','private-browser-state.mjs':'plugins/data-space/private-browser-state.mjs','env-script.mjs':'plugins/data-space/env-script.mjs','native-app.mjs':'tests/desktop/native-app.mjs','enable-data-space.mjs':'scripts/enable-data-space.mjs'}.items():
 target=out/'source'/name;target.parent.mkdir(exist_ok=True);target.write_bytes((repo/path).read_bytes());sources[name]={'origin':path,'sha256':sha(target.read_bytes())}
(out/'source-index.json').write_text(json.dumps(sources,indent=2)+'\n')
docdir=Path.home()/'Library/Application Support/Pi Agent Desktop/data/data-space/project-documents/e2f5d42d-2781-4e68-a452-4c87c7d1d346';store=docdir.parent.parent/'store.json';before=store.read_bytes()
text='''# 经营合同：实际 Electron 环境刷新与受管消费（隔离副本准备验证）

日期：2026-10-26。所选数据源为 Electron 桌面“项目管理系统”，项目/环境沿用原配置；目标 /pms/OperationContract。

已执行：只将所选项目与环境复制到工作区外0700私有目录；原参数、脚本和旧动态缓存原样保留。启动真实 Electron 主进程及后端，使用空模型认证/配置，通过正常鉴权 renderer 请求实际数据空间插件的 /env/refresh。force=true 后返回 ok、非cached、scriptRun成功；隔离库持久化新token和有效期，静态参数/脚本及内容revision保持不变。

随后请求实际插件 /automation prepare-private，只做token→token映射；受管文件中的token与刷新缓存一致，公开准备/刷新回执不含token。测试进程私下桥接自己的受管引用文件路径后，用原生authState验证工作区、origin/base URL和有效期。此跨进程测试桥接不是Agent业务执行，公开接口没有返回私有路径。

浏览器使用两个独立全新context：匿名41次同源读取后跳转/login；桌面刷新token组30次同源读取（含profile），到达经营合同页、“查询”出现1次，账号匹配。两组页面/HTTP错误0、写入和外域请求0。只允许同源GET/HEAD，不输入表单、不保存截图/trace/DOM/响应正文。零拒绝计数不等于守卫反例通过；插件后端刷新请求次数没有单独计量，不虚报零请求。

已清理：实际插件disconnect后受管状态删除；context、浏览器、自有Electron进程和整个私有副本删除。原store.json逐字节不变，原动态缓存未刷新，三条源码草稿状态不变。结果公开文本对已知配置值/本轮token及其URL编码、Base64检查未发现；这不是通用隐私过滤证明。

结论：所选环境副本的真实Electron刷新→持久缓存→受管准备→测试进程原生消费→路由/账号观察子链成立。它不等于原库环境缓存刷新、个人Agent会话、正式测试或发现到交付的全链验收。

剩余：业务角色/租户/隔离测试数据unknown；准备回执authentication/role/data仍unknown，recording为unsupported。私密录制及匿名候选独立设计评审/正反诊断/正式执行待完成。模型调用0、正式批次0、业务写入0；整计划未完成。

公开证据：desktop-refresh-1792992083192/。文件持久保存不代表应用文档列表可见或正式测试结果入库。
'''
snapshot=docdir/'desktop-refresh-1792992083192';snapshot.mkdir(mode=0o700);items=[]
for name in ['plan.json','result.json','harness.mjs','source-index.json']:
 b=(out/name).read_bytes();p=snapshot/name
 with p.open('xb') as f:f.write(b)
 os.chmod(p,0o600);assert p.read_bytes()==b;items.append({'path':name,'sha256':sha(b),'bytes':len(b)})
doc=docdir/'OperationContract-desktop-private-refresh-2026-10-26.md'
with doc.open('x') as f:f.write(text)
os.chmod(doc,0o600);assert doc.read_text()==text;assert store.read_bytes()==before
receipt={'document':{'path':str(doc),'sha256':sha(doc.read_bytes()),'bytes':doc.stat().st_size},'snapshot':{'path':str(snapshot),'files':items},'storeUnchanged':True,'application_document_index':'unsupported'}
(out/'data-space-documents.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
files={}
for p in sorted(out.rglob('*')):
 if p.is_file():assert not p.is_symlink();files[str(p.relative_to(repo))]=p.read_bytes()
for name in ['pms-desktop-refresh.log','verify-pms-desktop-refresh.mjs','archive-pms-desktop-refresh.py']:
 p=repo/'tests/scratch/ui-optimization-u00'/name;files[str(p.relative_to(repo))]=p.read_bytes()
archive=repo/'docs/ui-testing-evidence/optimization-pms-desktop-refresh.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for n,b in sorted(files.items()):
  m=tarfile.TarInfo(n);m.size=len(b);m.mtime=0;t.addfile(m,io.BytesIO(b))
with tarfile.open(archive) as t:
 assert set(t.getnames())==set(files)
 for m in t:assert t.extractfile(m).read()==files[m.name]
index={'date':'2026-10-26','status':r['status'],'plan_complete':False,'modelCalls':0,'formalRuns':0,'modelReviewLedgerSha256':sha(ledger.read_bytes()),'ledger_unchanged':True,'result':r,'durable_project_documents':receipt,'archive':{'path':str(archive.relative_to(repo)),'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'files':len(files),'roundtrip_verified':True},'files':[{'path':n,'sha256':sha(b),'bytes':len(b)}for n,b in sorted(files.items())]}
(repo/'docs/ui-testing-evidence/optimization-pms-desktop-refresh.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'files':len(files),'bytes':archive.stat().st_size,'persistent_files':len(items),'ledger_unchanged':True}))
