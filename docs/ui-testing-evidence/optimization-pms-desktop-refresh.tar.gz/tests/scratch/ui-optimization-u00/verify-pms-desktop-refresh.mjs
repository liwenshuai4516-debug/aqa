/** Actual Electron refresh and managed-state consumption; private selected-project copy, no model or business writes. */
import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir,mkdtemp,rm,readdir,access,chmod,cp,realpath} from 'node:fs/promises';
import {join} from 'node:path';
import {homedir,tmpdir} from 'node:os';
import electron from 'electron';
import {chromium} from 'playwright';
import {authState,sha256} from 'pi-ui-testing';
import {enableDataSpace} from '../../../scripts/enable-data-space.mjs';
import {launchNativeApp} from '../../desktop/native-app.mjs';
import {portUp} from '../../lib/port-utils.mjs';
import {ensureBuild} from '../../lib/ensure-build.mjs';
import {CHROME_PATH} from '../../lib/chrome.mjs';
assert.ok(process.argv.includes('--refresh-selected-private-copy'));
assert.equal(process.env.PI_WEB_SMOKE_PREBUILT,'1');
const repo=process.cwd();ensureBuild(repo,'pms-desktop-private-refresh');
const output=join(repo,'tests/scratch/ui-pms-desktop-refresh',String(Date.now()));await mkdir(output,{recursive:true});
const original=join(homedir(),'Library/Application Support/Pi Agent Desktop/data/data-space/store.json'),before=await readFile(original),source=JSON.parse(before);
const systemId='e2f5d42d-2781-4e68-a452-4c87c7d1d346',envId='f46a32da-2eac-43ca-86b8-2fa5eca5385c',selected=source.envs.find(e=>e.id===envId&&e.systemId===systemId);assert.ok(selected);
const target=new URL('/pms/OperationContract',selected.baseUrl),expectedAccount=selected.params.find(p=>p.key==='账号')?.value;assert.ok(expectedAccount);
const privateRoot=await realpath(await mkdtemp(join(tmpdir(),'pms-desktop-refresh-'))),dataDir=join(privateRoot,'data'),agentDir=join(privateRoot,'agent'),workspace=join(privateRoot,'work'),storePath=join(dataDir,'data-space/store.json');
const result={status:'blocked',systemId,envId,target:target.href,modelCalls:0,formalRuns:0,businessWrites:0,selectedStoreWrites:0,privateSelectedProjectCopy:true,prebuiltServerSha256:sha256(await readFile(join(repo,'dist/server/index.js'))),prebuiltDesktopSha256:sha256(await readFile(join(repo,'dist/desktop/main.js'))),limitations:['Actual Electron plugin HTTP path with native authState consumed in the test process, not an Agent business run','Private copy only; authoritative dynamic cache remains untouched','Account/route observations do not establish role, tenant or data readiness','No private recording, approved diagnostic or formal run']};
await writeFile(join(output,'plan.json'),JSON.stringify(result,null,2)+'\n');
let app,browser,prepared,privatePath,page,stage='isolated-setup';const secrets=[];
try{
 for(const p of [dataDir,agentDir,workspace,join(dataDir,'data-space')])await mkdir(p,{recursive:true,mode:0o700});
 await writeFile(join(agentDir,'auth.json'),'{}',{mode:0o600});await writeFile(join(agentDir,'models.json'),'{"providers":{}}',{mode:0o600});
 await enableDataSpace(repo,{agentDir,dataDir});
 const isolated={version:3,revision:source.revision,updatedAt:source.updatedAt,systems:source.systems.filter(s=>s.id===systemId),modules:[],features:[],cases:[],envs:[structuredClone(selected)]};
 for(const p of [...selected.params??[],...selected.dynamic??[]])if(p.value)secrets.push(String(p.value));
 // Preserve configured script, parameters and old cache exactly; refresh must replace dynamic values through the real plugin.
 await writeFile(storePath,JSON.stringify(isolated),{mode:0o600});
 await writeFile(join(dataDir,'plugin-permissions.json'),JSON.stringify({v:1,grants:[{pluginId:'data-space',family:'net',hosts:[target.hostname],reason:'Authorized selected-project isolated environment refresh',grantedAt:Date.now()}]}),{mode:0o600});
 const port=18979;assert.equal(await portUp(port),false);
 const env={...process.env};for(const k of Object.keys(env))if(/(API_KEY|AUTH_TOKEN|ACCESS_TOKEN|SECRET_ACCESS_KEY|SESSION_TOKEN)$/.test(k)||/^(AWS_|GOOGLE_|GCLOUD_|AZURE_|PI_)/.test(k)||['ELECTRON_RUN_AS_NODE','NODE_OPTIONS'].includes(k))delete env[k];
 Object.assign(env,{PI_DESKTOP_USER_DATA:join(privateRoot,'ui'),PI_CODING_AGENT_DIR:agentDir,PI_WEB_DATA_DIR:dataDir,PI_WEB_CWD:workspace,PI_WEB_PORT:String(port),PI_WEB_PLUGIN_CATALOG_URL:'off',PI_WEB_SDK:'bundled'});
 stage='electron-start';app=await launchNativeApp({executablePath:electron,packaged:false,env});page=await app.firstWindow();await page.waitForSelector('.app');
 async function request(path,body){return page.evaluate(async({path,body})=>{const response=await fetch('/plugins-api/data-space'+path,{method:body?'POST':'GET',credentials:'same-origin',...(body?{headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}:{})});if(!response.ok)throw new Error('plugin-request-rejected');return response.json();},{path,body});}
 stage='native-state';const state=await request('/state');assert.ok(state.systems.some(s=>s.id===systemId));assert.ok(state.envs.some(e=>e.id===envId));
 stage='actual-plugin-refresh';const refreshed=await request('/env/refresh',{envId,force:true});assert.equal(refreshed.ok,true);assert.equal(refreshed.cached,false);assert.equal(refreshed.scriptRun.ok,true);
 const current=JSON.parse(await readFile(storePath,'utf8')),fresh=current.envs.find(e=>e.id===envId),token=fresh.dynamic.find(v=>v.key==='token')?.value;assert.ok(token);secrets.push(token);
 assert.deepEqual(fresh.params,selected.params);assert.deepEqual(fresh.script,selected.script);assert.ok(Date.parse(fresh.dynamic.find(v=>v.key==='token').expiresAt)>Date.now());
 result.refresh={ok:true,cached:false,scriptRunOk:true,dynamicTokenPersisted:true,parametersUnchanged:true,scriptUnchanged:true,contentRevisionPreserved:current.revision===isolated.revision,publicResponseContainsToken:JSON.stringify(refreshed).includes(token)};assert.equal(result.refresh.publicResponseContainsToken,false);
 stage='actual-plugin-prepare';prepared=await request('/automation',{action:'prepare-private',engine:'ui',mode:'execute',workspace,systemId,envId,targetUrl:target.href,privateBindings:[{parameterKey:'token',storageKey:'token'}]});assert.equal(prepared.status,'prepared-private-execution');assert.equal(JSON.stringify(prepared).includes(token),false);
 const dirs=await readdir(join(dataDir,'data-space/private-browser'));assert.equal(dirs.length,1);privatePath=join(dataDir,'data-space/private-browser',dirs[0],'state.json');
 const managed=JSON.parse(await readFile(privatePath,'utf8'));assert.equal(managed.pi_ui_private.reference,prepared.auth.reference);assert.equal(managed.origins[0].localStorage[0].value,token);assert.equal(managed.origins[0].localStorage.length,1);
 // Cross-process bridge only inside this owned test. The public API never returns the private path.
 assert.equal(process.env[prepared.auth.reference],undefined);process.env[prepared.auth.reference]=privatePath;
 stage='native-consumption';try{assert.equal(await authState({auth:prepared.auth,base_url:target.href},workspace),privatePath);}finally{delete process.env[prepared.auth.reference];}
 result.preparation={status:prepared.status,authentication:prepared.preparation.authentication,role:prepared.preparation.role,data:prepared.preparation.data,recording:prepared.preparation.recording,currentDynamicTokenConsumed:true,nativeAuthStateScopeExpiryVerified:true,publicResponseContainsToken:false};
 stage='browser-observation';browser=await chromium.launch({headless:true,...(CHROME_PATH?{executablePath:CHROME_PATH}:{})});result.contexts=[];
 for(const [kind,path] of [['anonymous',undefined],['desktop-refreshed-managed-token',privatePath]]){
  const context=await browser.newContext({...(path?{storageState:path}:{}),serviceWorkers:'block',acceptDownloads:false});const observation={kind,readRequests:0,blockedWriteRequests:0,blockedForeignRequests:0,pageErrors:0,httpErrors:0};result.contexts.push(observation);
  try{
   await context.route('**/*',async route=>{const req=route.request();if(new URL(req.url()).origin!==target.origin){observation.blockedForeignRequests++;return route.abort();}if(!['GET','HEAD'].includes(req.method())){observation.blockedWriteRequests++;return route.abort();}observation.readRequests++;return route.continue();});
   const p=await context.newPage();p.on('pageerror',()=>observation.pageErrors++);p.on('response',r=>{if(r.status()>=400)observation.httpErrors++;});await p.goto(target.href,{waitUntil:'networkidle',timeout:25000});
   const u=new URL(p.url());observation.atTarget=u.origin===target.origin&&u.pathname===target.pathname;observation.atLogin=u.origin===target.origin&&u.pathname==='/login';observation.queryControlCount=await p.getByText('查询',{exact:true}).count();
   if(path)observation.accountMatched=await p.evaluate(async expected=>{let token=localStorage.getItem('token');try{const v=JSON.parse(token);if(typeof v==='string')token=v;}catch{}const r=await fetch('/api/base-service/account-profile',{redirect:'error',headers:{token,'x-parent-client-code':'pms','x-client-code':'pms'},signal:AbortSignal.timeout(10000)});const body=await r.json();return r.ok&&body.code===200&&body.data?.username===expected;},expectedAccount);
  }finally{await context.close();observation.contextClosed=true;}
 }
 assert.equal(result.contexts[0].atLogin,true);assert.equal(result.contexts[1].atTarget,true);assert.equal(result.contexts[1].accountMatched,true);
 stage='disconnect';await request('/automation',{action:'disconnect',engine:'ui',workspace,envId});await assert.rejects(access(privatePath));result.disconnectRemovedManagedState=true;
 result.status='ELECTRON_REFRESH_MANAGED_TOKEN_NATIVE_CONSUMPTION_OBSERVED';
}catch{result.blockedAt=stage;process.exitCode=1;}
finally{
 if(prepared)delete process.env[prepared.auth.reference];
 if(browser)await browser.close();if(app)await app.close();
 await rm(privateRoot,{recursive:true,force:true});await assert.rejects(access(privateRoot));result.privateRootRemoved=true;
 result.storeUnchanged=(await readFile(original)).equals(before);assert.ok(result.storeUnchanged);
 const publicText=JSON.stringify(result);for(const secret of secrets.filter(s=>s.length>=6))assert.ok(!publicText.includes(secret)&&!publicText.includes(encodeURIComponent(secret))&&!publicText.includes(Buffer.from(secret).toString('base64')));
 result.knownValuesAbsentFromPublicResult=true;
 await cp(new URL(import.meta.url),join(output,'harness.mjs'));await writeFile(join(output,'result.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({output,...result},null,2));
}
