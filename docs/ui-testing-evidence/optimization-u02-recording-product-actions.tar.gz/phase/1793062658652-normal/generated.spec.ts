import {test,expect} from '@playwright/test';test('heading',async({page})=>{await page.goto('/');await expect(page.getByRole('heading',{name:'Privacy fixture'})).toBeVisible();});
