from pathlib import Path
import hashlib, io, json, re, subprocess, tarfile
repo=Path.cwd()
phase=repo/'tests/scratch/ui-optimization-u00/recording-product-actions'
dest=repo/'docs/ui-testing-evidence/optimization-u02-recording-product-actions.tar.gz'
index=dest.with_name('optimization-u02-recording-product-actions.json')
hash=lambda b:hashlib.sha256(b).hexdigest()
sources=[
'.pi/skills/ui-testing-workflow/assets/mcp-extension.mjs',
'.pi/skills/ui-testing-workflow/assets/private-recording-actions.mjs',
'.pi/skills/ui-testing-workflow/assets/private-recording-preflight.mjs',
'.pi/skills/ui-testing-workflow/assets/private-recording-connection.mjs',
'.pi/skills/ui-testing-workflow/assets/private-recording-session.mjs',
'.pi/skills/ui-testing-workflow/assets/recording-preflight.mjs',
'.pi/skills/ui-testing-workflow/assets/recording-preflight-reporter.mjs',
'.pi/skills/ui-testing-workflow/SKILL.md',
'.pi/skills/ui-testing-workflow/references/maintenance.md',
'docs/ui-testing-optimization-plan.md','docs/ui-testing-optimization-execution.md',
'docs/project-map.md','docs/directory-reference.md',
'tests/ui-private-recording-product-test.mjs','tests/ui-testing-integration-test.mjs',
'tests/unit/ui-private-recording-actions.test.ts','tests/unit/ui-private-recording-preflight.test.ts',
'tests/unit/ui-private-recording-connection.test.ts','tests/unit/ui-private-recording-workspace.test.ts',
'tests/unit/ui-recording-preflight.test.ts']
entries=[]
for p in sorted(phase.rglob('*')):
 if p.is_file() and not p.is_symlink() and p.name!='project-storage.json':entries.append((p,'phase/'+p.relative_to(phase).as_posix()))
for relative in sources:entries.append((repo/relative,'source/'+relative))
for folder,label in [('tests/scratch/ui-workflow-visibility/1793063053412','electron'),('tests/scratch/ui-guards/1793063070164','guards')]:
 for p in sorted((repo/folder).rglob('*')):
  if p.is_file() and not p.is_symlink():entries.append((p,label+'/'+p.relative_to(repo/folder).as_posix()))
files=[]
with tarfile.open(dest,'w:gz') as archive:
 for p,name in entries:
  raw=p.read_bytes();data=raw
  # A failed unit assertion printed its disposable UUID fixture. Preserve a labelled reduced copy.
  if p.name=='unit-final.log':data=re.sub(rb'synthetic-[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}',b'[SYNTHETIC-UNIT-VALUE]',raw)
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o600;info.mtime=0
  archive.addfile(info,io.BytesIO(data))
  files.append({'path':name,'bytes':len(data),'sha256':hash(data),**({'reduction':'disposable unit UUID removed','source_sha256':hash(raw)} if raw!=data else {})})
with tarfile.open(dest,'r:gz') as archive:
 for f in files:
  data=archive.extractfile(f['path']).read()
  assert len(data)==f['bytes'] and hash(data)==f['sha256']
modes=['normal','ephemeral','corrupt','cancel','budget','existing','symlink','unsupported','helper-readonly','helper-plan','helper-delegate','helper-disabled']
samples=[]
for mode in modes:
 d=json.loads((phase/('product-'+mode+'-final.log')).read_text())
 assert d['status']=='PASS' and d['modelCalls']==d['formalRuns']==d['businessWrites']==0
 assert d['recordingStatus']==('complete' if mode in ['normal','ephemeral'] else 'partial')
 samples.append({'mode':mode,'status':d['status'],'recordingStatus':d['recordingStatus'],'gaps':d['finishGaps'],'recording_ref':d['recordingRef'],'evidence':'phase/'+Path(d['output']).name+'/result.json'})
checks={'typecheck':'typecheck-final-02.log','unit':'unit-final-02.log','build':'build.log','lint':'lint.log','protocol':'protocol.log','layout':'layout.log','sdk':'sdk-integration.log','guards':'guards.log','electron':'electron.log','size':'size-final.log','clean':'clean-final.log'}
for p in checks.values():assert (phase/p).is_file()
ledgers={}
for name,expected in [('u05-authorized-review-budget.json','34aaec3d27776ad96474be83f0be5a4eebe001fb41467afc69a4372c2b7e31ec'),('pms-anonymous-authorized-review-budget.json','854cec9cb4cb8574adcdec3163d7fd2953ab1016be4c9799f48a2cfa7bba87c3')]:
 actual=hash((phase.parent/name).read_bytes());assert actual==expected;ledgers[name]=actual
payload={'schema_version':'1.0','stage':'U02 explicit product recording actions','date':'2026-10-27','base_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'native_version':'0.1.18','status':'synthetic-product-subchain-verified; M1/M2 not released','model_calls':0,'formal_runs':0,'real_business_writes':0,'samples':samples,'verification':{'unit_files':8,'unit_tests':45,'sdk_checks':22,'guard_checks':9,'electron_checks':7,'mcp_tools':87,'logs':checks,'protocol_history':'SKIP: no Git tag','screenshots_inspected':['electron/after-skills.png','electron/mcp-status.png']},'ledgers_unchanged':ledgers,'limits':['Trusted explicit single-page/frame Chromium protocol only; not arbitrary project code sandbox or input dependency closure','Generic data-space record preparation remains unsupported','No real PMS business or Electron complete business workflow validated','Complete interrupted recording recovery and other targets not validated','Private synthetic protocol/storage/trace and SDK long raw temporary files were removed by owned harness; public receipts do not substitute for readable raw evidence','Personal application not reloaded or updated'], 'archive':{'path':dest.name,'bytes':dest.stat().st_size,'sha256':hash(dest.read_bytes()),'members':len(files),'uncompressed_bytes':sum(f['bytes'] for f in files),'readback_verified':True},'files':files}
index.write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(payload['archive'],ensure_ascii=False))
