from pathlib import Path
import hashlib,json,tarfile,io,os,shutil
repo=Path.cwd();scratch=repo/'tests/scratch/ui-optimization-u00';sha=lambda b:hashlib.sha256(b).hexdigest()
names=['normal','json','invalid','cancel','transient'];records={n:json.loads((scratch/('runtime-storage-'+n+'.log')).read_text()) for n in names}
for n,r in records.items():
 assert not r.get('errorSummary'),(n,r.get('errorSummary'))
 assert r['modelCalls']==r['formalRuns']==r['businessWrites']==0 and r['ownedRawOutputsRemoved']
 if n in ['invalid','cancel']:assert r['recordingStatus']=='partial' and not r['publicDraftExists'] and r['privateNativeDraftExists']
 else:assert r['recordingStatus']=='complete' and r['publicScriptEqualsNative'] and not r['finishGaps']
 if n!='transient':assert all(not t['containsSyntheticSecret'] and not t['mediaBlocks'] for t in r['tools']) and not any(f.get('containsSyntheticSecret') for f in r['findings'])
assert records['transient']['transientRuntimeStorageCleared'] and records['transient']['runtimeStorageLeakDespiteHeaderCapture']
assert records['json']['runtimeStorageJson'] and records['cancel']['cancelledAtPrivateCapture']
assert 'private-authentication-storage-invalid' in records['invalid']['finishGaps']
verified=0;files={}
for n,r in records.items():
 d=Path(r['output']);(d/'.cleanup-keep').write_text('Retain reduced public evidence; owned raw synthetic payload removed.\n')
 (d/'tests').mkdir(exist_ok=True);(d/'tests/seed.spec.ts').write_bytes((d/'seed.spec.ts').read_bytes());(d/'package.json').write_text('{"type":"module"}')
 def walk(v):
  global verified
  if isinstance(v,dict):
   if isinstance(v.get('path'),str) and isinstance(v.get('sha256'),str):
    p=Path(v['path']);assert not p.is_absolute() and '..' not in p.parts
    assert sha((d/p).read_bytes())==v['sha256'],str(d/p);verified+=1
   for x in v.values():walk(x)
  elif isinstance(v,list):
   for x in v:walk(x)
 for p in (d/'qa').rglob('*.json'):walk(json.loads(p.read_text()))
 walk(r['snapshot']['receipt']['inputs'])
 if n!='transient':walk(r['recordingRef']);walk(r.get('generatedScriptRef'))
 else:assert not (d/'qa').exists()
 for p in d.rglob('*'):
  assert not p.is_symlink()
  if p.is_file():files[str(p.relative_to(repo))]=p.read_bytes()
sdk=records['json']['sdkEvents'];calls=[e for e in sdk if e['kind']=='tool_call'];helpers=[e for e in calls if e['toolName'].endswith('__browser_run_code_unsafe')];assert len(calls)==9 and len(helpers)==4
for e in helpers:
 parent=next(p for p in calls if p['toolCallId']==e['parentToolCallId']);end=next(x for x in sdk if x['kind']=='tool_result' and x['toolCallId']==e['toolCallId']);assert not end['isError']
 assert sdk.index(end)<next(i for i,x in enumerate(sdk) if x['kind']=='tool_result' and x['toolCallId']==parent['toolCallId'])
extra=['probe-recording-runtime-storage.mjs','runtime-storage-recording-prototype.mjs','recording-runtime-storage-document.md','archive-recording-runtime-storage.py']+['runtime-storage-'+n+'.log' for n in names+['before','native','typecheck','unit','sdk-integration','desktop-visibility','lint','protocol','size']]
for n in extra:
 p=scratch/n;files[str(p.relative_to(repo))]=p.read_bytes()
export=scratch/'u02-recording-storage-export';manifest=json.loads((export/'bundle-manifest.json').read_text());assert manifest['runtime_version']=='0.1.14'
for n in ['bundle-manifest.json','assets/runtime/src/private-evidence.ts','assets/runtime/src/index.ts','assets/runtime/package.json','assets/runtime/dist/private-evidence.js']:
 p=export/n;files[str(p.relative_to(repo))]=p.read_bytes()
source=Path('/Users/liyingjun/Desktop/SW-QA/13-pi/agent-client');assert (source/'packages/ui-testing/src/private-evidence.ts').read_bytes()==(export/'assets/runtime/src/private-evidence.ts').read_bytes()
files['upstream/tests/ui-testing/private-evidence.test.mjs']=(source/'tests/ui-testing/private-evidence.test.mjs').read_bytes()
bundle=repo/'.pi/skills/ui-testing-workflow/assets/pi-ui-testing-0.1.14.tgz';assert bundle.read_bytes()==(export/'assets/pi-ui-testing-0.1.14.tgz').read_bytes()
visibility=json.loads((scratch/'runtime-storage-desktop-visibility.log').read_text());assert visibility['status']=='PASS'
for p in Path(visibility['evidence']).rglob('*'):
 if p.is_file():files[str(p.relative_to(repo))]=p.read_bytes()
ledgers={n:sha((scratch/n).read_bytes()) for n in ['u05-authorized-review-budget.json','pms-anonymous-authorized-review-budget.json']};assert ledgers==json.loads((repo/'docs/ui-testing-evidence/optimization-u02-recording-runtime-headers.json').read_text())['ledgerSha256']
docdir=Path.home()/'Library/Application Support/Pi Agent Desktop/data/data-space/project-documents/e2f5d42d-2781-4e68-a452-4c87c7d1d346';store=docdir.parent.parent/'store.json';before=store.read_bytes()
snap=docdir/('recording-runtime-storage-'+Path(records['json']['output']).name);snap.mkdir(mode=0o700)
for n,r in records.items():shutil.copytree(Path(r['output']),snap/n)
persisted=[]
for p in snap.rglob('*'):
 assert not p.is_symlink();os.chmod(p,0o700 if p.is_dir() else 0o600)
 if p.is_file():
  n,*parts=p.relative_to(snap).parts;assert p.read_bytes()==(Path(records[n]['output'])/Path(*parts)).read_bytes();persisted.append({'path':str(p.relative_to(snap)),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size})
doc=docdir/'OperationContract-recording-runtime-storage-2026-10-26.md';text=(scratch/'recording-runtime-storage-document.md').read_text()
with doc.open('x') as f:f.write(text)
os.chmod(doc,0o600);assert doc.read_text()==text and store.read_bytes()==before
archive=repo/'docs/ui-testing-evidence/optimization-u02-recording-runtime-storage.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for n,b in sorted(files.items()):
  m=tarfile.TarInfo(n);m.size=len(b);m.mtime=0;t.addfile(m,io.BytesIO(b))
with tarfile.open(archive) as t:
 assert set(t.getnames())==set(files)
 for m in t:assert t.extractfile(m).read()==files[m.name]
index={'date':'2026-10-26','status':'RUNTIME_STORAGE_OBSERVATION_IMPLEMENTED_TRANSIENT_VALUE_STILL_LEAKS','plan_complete':False,'product_private_recording':'unsupported','current_runs':records,'refsVerified':verified,'modelCalls':0,'formalRuns':0,'businessWrites':0,'ledgerSha256':ledgers,'runtime':{'version':'0.1.14','sourceCommit':manifest['source_commit'],'upstreamPushed':False,'path':str(bundle.relative_to(repo)),'sha256':sha(bundle.read_bytes())},'sdkOwnership':{'source':'actual SDK hook events','verifiedRun':'json','mcpCalls':len(calls),'privateCaptures':len(helpers)},'verification':{'nativeTests':'before 7 pass/1 fail; after 15 pass','typecheck':'5 configurations passed','vitest':'4 files,29 tests passed','sdkIntegration':'passed','desktopVisibility':visibility,'lint':'passed','protocol':'passed; unavailable tag heuristic skipped','size':'passed'},'unretainedRefs':{'transient':records['transient']['recordingRef'],'reason':'Synthetic secret leak in public QA; owned raw payload removed, source/reduced metrics retained; trace/storage hashes are observations only'},'document':{'path':str(doc),'sha256':sha(doc.read_bytes()),'storeUnchanged':True},'snapshot':{'path':str(snap),'files':persisted},'limits':['Private host observation method only; product record remains unsupported','Previously unobserved value removed before first capture still leaks','No generic concurrent/closed-context/cross-frame/sessionStorage/IndexedDB guarantee','SDK and isolated Electron discovery checks do not establish PMS business recording'], 'archive':{'path':str(archive.relative_to(repo)),'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'files':len(files),'roundtrip_verified':True},'files':[{'path':n,'sha256':sha(b),'bytes':len(b)} for n,b in sorted(files.items())]}
(repo/'docs/ui-testing-evidence/optimization-u02-recording-runtime-storage.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'files':len(files),'refs':verified,'snapshotFiles':len(persisted),'archiveBytes':archive.stat().st_size}))
