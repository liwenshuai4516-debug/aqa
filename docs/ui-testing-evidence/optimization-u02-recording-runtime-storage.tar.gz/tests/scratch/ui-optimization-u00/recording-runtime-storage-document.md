# U02 运行时存储值过滤：阶段记录

2026-10-26；Electron 权威数据空间“项目管理系统”；原生 pi-ui-testing 0.1.14、SDK 1.2.0、Playwright Test 1.62.1。使用自有合成 HTTP 站点及隔离身份，没有真实 PMS 业务录制。整体计划未完成，产品私密 record 仍 unsupported。

## 实现与复用

原生 PrivateEvidence 新增宿主 observeStorageState(state)：完整校验 cookies/origins/localStorage 值结构后，复用 storageSecrets/variants 累积字符串叶值与既有编码；create 也使用这个方法。新观察保留旧值，不因删除或轮换遗忘。坏状态固定错误且原子拒绝，不把错误正文或任意业务字符串当秘密字典。该方法不采集浏览器、不新增模型工具、不批准测试。

原生源码本地提交 92235e882a94d79106039a1c0f05fdaaf5f3c827，未推上游。从源码导出、编译 0.1.14 包，更新 e2e 清单和锁文件，经 install:e2e 安装，未改 node_modules 源码或个人配置。原生回归先在旧版本失败（observeStorageState 不存在），新增后私密证据/环境 15 项通过。

内部录制原型在同一个 SDK 固定私有 helper 中增加 Playwright context.storageState 写私有 storage.json，校验路径/普通文件，收紧权限后仅在宿主读入原生过滤器；随后仍完成 trace chunk、收集标准认证头、过滤父响应。helper 仍只返回固定摘要，参数没有绝对私有路径。原始存储内容和 trace 不进入 SDK 的公开响应。原 scope 上限 8 次 helper、30 次工具，原生 max_steps10；正常实际业务5次+私有4次=9次 MCP，原生 steps仅5。SDK 真实 tool_call/tool_result 的 parentToolCallId 记录调用归属。

## 五轮实际录制对照

1. 新 localStorage 字符串：complete、1脚本、gaps=[]，公开/原生草稿字节一致；公开响应/SDK长输出/工作区未检出已知初始与新增合成秘密或其受支持编码，媒体块0。
2. 新 localStorage 嵌套 JSON：同上；DOM反射其中字符串叶值，真实context.storageState含JSON结构，过滤器识别该叶值。
3. writer阶段坏存储结构：故障钩子将私有文件的value改为数字42，原生方法拒绝公开，私有原生草稿存在/公开不存在，partial/0脚本，保留private-authentication-storage-invalid等缺口。早期harness沿用corruptTraceRejected字段名，实际源码只改存储文件，未损坏trace；以精确源码为依据，后续样本字段已改名。
4. 采集响应到达时取消原signal：partial/0脚本、私有草稿保留/公开不存在，保留private-authentication-capture-cancelled等缺口，browser_close真实成功。
5. 采集前删除的新值：seed先确认runtime-token存在，再删除并确认null，DOM仍反射该旧值。当前state不再含值，标准认证头也未传该值；公开setup/snapshot和SDK长输出仍泄露。原生complete/1脚本不代表隐私通过，此为明确失败。不能用新增值正向轮覆盖它，也不能声称支持任意动态认证生命周期。

每轮模型调用、正式批次、真实业务写入均0，PMS剩余2次仅设计评审额度及旧U05账本摘要未变。无独立结果评审或正式报告交付。

## 工程与证据

完整5配置typecheck、4文件29项Vitest、lint、协议同步、size通过；协议tag启发式无可用tag跳过。SDK集成通过；使用已有构建的隔离Electron验证技能发现、禁用启用重载、MCP直连87工具和重连通过，未把这些检查当业务录制验收，未操作当前个人窗口。

证据及精确源码归档至 docs/ui-testing-evidence/optimization-u02-recording-runtime-storage.json / .tar.gz；包含原生包源码/manifest、对照结果、公开产物及Electron截图。原始合成私密payload/SDK临时输出按归属清理，自有进程关闭；第五轮泄露的公开QA不保留，指标/精确源码及安全草稿保留，其manifest引用明确不可回读。trace/storage摘要是实际观察值，不冒充已保留原始文件引用。

本文与五轮公开/减少内容快照保存到权威Electron项目文档，0700/0600、回读核验、store.json字节不变。文件保存不代表应用文档列表显示或正式结果入库。

下一步：解决首次采集前删除值的受控采集时机、frame/存储生命周期和协议结构冲突；确认固定unsafe helper及路径/预算边界后再收敛内部适配、接Electron产品全链。通用输入闭包、完整重连续录、真实角色/租户/数据、U00成对计量、U03/U07及M1/M2仍待完成。
