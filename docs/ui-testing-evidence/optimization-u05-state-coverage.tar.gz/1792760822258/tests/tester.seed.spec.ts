import {test,expect} from '@playwright/test';
import {writeFile} from 'node:fs/promises';
test('seed',async({page})=>{
 await page.addInitScript(()=>{
  const states: {status:string,rows:string[]}[]=[];
  (window as any).__u05StatusObservations=states;
  new MutationObserver(()=>{
   const status=document.querySelector('[role=status]')?.textContent;
   if(status && status!==states.at(-1)?.status)
    states.push({status,rows:Array.from(document.querySelectorAll('li'),li=>li.textContent||'')});
  }).observe(document,{subtree:true,childList:true,characterData:true});
 });
 await page.goto('/?role=tester');
 await expect(page.locator('#identity')).toHaveText('Role: tester');
 await expect(page.getByRole('status')).toHaveText('Ready');
 const states=await page.evaluate(()=>(window as any).__u05StatusObservations);
 expect(states).toEqual([{status:'Loading',rows:[]},{status:'Ready',rows:["Alpha","Beta"]}]);
 await writeFile('qa/ui/recordings/tester/loading-observation.json',JSON.stringify({role:"tester",states}));
});