{
  "feature": "permission",
  "scenario": "permission-declared",
  "states": [
    "viewer Add hidden"
  ],
  "source": {
    "path": "qa/ui/scopes/declaration/fixture.mjs",
    "sha256": "f07cad393d22c4629c771ef7763de96b47d030b6730fbec222fd110da2b89cc5"
  },
  "expected": [
    "viewer cannot see Add",
    "tester can see Add"
  ],
  "observations": [
    {
      "path": "qa/ui/recordings/viewer/events/action-54/response.json",
      "sha256": "f2bf4d1efe3339b2f7406f538f3e8b4615d9f68d21bc7e42f4dcce9e523649b3"
    }
  ],
  "locators": {},
  "gaps": [
    "Tester observation remains in the original tester scope"
  ]
}