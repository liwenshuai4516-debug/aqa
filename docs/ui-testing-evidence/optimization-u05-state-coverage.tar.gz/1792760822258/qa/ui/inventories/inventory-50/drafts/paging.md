{
  "feature": "paging",
  "scenario": "paging-declared",
  "states": [
    "first page",
    "last page",
    "query retained across next and previous",
    "both page boundaries"
  ],
  "source": {
    "path": "qa/ui/scopes/declaration/fixture.mjs",
    "sha256": "f07cad393d22c4629c771ef7763de96b47d030b6730fbec222fd110da2b89cc5"
  },
  "expected": [
    "two rows per page",
    "next and previous retain query"
  ],
  "observations": [
    {
      "path": "qa/ui/recordings/tester/events/action-34/response.json",
      "sha256": "f04c22b896e8e0da9a25583968deb66ba0f4aa0b1cdaffb71da279187ab1e1ef"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-37/response.json",
      "sha256": "5bdfd695f9a7f44df0a55315f94493f0d656a83b6591e3b27d7691b211e80892"
    }
  ],
  "locators": {
    "query": "getByRole('textbox', { name: 'Query' })",
    "search": "getByRole('button', { name: 'Search' })",
    "reset": "getByRole('button', { name: 'Reset' })",
    "add": "getByRole('button', { name: 'Add' })",
    "name": "getByRole('textbox', { name: 'Name' })",
    "cancel": "getByRole('button', { name: 'Cancel' })",
    "save": "getByRole('button', { name: 'Save' })",
    "next": "getByRole('button', { name: 'Next' })",
    "previous": "getByRole('button', { name: 'Previous' })"
  },
  "gaps": []
}