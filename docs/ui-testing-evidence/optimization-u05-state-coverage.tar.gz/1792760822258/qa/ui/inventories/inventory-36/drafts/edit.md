{
  "feature": "edit",
  "scenario": "edit-declared",
  "states": [
    "dialog open",
    "filled then cancelled",
    "saved once",
    "one persisted name after reload"
  ],
  "source": {
    "path": "qa/ui/scopes/declaration/fixture.mjs",
    "sha256": "f07cad393d22c4629c771ef7763de96b47d030b6730fbec222fd110da2b89cc5"
  },
  "expected": [
    "dialog opens and cancels without writes",
    "saved name survives reload"
  ],
  "observations": [
    {
      "path": "qa/ui/recordings/tester/events/action-12/response.json",
      "sha256": "b9b25465f046d8ee3a05c81cab769f1784e91dc287cdbff84e610065ec4e211e"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-17/response.json",
      "sha256": "052645c69fefda69d4dc0d01a07a1684c269e256e838c657dc13dd730379e763"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-19/response.json",
      "sha256": "88f633940518557329f6531fb0fe2972e4b1d83bba69794b5cad96a12a0543fe"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-24/response.json",
      "sha256": "94ad252250896ef668e70ee869b66ea6f002b269430d160eeb3a6f1a66837b04"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-27/response.json",
      "sha256": "47a79565010b54501aae6559fc27978f4683a1d92d4cd5412cdd63df2cbe7f83"
    }
  ],
  "locators": {
    "query": "getByRole('textbox', { name: 'Query' })",
    "search": "getByRole('button', { name: 'Search' })",
    "reset": "getByRole('button', { name: 'Reset' })",
    "add": "getByRole('button', { name: 'Add' })",
    "name": "getByRole('textbox', { name: 'Name' })",
    "cancel": "getByRole('button', { name: 'Cancel' })",
    "save": "getByRole('button', { name: 'Save' })"
  },
  "gaps": []
}