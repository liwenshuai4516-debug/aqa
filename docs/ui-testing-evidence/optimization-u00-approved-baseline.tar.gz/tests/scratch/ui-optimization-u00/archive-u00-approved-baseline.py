import json, hashlib, tarfile, io
from pathlib import Path
repo=Path.cwd(); root=repo/'tests/scratch/ui-browser-candidate/1792809587795'; output=repo/'tests/scratch/ui-approved-baseline/1792922618301'; files={}
sha=lambda b:hashlib.sha256(b).hexdigest()
def add(p):
 p=Path(p);assert not p.is_symlink();name=str(p.relative_to(repo));assert not any(v in name.split('/') for v in ['ui-review-authority','private-authority','auth.json','model-cache.json','node_modules']);files[name]=p.read_bytes()
r=json.loads((output/'result.json').read_text());assert r['status']=='PASS';assert r['results']['data']['counts']['passed']==6;assert r['results']['details']['assertion_reached_attempt_count']==13
assert len(r['samples'])==18
priorpath=repo/'docs/ui-testing-evidence/optimization-u05-approved-run.json';prior=json.loads(priorpath.read_text());assert sha((repo/prior['archive']['path']).read_bytes())==prior['archive']['sha256']
ledger='tests/scratch/ui-optimization-u00/u05-authorized-review-budget.json';assert sha((repo/ledger).read_bytes())==next(f['sha256'] for f in prior['files'] if f['path']==ledger),'No new fee calls permitted'
refs={}
def verify(ref):
 p=root/ref['path'];assert sha(p.read_bytes())==ref['sha256'],ref['path'];refs[ref['path']]=ref['sha256']
for ref in r['immutable_refs']+[r['execution']['run_ref'],r['results']['results_ref'],r['task']['task_ref']]:verify(ref)
for ref in r['execution']['run']['data']['output_refs']:verify(ref)
for p in (root/Path(r['execution']['run_ref']['path']).parent).rglob('*'):
 if p.is_file():add(p)
for p in output.iterdir():
 if p.is_file():add(p)
for p in (repo/'tests/scratch/ui-optimization-u00').glob('u00-approved-*.log'):add(p)
for p in ['tests/ui-approved-baseline-measure.mjs','tests/scratch/ui-optimization-u00/archive-u00-approved-baseline.py',r['task']['task_ref']['path']]:
 add(root/p if p.startswith('qa/') else repo/p)
add(priorpath)
archive=repo/'docs/ui-testing-evidence/optimization-u00-approved-baseline.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for n,b in sorted(files.items()):
  m=tarfile.TarInfo(n);m.size=len(b);m.mtime=0;t.addfile(m,io.BytesIO(b))
with tarfile.open(archive) as t:
 assert set(t.getnames())==set(files)
 for m in t:assert t.extractfile(m).read()==files[m.name]
summary=[{k:s[k] for k in ['operation','round','elapsed_ms']}|{'host_readFile_calls':sum(s['files']['readFile'].values()),'host_readdir_calls':sum(s['files']['readdir'].values()),'direct_children':s['directChildren']} for s in r['samples']]
index={'date':'2026-10-25','status':'CURRENT_APPROVED_REGRESSION_MEASURED_BASELINE_INCOMPLETE','plan_complete':False,'plan':r['plan'],'formal_run_ref':r['execution']['run_ref'],'counts':r['results']['data']['counts'],'assertions_reached':13,'samples':summary,'model_calls':0,'fee_ledger_unchanged':True,'prior_approved_evidence':prior['archive'],'public_refs_verified':refs,'remaining':r['plan']['missing'],'limits':['Host async fs/promises calls only, not all OS I/O or child I/O','Direct child events do not count nested browser launches','Setup/OS caches warm; observer overhead retained','One current-version regression, no paired full-workflow speed claim','New benchmark execution task blocked at analyze; no new independently approved report delivery','Historical approved run/report/review/delivery immutable'], 'validation':{'typecheck':'passed','vitest':'51 passed in 3 files','lint':'passed','protocol':'structure passed; history no-tag skip','desktop':'not rerun; measurement-only addition','cleanup':'preview only; no deletion'},'archive':{'path':str(archive.relative_to(repo)),'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'files':len(files),'roundtrip_verified':True},'files':[{'path':n,'sha256':sha(b),'bytes':len(b)} for n,b in sorted(files.items())]}
(repo/'docs/ui-testing-evidence/optimization-u00-approved-baseline.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'files':len(files),'bytes':archive.stat().st_size,'refs':len(refs)}))
