# U02 存储观察器边界：阶段记录

2026-10-26；Electron 权威项目“项目管理系统”；SDK 1.2.0、Playwright Test 1.62.1、原生 pi-ui-testing 0.1.14（本轮未改运行包）。自有合成站点/身份，模型调用、正式批次、真实业务写入均0。产品私密 record 仍 unsupported，整体计划未完成。

## 复现、修改与实际验证

真实 Chromium 前后探针各4种情况：旧模块接受新增frame、已有frame和已导航页面，解除监听后拒绝刷新；修正后四种均拒绝。frame内容是空合成页面，此处证明未拒绝超出支持范围的结构，未声称已复现frame凭据泄露。

内部 observePrivateStorage 在创建私有文件或启动CDP前校验当前page.url为about:blank、frames=1、context.pages=1；已有frame、非blank、多页面立即拒绝。安装后记录frameattached历史标记，读取侧拒绝该未知事件，即使frame随后移除仍不放行；dispose移除新增监听。当前URL检查只核对安装时前提，不能证明页面过去从未导航；受控seed的每次新context/page事实仍来自Playwright fixture及冻结源码，不把URL当生命周期证明。并发初始化未证明。

实际SDK/MCP四轮：

- 旧模块对照：受控writer响应前固定helper附加并移除空iframe，仍complete/1脚本/gaps=[]，证明旧模块会放行未覆盖frame历史。
- 修正后frame对照：同样实际附加/移除；私有草稿保留、公开草稿不存在，partial/0脚本，保留private-storage-frame-history-rejected、missing-generated-script、goal-not-reached、tool-error-or-cancelled。
- CDP监听解除：受控seed仅为本负向夹具给page绑定私有dispose函数，固定helper await该函数（实际client.detach），再刷新失败；私有草稿保留/公开不存在，partial/0脚本，保留private-storage-observer-detached等缺口。不是MCP整个连接断开，不混称全链重连续录。
- 正向：新context/page、瞬态嵌套JSON字符串在首次state采集前已删除，正常complete/1脚本/gaps=[]，公开和原生草稿字节一致；公开响应、SDK长输出及工作区未检出本轮已知初始/新增秘密及受支持编码，媒体块0。

两类partial的browser_close均实际成功。正向实际5业务工具+4私有helper=9 MCP，原生steps只计5；SDK真实tool_call/tool_result保留parentToolCallId归属。scope明确8次helper、30次工具、128事件/2MiB，负向夹具明确允许附加/移除空frame或解除其自有观察器。无真实PMS业务操作、模型评审或正式结果交付。

## 测试依据与保存

新增frame历史和初态2项测试。初版9项在旧模块为8通过/1失败，但初态测试仅检查最终报错，会因旧模块重复安装属性时报错而误通过；已强化为“启动CDP前拒绝且不创建任何捕获文件”。使用精确旧模块快照再跑强化版，7通过/2失败；修正后全部通过，相关3文件28项Vitest、完整5配置typecheck、lint、协议同步、size、diff通过。初版弱测试源码未单独保存，日志只作历史，不冒称有精确源码；强化负向源码/旧模块/日志完整保存。临时baseline单测执行后已移出正常单测目录，保留归档副本，不把预期失败混进最终通过率。

证据归档 docs/ui-testing-evidence/optimization-u02-recording-storage-boundaries.json / .tar.gz。保留旧模块、原生浏览器前后探针、4轮SDK原生公开产物及精确输入快照/源码。原始私有事件/trace/state和SDK临时输出按归属清理，自有进程结束；摘要不冒充原始文件可回读。PMS剩余2次仅设计评审及U05账本摘要不变。

本文与公开快照保存到Electron项目文档，0700/0600、逐文件回读、store.json未写，不声称应用文档列表显示或正式结果入库。本轮未重跑Electron界面：内部资产仍未被产品mcp-extension导入；前轮发现/禁用/重载结果保留，不计本轮通过。未改个人配置/安装，不操作当前应用窗口。

此步是明确拒绝未覆盖frame/初态和失效监听的安全边界，不是多frame录制能力或最终交付。后续需处理实际产品所需frame/target支持、并发初始化/监听完整性、完整重连续录和产品生命周期接入；通用输入闭包、真实角色/租户/数据、U00计量、U03/U07及M1/M2仍未完成。
