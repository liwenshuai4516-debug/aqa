from pathlib import Path
import hashlib,json,tarfile,io,os,shutil
repo=Path.cwd();scratch=repo/'tests/scratch/ui-optimization-u00';sha=lambda b:hashlib.sha256(b).hexdigest()
names={n:'storage-boundaries-sdk-'+n+'.log' for n in ['before','frame','detach','normal']};records={n:json.loads((scratch/f).read_text()) for n,f in names.items()}
for n,r in records.items():
 assert not r.get('errorSummary'),(n,r.get('errorSummary'))
 assert r['modelCalls']==r['formalRuns']==r['businessWrites']==0 and r['ownedRawOutputsRemoved']
 if n in ['frame','detach']:assert r['recordingStatus']=='partial' and not r['publicDraftExists'] and r['privateNativeDraftExists']
 else:assert r['recordingStatus']=='complete' and r['publicScriptEqualsNative'] and not r['finishGaps']
 assert all(not t['containsSyntheticSecret'] and not t['mediaBlocks'] for t in r['tools']) and not any(f.get('containsSyntheticSecret') for f in r['findings'])
assert records['normal']['runtimeStorageJson'] and records['normal']['transientRuntimeStorageCleared']
assert records['before']['oldObserver'] and records['before']['boundaryMode']=='frame-attach-remove'
assert 'private-storage-frame-history-rejected' in records['frame']['finishGaps'] and 'private-storage-observer-detached' in records['detach']['finishGaps']
verified=0;files={}
for n,r in records.items():
 d=Path(r['output']);(d/'.cleanup-keep').write_text('Retain public reduced evidence; owned raw synthetic payload removed.\n')
 for local,relative in [('seed.spec.ts','tests/seed.spec.ts'),('observe-storage.mjs','tests/observe-storage.mjs')]:
  (d/relative).parent.mkdir(exist_ok=True);(d/relative).write_bytes((d/local).read_bytes())
 (d/'package.json').write_text('{"type":"module"}')
 def walk(v):
  global verified
  if isinstance(v,dict):
   if isinstance(v.get('path'),str) and isinstance(v.get('sha256'),str):
    p=Path(v['path']);assert not p.is_absolute() and '..' not in p.parts
    assert sha((d/p).read_bytes())==v['sha256'],str(d/p);verified+=1
   for x in v.values():walk(x)
  elif isinstance(v,list):
   for x in v:walk(x)
 for p in (d/'qa').rglob('*.json'):walk(json.loads(p.read_text()))
 walk(r['snapshot']['receipt']['inputs']);walk(r['recordingRef']);walk(r.get('generatedScriptRef'))
 for p in d.rglob('*'):
  assert not p.is_symlink()
  if p.is_file():files[str(p.relative_to(repo))]=p.read_bytes()
sdk=records['normal']['sdkEvents'];calls=[e for e in sdk if e['kind']=='tool_call'];helpers=[e for e in calls if e['toolName'].endswith('__browser_run_code_unsafe')];assert len(calls)==9 and len(helpers)==4
for e in helpers:
 parent=next(p for p in calls if p['toolCallId']==e['parentToolCallId']);end=next(x for x in sdk if x['kind']=='tool_result' and x['toolCallId']==e['toolCallId']);assert not end['isError']
 assert sdk.index(end)<next(i for i,x in enumerate(sdk) if x['kind']=='tool_result' and x['toolCallId']==parent['toolCallId'])
extra=['probe-recording-observer-boundaries.mjs','observer-boundaries-recording-prototype.mjs','storage-boundaries-observer-before.mjs','probe-storage-observer-boundaries.mjs','storage-boundaries-document.md','archive-storage-boundaries.py','storage-boundaries-unit-baseline.test.ts']+list(names.values())+['storage-boundaries-'+n+'.log' for n in ['before','native','typecheck','unit','unit-before','unit-strengthened-before','lint','protocol','size']]
for n in extra:
 p=scratch/n;files[str(p.relative_to(repo))]=p.read_bytes()
for n in ['.pi/skills/ui-testing-workflow/assets/private-recording-storage-events.mjs','tests/unit/ui-private-recording-storage-events.test.ts']:files[n]=(repo/n).read_bytes()
probes={n:json.loads((scratch/('storage-boundaries-'+n+'.log')).read_text()) for n in ['before','native']}
assert [x['rejected'] for x in probes['before']['observations']]==[False,False,False,True]
assert all(x['rejected'] for x in probes['native']['observations'])
ledgers={n:sha((scratch/n).read_bytes()) for n in ['u05-authorized-review-budget.json','pms-anonymous-authorized-review-budget.json']};assert ledgers==json.loads((repo/'docs/ui-testing-evidence/optimization-u02-recording-storage-events.json').read_text())['ledgerSha256']
docdir=Path.home()/'Library/Application Support/Pi Agent Desktop/data/data-space/project-documents/e2f5d42d-2781-4e68-a452-4c87c7d1d346';store=docdir.parent.parent/'store.json';before=store.read_bytes()
snap=docdir/('recording-storage-boundaries-'+Path(records['normal']['output']).name);snap.mkdir(mode=0o700)
for n,r in records.items():shutil.copytree(Path(r['output']),snap/n)
persisted=[]
for p in snap.rglob('*'):
 assert not p.is_symlink();os.chmod(p,0o700 if p.is_dir() else 0o600)
 if p.is_file():
  n,*parts=p.relative_to(snap).parts;assert p.read_bytes()==(Path(records[n]['output'])/Path(*parts)).read_bytes();persisted.append({'path':str(p.relative_to(snap)),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size})
doc=docdir/'OperationContract-recording-storage-boundaries-2026-10-26.md';text=(scratch/'storage-boundaries-document.md').read_text()
with doc.open('x') as f:f.write(text)
os.chmod(doc,0o600);assert doc.read_text()==text and store.read_bytes()==before
archive=repo/'docs/ui-testing-evidence/optimization-u02-recording-storage-boundaries.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for n,b in sorted(files.items()):
  m=tarfile.TarInfo(n);m.size=len(b);m.mtime=0;t.addfile(m,io.BytesIO(b))
with tarfile.open(archive) as t:
 assert set(t.getnames())==set(files)
 for m in t:assert t.extractfile(m).read()==files[m.name]
index={'date':'2026-10-26','status':'FRAME_HISTORY_AND_INITIAL_PAGE_PRECONDITIONS_REJECTED_OBSERVER_DETACH_BLOCKS_PUBLICATION','plan_complete':False,'product_private_recording':'unsupported','current_runs':records,'refsVerified':verified,'modelCalls':0,'formalRuns':0,'businessWrites':0,'ledgerSha256':ledgers,'runtimeVersion':'0.1.14 unchanged','sdkOwnership':{'source':'actual SDK hook events','verifiedRun':'normal','mcpCalls':len(calls),'privateCaptures':len(helpers)},'verification':{'nativeProbes':probes,'typecheck':'5 configurations passed','vitest':'3 files,28 tests passed','negativeUnit':'strengthened baseline:7 pass/2 fail; weaker earlier test:8 pass/1 fail, initial-state false positive corrected','lint':'passed','protocol':'passed; unavailable tag heuristic skipped','size':'passed','desktop':'not repeated; internal observer only, product entry remains closed'},'sourceLimits':['Earlier weak unit source not separately snapshotted; its log is history, not an exact-source replay','Blank current URL is an initial precondition, not proof of prior navigation history'],'document':{'path':str(doc),'sha256':sha(doc.read_bytes()),'storeUnchanged':True},'snapshot':{'path':str(snap),'files':persisted},'limits':['Rejects unsupported frame history; does not implement multi-frame recording','No concurrent initialization/existing-page lifetime/complete reconnect or filesystem race proof','CDP observer detach is not a full MCP disconnect','Raw private events/trace/storage removed by ownership; hashes are not retained raw FileRefs'], 'archive':{'path':str(archive.relative_to(repo)),'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'files':len(files),'roundtrip_verified':True},'files':[{'path':n,'sha256':sha(b),'bytes':len(b)} for n,b in sorted(files.items())]}
(repo/'docs/ui-testing-evidence/optimization-u02-recording-storage-boundaries.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'files':len(files),'refs':verified,'snapshotFiles':len(persisted),'archiveBytes':archive.stat().st_size}))
