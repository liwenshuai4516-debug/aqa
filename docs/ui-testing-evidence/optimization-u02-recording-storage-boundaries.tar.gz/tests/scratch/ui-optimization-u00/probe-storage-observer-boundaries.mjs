import assert from 'node:assert/strict';
import {mkdtemp,rm,realpath} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {chromium} from 'playwright';
import {CHROME_PATH} from '../../lib/chrome.mjs';
import {observePrivateStorage,readPrivateStorageEvents} from '../../../.pi/skills/ui-testing-workflow/assets/private-recording-storage-events.mjs';
const baseline=process.argv.includes('--baseline');
const root=await realpath(await mkdtemp(join(tmpdir(),'storage-boundaries-')));let browser;
const result={modelCalls:0,businessWrites:0,baseline,observations:[]};
try{
 browser=await chromium.launch({headless:true,...(CHROME_PATH?{executablePath:CHROME_PATH}:{})});
 for(const mode of ['frame','existing-frame','existing-page','detach']){
  const context=await browser.newContext(),page=await context.newPage(),file=join(root,mode+'.ndjson');
  if(mode==='existing-frame')await page.setContent('<iframe srcdoc="<p>Existing controlled frame</p>"></iframe>');
  if(mode==='existing-page')await page.goto('data:text/html,<p>Already navigated controlled page</p>');
  if(['existing-frame','existing-page'].includes(mode)){
   let rejected=false;try{await observePrivateStorage(page,file);}catch{rejected=true;}
   assert.equal(rejected,!baseline);result.observations.push({mode,rejected,frameCount:page.frames().length});
  }else{
   const observer=await observePrivateStorage(page,file);
   if(mode==='frame')await page.setContent('<iframe srcdoc="<p>Controlled frame</p>"></iframe>');
   else await observer.dispose();
   let rejected=false;try{await observer.flush();readPrivateStorageEvents(file,'http://fixture.invalid');}catch{rejected=true;}
   assert.equal(rejected,mode==='detach'||!baseline);result.observations.push({mode,rejected,frameCount:page.frames().length});
  }
  await context.close();
 }
 result.status=baseline?'BASELINE_FRAME_AND_EXISTING_PAGE_ACCEPTANCE_REPRODUCED':'FRAME_EXISTING_PAGE_AND_DETACH_REJECTED';
}finally{await browser?.close();await rm(root,{recursive:true,force:true});console.log(JSON.stringify(result,null,2));}
