{
  "feature": "permission",
  "scenario": "permission-declared",
  "states": [
    "tester sees Add"
  ],
  "source": {
    "path": "qa/ui/scopes/declaration/fixture.mjs",
    "sha256": "f07cad393d22c4629c771ef7763de96b47d030b6730fbec222fd110da2b89cc5"
  },
  "expected": [
    "viewer cannot see Add",
    "tester can see Add"
  ],
  "observations": [
    {
      "path": "qa/ui/recordings/tester/events/action-34/response.json",
      "sha256": "7e455648f6895129f3f7c7d3f07258da10e300ae05ef971dfb8b658e05f09366"
    }
  ],
  "locators": {
    "query": "getByRole('textbox', { name: 'Query' })",
    "search": "getByRole('button', { name: 'Search' })",
    "reset": "getByRole('button', { name: 'Reset' })",
    "next": "getByRole('button', { name: 'Next' })",
    "previous": "getByRole('button', { name: 'Previous' })",
    "add": "getByRole('button', { name: 'Add' })",
    "cancel": "getByRole('button', { name: 'Cancel' })",
    "name": "getByRole('textbox', { name: 'Name' })",
    "save": "getByRole('button', { name: 'Save' })"
  },
  "gaps": [
    "viewer context not observed in tester scope"
  ]
}