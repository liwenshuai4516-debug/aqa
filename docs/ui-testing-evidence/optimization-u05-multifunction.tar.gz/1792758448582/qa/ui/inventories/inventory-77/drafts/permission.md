{
  "feature": "permission",
  "scenario": "permission-declared",
  "states": [
    "viewer Add hidden"
  ],
  "source": {
    "path": "qa/ui/scopes/declaration/fixture.mjs",
    "sha256": "f07cad393d22c4629c771ef7763de96b47d030b6730fbec222fd110da2b89cc5"
  },
  "expected": [
    "viewer cannot see Add",
    "tester can see Add"
  ],
  "observations": [
    {
      "path": "qa/ui/recordings/viewer/events/action-51/response.json",
      "sha256": "5de1294ddc5b910b926ccac0c88d0158bd46049163500459677873e6ee9d4aba"
    }
  ],
  "locators": {},
  "gaps": [
    "Tester observation remains in the original tester scope"
  ]
}