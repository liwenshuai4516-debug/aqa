{
  "feature": "paging",
  "scenario": "paging-declared",
  "states": [
    "first page",
    "last page",
    "previous boundary"
  ],
  "source": {
    "path": "qa/ui/scopes/declaration/fixture.mjs",
    "sha256": "f07cad393d22c4629c771ef7763de96b47d030b6730fbec222fd110da2b89cc5"
  },
  "expected": [
    "two rows per page",
    "next and previous retain query"
  ],
  "observations": [
    {
      "path": "qa/ui/recordings/tester/events/action-12/response.json",
      "sha256": "3879aa102fc15b18846853cda8988897677159111fdcb640cacf2964073ba4f8"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-15/response.json",
      "sha256": "4702aafafe241b8dd7de502329c4dfcc45a6b0bb1a667f7c9c372695dea30ff7"
    }
  ],
  "locators": {
    "query": "getByRole('textbox', { name: 'Query' })",
    "search": "getByRole('button', { name: 'Search' })",
    "reset": "getByRole('button', { name: 'Reset' })",
    "next": "getByRole('button', { name: 'Next' })",
    "previous": "getByRole('button', { name: 'Previous' })"
  },
  "gaps": [
    "Paging with an active query not observed"
  ]
}