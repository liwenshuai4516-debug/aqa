{
  "feature": "details",
  "scenario": "details-declared",
  "states": [
    "about selected",
    "details expanded"
  ],
  "source": {
    "path": "qa/ui/scopes/declaration/fixture.mjs",
    "sha256": "f07cad393d22c4629c771ef7763de96b47d030b6730fbec222fd110da2b89cc5"
  },
  "expected": [
    "tab selection changes panel",
    "details expansion changes visibility"
  ],
  "observations": [
    {
      "path": "qa/ui/recordings/tester/events/action-37/response.json",
      "sha256": "17058c358df12d501ffad67ef50e69fe6b1200e6fdd18fdfc53b282b96fc2fed"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-40/response.json",
      "sha256": "97997c008a47e87d24413e5615847aabb8f530ce87eee413db732cd997546d14"
    }
  ],
  "locators": {
    "query": "getByRole('textbox', { name: 'Query' })",
    "search": "getByRole('button', { name: 'Search' })",
    "reset": "getByRole('button', { name: 'Reset' })",
    "next": "getByRole('button', { name: 'Next' })",
    "previous": "getByRole('button', { name: 'Previous' })",
    "add": "getByRole('button', { name: 'Add' })",
    "cancel": "getByRole('button', { name: 'Cancel' })",
    "name": "getByRole('textbox', { name: 'Name' })",
    "save": "getByRole('button', { name: 'Save' })",
    "about": "getByRole('tab', { name: 'About' })",
    "details": "getByText('Details')"
  },
  "gaps": []
}