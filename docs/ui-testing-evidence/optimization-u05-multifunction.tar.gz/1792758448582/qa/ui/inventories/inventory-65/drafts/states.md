{
  "feature": "states",
  "scenario": "states-declared",
  "states": [
    "empty",
    "error"
  ],
  "source": {
    "path": "qa/ui/scopes/declaration/fixture.mjs",
    "sha256": "f07cad393d22c4629c771ef7763de96b47d030b6730fbec222fd110da2b89cc5"
  },
  "expected": [
    "loading precedes data",
    "no matches shows empty",
    "failure shows error"
  ],
  "observations": [
    {
      "path": "qa/ui/recordings/tester/events/action-45/response.json",
      "sha256": "7fe27caf52d5ab9b87050f4856db7678b265edd01331913f5da4deb2dc91a2cf"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-48/response.json",
      "sha256": "a091b4132140e8b2668af12a1810d304a13185f07ceeabfa7f36c33915fb792b"
    }
  ],
  "locators": {
    "query": "getByRole('textbox', { name: 'Query' })",
    "search": "getByRole('button', { name: 'Search' })",
    "reset": "getByRole('button', { name: 'Reset' })",
    "next": "getByRole('button', { name: 'Next' })",
    "previous": "getByRole('button', { name: 'Previous' })",
    "add": "getByRole('button', { name: 'Add' })",
    "cancel": "getByRole('button', { name: 'Cancel' })",
    "name": "getByRole('textbox', { name: 'Name' })",
    "save": "getByRole('button', { name: 'Save' })",
    "about": "getByRole('tab', { name: 'About' })",
    "details": "getByText('Details')",
    "list": "getByRole('tab', { name: 'List' })",
    "error": "getByRole('button', { name: 'Simulate error' })"
  },
  "gaps": [
    "Loading transition not observed by sequential MCP snapshots"
  ]
}