{
  "feature": "search",
  "scenario": "search-declared",
  "states": [
    "filtered",
    "reset"
  ],
  "source": {
    "path": "qa/ui/scopes/declaration/fixture.mjs",
    "sha256": "f07cad393d22c4629c771ef7763de96b47d030b6730fbec222fd110da2b89cc5"
  },
  "expected": [
    "query filters names",
    "reset restores first page"
  ],
  "observations": [
    {
      "path": "qa/ui/recordings/tester/events/action-1/response.json",
      "sha256": "3bfb90288772ae1173a4e68781cd15831f606bb8b8e690b33266a417bd21dd67"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-6/response.json",
      "sha256": "29d350165ee8572d2d8c11a4f3148d96c88c2bb27b9a2cfdadb6c1b8dfe875fc"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-9/response.json",
      "sha256": "518e6404ff103d182995f95c49c8fd439b9d761fb4417a97ba23b1f08ff509e6"
    }
  ],
  "locators": {
    "query": "getByRole('textbox', { name: 'Query' })",
    "search": "getByRole('button', { name: 'Search' })",
    "reset": "getByRole('button', { name: 'Reset' })"
  },
  "gaps": []
}