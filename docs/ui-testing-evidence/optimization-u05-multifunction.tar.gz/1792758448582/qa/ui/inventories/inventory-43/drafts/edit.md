{
  "feature": "edit",
  "scenario": "edit-declared",
  "states": [
    "dialog open",
    "cancel closes dialog",
    "saved",
    "persisted after reload"
  ],
  "source": {
    "path": "qa/ui/scopes/declaration/fixture.mjs",
    "sha256": "f07cad393d22c4629c771ef7763de96b47d030b6730fbec222fd110da2b89cc5"
  },
  "expected": [
    "dialog opens and cancels without writes",
    "saved name survives reload"
  ],
  "observations": [
    {
      "path": "qa/ui/recordings/tester/events/action-18/response.json",
      "sha256": "24ada491f6f4ade9e0615f2279418a9dd0b3ee6d490cf9f7093755e571555364"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-21/response.json",
      "sha256": "473b630e654b519315a00e819469c5117e4468d8112a6872d6e67c6531f576bc"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-23/response.json",
      "sha256": "73f6dee599360e73bd46c5b9a8fbc02dfcdcc2f5c8fa49a9afd8c8fa83f8164b"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-29/response.json",
      "sha256": "f2bc844fa70f17521e4570443c7ea830382a3a96372eab3a9d9920581c5466ed"
    },
    {
      "path": "qa/ui/recordings/tester/events/action-32/response.json",
      "sha256": "e70206161f66d39c086fd07eed287079c2c0e3f771bd9924be642673c73a5b2d"
    }
  ],
  "locators": {
    "query": "getByRole('textbox', { name: 'Query' })",
    "search": "getByRole('button', { name: 'Search' })",
    "reset": "getByRole('button', { name: 'Reset' })",
    "next": "getByRole('button', { name: 'Next' })",
    "previous": "getByRole('button', { name: 'Previous' })",
    "add": "getByRole('button', { name: 'Add' })",
    "cancel": "getByRole('button', { name: 'Cancel' })",
    "name": "getByRole('textbox', { name: 'Name' })",
    "save": "getByRole('button', { name: 'Save' })"
  },
  "gaps": [
    "Cancellation write side effects not independently inspected"
  ]
}