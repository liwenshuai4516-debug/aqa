// Owned synthetic harness only; generated extension receives these values as explicit arguments.
export const controls = { snapshot: null, beforePublication: null };
