from pathlib import Path
import hashlib,json,tarfile,io,os,shutil
repo=Path.cwd();root=repo/'tests/scratch/ui-recording-lifecycle';logs=repo/'tests/scratch/ui-optimization-u00';sha=lambda b:hashlib.sha256(b).hexdigest()
log_names={'baseline':'lifecycle-baseline-cancel-v2.log',**{n:'lifecycle-guarded-'+n+'.log' for n in ['complete','cancel','renew','close']}}
ids={n:Path(json.loads((logs/l).read_text())['output']).name for n,l in log_names.items()};results={n:json.loads((root/i/'result.json').read_text()) for n,i in ids.items()}
assert results['baseline']['publicDraftExists'] and results['baseline']['baselineLatePublicationReproduced'] and results['baseline']['recordingStatus']=='partial'
assert results['complete']['recordingStatus']=='complete' and results['complete']['publicScriptEqualsNative']
for n in ['cancel','renew','close']:
 r=results[n];assert not r['publicDraftExists'] and r['privateNativeDraftExists'] and r['recordingStatus']=='partial' and r['nativeWriterReplyObservedBeforeInterruption']
for r in results.values():
 assert r['modelCalls']==r['formalRuns']==r['businessWrites']==0 and r['ownedRawOutputsRemoved']
 assert all(not t['containsSyntheticSecret'] and t['mediaBlocks']==0 for t in r['tools'])
ledger=logs/'u05-authorized-review-budget.json';ledger_sha=sha(ledger.read_bytes());assert ledger_sha==json.loads((repo/'docs/ui-testing-evidence/optimization-u02-managed-recording.json').read_text())['modelReviewLedgerSha256']
verified=0
for d in root.iterdir():
 if not d.is_dir():continue
 (d/'.cleanup-keep').write_text('Retain native lifecycle failure/success evidence; no raw private payloads.\n')
 if (d/'seed.spec.ts').exists():
  (d/'tests').mkdir(exist_ok=True);(d/'tests/seed.spec.ts').write_bytes((d/'seed.spec.ts').read_bytes());(d/'package.json').write_bytes(b'{"type":"module"}')
 def walk(v):
  global verified
  if isinstance(v,dict):
   if isinstance(v.get('path'),str) and isinstance(v.get('sha256'),str):
    p=Path(v['path']);assert not p.is_absolute() and '..' not in p.parts;assert sha((d/p).read_bytes())==v['sha256'],str(d/p);verified+=1
   for x in v.values():walk(x)
  elif isinstance(v,list):
   for x in v:walk(x)
 for p in (d/'qa').rglob('*.json'):walk(json.loads(p.read_text()))
 if (d/'seed.spec.ts').exists():walk(json.loads((d/'result.json').read_text()))
text='''# 私密录制请求生命周期与晚到发布验证

2026-10-26，Electron权威项目“项目管理系统”后续工程证据。仅本机合成目标，模型调用、正式批次和业务写入均0。

旧私有副本原型存在可复现缺陷：在原生writer成功响应到达后、发布前取消实际ui_discover_record调用，SDK/原生记录为partial，但原型仍将原生草稿写入公开工作区。基线轮明确记录publicDraftExists=true，不能算安全发布。第一轮harness生成扩展的对象闭括号缺失，未启动录制即失败；保留失败摘要，修正harness后才获得完整基线，不改原生结果。

内部private-recording-workspace新增beginOperation(signal)：每次调用在验证副本/受管身份时绑定取消信号，返回assertActive、finish及publish。publish重验身份/输入/权限后再次同步核对有效状态，再执行同步独占文件写入；完成/拒绝均解绑监听器。取消或revoke立即使所有pending操作失效；revoke仍只删除派生认证、保留私有原生草稿。SDK正常完成请求也会abort其send信号，因此必须在交付正常响应前finish，避免误撤销正常会话。

隔离原型在真实createMcpExtension.createTransport接入此内部模块，传递真实SDK send options及signal，原始协议先保留私有。收到writer响应后测试钩子分别触发真实调用取消、父受管state变化、snapshot关闭，再尝试公开发布。三轮均publicDraftExists=false、privateNativeDraftExists=true，原生partial、0 script_refs，保留late-*-publication-blocked/missing-generated-script等缺口。取消轮保留原生cancelled步骤，不伪造业务失败。关闭轮是snapshot.revoke的逻辑关闭，未强行切断MCP子进程；真实断连/重连和进程关闭时序仍待验。

正常对照5步完整录制、原生complete、gaps为空、1脚本，公开草稿与原生文件字节相同；宿主引用和父state不变。公开已知秘密/编码/媒体检查通过，原始私有协议含合成值；测试结束清理本轮原始合成payload与自有进程，公开日志为减少内容后的证据，不代表完整原文。

完整typecheck通过，4个相关Vitest文件27项通过（模块11项，含正常SDK完成信号、预取消、晚取消/身份变化/校验中取消、旧snapshot与新snapshot隔离），lint/协议/size检查通过。原U05评审账本不变。

这是内部准备模块与隔离原型验证，产品mcp-extension尚未接入，数据空间record仍unsupported。通用输入闭包、新凭据/嵌套JSON、全部协议分支、真正断连/重连、竞态文件系统路径替换、Electron完整链和真实角色/租户/数据未证明。整计划继续进行中。项目文档以0700/0600落盘并回读；未建立应用文档列表索引。
'''
docdir=Path.home()/'Library/Application Support/Pi Agent Desktop/data/data-space/project-documents/e2f5d42d-2781-4e68-a452-4c87c7d1d346';store=docdir.parent.parent/'store.json';before=store.read_bytes();snapshot=docdir/('recording-lifecycle-'+ids['complete']);snapshot.mkdir(mode=0o700)
for n,i in ids.items():shutil.copytree(root/i,snapshot/n)
persisted=[]
for p in snapshot.rglob('*'):
 if p.is_dir():os.chmod(p,0o700)
 elif p.is_file():
  assert not p.is_symlink();os.chmod(p,0o600);n,*parts=p.relative_to(snapshot).parts;assert p.read_bytes()==(root/ids[n]/Path(*parts)).read_bytes();persisted.append({'path':str(p.relative_to(snapshot)),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size})
doc=docdir/'OperationContract-recording-lifecycle-2026-10-26.md'
with doc.open('x') as f:f.write(text)
os.chmod(doc,0o600);assert doc.read_text()==text and store.read_bytes()==before
files={}
for p in sorted(root.rglob('*')):
 if p.is_file():assert not p.is_symlink();files[str(p.relative_to(repo))]=p.read_bytes()
for n in ['probe-recording-lifecycle.mjs','lifecycle-recording-prototype.mjs','recording-lifecycle-control.mjs','archive-recording-lifecycle.py','lifecycle-unit.log','lifecycle-baseline-cancel.log',*log_names.values()]:
 p=logs/n;files[str(p.relative_to(repo))]=p.read_bytes()
for n in ['.pi/skills/ui-testing-workflow/assets/private-recording-workspace.mjs','tests/unit/ui-private-recording-workspace.test.ts']:files[n]=(repo/n).read_bytes()
archive=repo/'docs/ui-testing-evidence/optimization-u02-recording-lifecycle.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for n,b in sorted(files.items()):
  m=tarfile.TarInfo(n);m.size=len(b);m.mtime=0;t.addfile(m,io.BytesIO(b))
with tarfile.open(archive) as t:
 assert set(t.getnames())==set(files)
 for m in t:assert t.extractfile(m).read()==files[m.name]
index={'date':'2026-10-26','status':'BASELINE_LATE_PUBLICATION_REPRODUCED_THREE_LIFECYCLE_CONTROLS_BLOCKED_NORMAL_COMPLETE','plan_complete':False,'product_private_recording':'unsupported','modelCalls':0,'formalRuns':0,'modelReviewLedgerSha256':ledger_sha,'ledger_unchanged':True,'current_runs':{n:{'directory':str((root/i).relative_to(repo)),'result':results[n]} for n,i in ids.items()},'refsVerified':verified,'verification':{'typecheck':'passed, all five configs','vitest':'4 files 27 tests passed, module 11 tests','lint':'passed','protocol':'passed; tag heuristic unavailable','size':'passed'},'historical_harness_failure':'1792996532482: generated extension missing object brace; no recording; original summary/source retained','baselineSummaryCorrection':'Baseline run nativeDraftPublication generic summary wrongly says not-published-failure-preserved; authoritative publicDraftExists=true and baselineLatePublicationReproduced=true prove the defect. History retained. Guarded controls do not publish.','document':{'path':str(doc),'sha256':sha(doc.read_bytes()),'bytes':doc.stat().st_size,'storeUnchanged':True},'snapshot':{'path':str(snapshot),'files':persisted},'limits':['Internal module and isolated transport only; product not connected','Close control calls snapshot.revoke, not physical MCP disconnect','No generic closure/new secret/protocol/full filesystem race/reconnect/Electron proof','Raw synthetic payloads removed; public logs reduced'],'archive':{'path':str(archive.relative_to(repo)),'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'files':len(files),'roundtrip_verified':True},'files':[{'path':n,'sha256':sha(b),'bytes':len(b)} for n,b in sorted(files.items())]}
(repo/'docs/ui-testing-evidence/optimization-u02-recording-lifecycle.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'files':len(files),'refs':verified,'snapshotFiles':len(persisted),'bytes':archive.stat().st_size}))
