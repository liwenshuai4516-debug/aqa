# U02 录制配置层门禁阶段记录

环境：macOS arm64；原生 pi-ui-testing 0.1.14；目标 Playwright CLI；隔离 SDK/MCP 与 Electron。仅使用合成参数、临时数据目录与已有构建，模型调用、正式批次、真实业务写入均为 0。

修复前新增两种配置断言均失败（3 通过 / 2 失败）：内联 storageState、环境变量私有路径均获前置校验放行。没有执行 seed，不将这次配置放行称为已复现秘密泄露。

修复后通过公开 Reporter API 获取最小元数据，在既有 setup 执行钩子拒绝所选 project 的 storageState 及 contextOptions.storageState。覆盖继承配置、其他 project 不连带阻塞；不输出 use 原值、metadata 或错误原文，不读取私有状态文件。

实际 SDK 先由 data-space prepare-private(execute) 生成合成受管引用，再将该引用用于目标配置。调用真实 generator_setup_page 经 SDK 嵌套工具管线被拒绝，seed-executed 文件不存在。恢复匿名配置后真实 Chromium seed、snapshot、定位生成及点击通过，关闭成功。执行专用引用的普通正式执行路径未改动，本轮未重跑其业务测试。

相关 3 文件 12 项 Vitest、完整 5 配置类型检查、lint、协议同步、size 检查通过；协议 Git tag 启发式因无可用 tag 跳过。隔离 Electron 通过技能页与快捷发现、禁用/启用及重载持久、87 个直连 MCP 工具与重连检查；非真实 PMS 私密业务录制，不称当前个人应用已热更新。

同时修正维护文档的 0.1.14 来源提交与 SHA-256，和现有分发包/export manifest 实际核对；没有更新包或个人配置。

剩余边界：配置层检查不检测 test.use、自定义 fixture 或 seed 运行时认证注入；不解决收集与执行间配置竞态。内部私有输入副本、事件捕获与生命周期适配尚未连入产品录制入口。产品私密 record 仍 unsupported；整体 U02 与优化计划继续实施中。PMS 剩余 2 次设计评审额度保留，report-2 未结果批准。
