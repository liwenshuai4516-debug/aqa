from pathlib import Path
import hashlib,json,tarfile,io,os,shutil
repo=Path.cwd(); root=repo/'tests/scratch/ui-optimization-u00/recording-product-preflight'; sha=lambda b:hashlib.sha256(b).hexdigest()
previous=json.loads((repo/'docs/ui-testing-evidence/optimization-u02-recording-storage-boundaries.json').read_text())
ledgers={n:sha((root.parent/n).read_bytes()) for n in ['u05-authorized-review-budget.json','pms-anonymous-authorized-review-budget.json']}
assert ledgers==previous['ledgerSha256']
assert 'Tests  2 failed | 3 passed' in (root/'baseline.log').read_text()
assert 'Tests  12 passed' in (root/'unit.log').read_text()
assert '"status": "passed"' in (root/'integration.log').read_text()
desktop=json.loads((root/'desktop.log').read_text());assert desktop['status']=='PASS'
assert desktop['actualModelCalls']==desktop['businessRequests']==0
assert '87 tools' in desktop['mcpStatus']
files={str(p.relative_to(repo)):p.read_bytes() for p in root.iterdir() if p.is_file()}
for n in ['.pi/skills/ui-testing-workflow/assets/recording-preflight.mjs','.pi/skills/ui-testing-workflow/assets/recording-preflight-reporter.mjs','tests/unit/ui-recording-preflight.test.ts','tests/ui-testing-integration-test.mjs','.pi/skills/ui-testing-workflow/references/maintenance.md','docs/ui-testing-optimization-execution.md','docs/ui-testing-optimization-plan.md']:
 files[n]=(repo/n).read_bytes()
for p in Path(desktop['evidence']).rglob('*'):
 assert not p.is_symlink()
 if p.is_file():files[str(p.relative_to(repo))]=p.read_bytes()
archive=repo/'docs/ui-testing-evidence/optimization-u02-recording-product-preflight.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for n,b in sorted(files.items()):
  info=tarfile.TarInfo(n);info.size=len(b);info.mode=0o600;t.addfile(info,io.BytesIO(b))
with tarfile.open(archive,'r:gz') as t:
 for member in t.getmembers():assert t.extractfile(member).read()==files[member.name]
index={'schema_version':'1.0','stage':'U02 recording product configuration preflight','status':'partial-plan-in-progress','modelCalls':0,'formalRuns':0,'businessWrites':0,'baseline':{'passed':3,'failed':2,'meaning':'configuration admission only, no seed executed or leak claimed'},'unit':{'files':3,'passed':12},'sdk':'passed','electron':'PASS','ledgerSha256':ledgers,'archive':{'path':str(archive.relative_to(repo)),'sha256':sha(archive.read_bytes()),'files':len(files)},'files':{n:sha(b) for n,b in sorted(files.items())},'limits':['configuration only, runtime seed/test.use/fixture injection not covered','private product recording remains unsupported','no formal run or review approval','Electron document files saved without application list index']}
indexPath=archive.with_suffix('').with_suffix('.json');indexPath.write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
docroot=Path('/Users/liyingjun/Library/Application Support/Pi Agent Desktop/data/data-space/project-documents/e2f5d42d-2781-4e68-a452-4c87c7d1d346');store=docroot.parent.parent/'store.json';original=store.read_bytes()
stamp=Path(desktop['evidence']).name;dest=docroot/('recording-product-preflight-'+stamp);dest.mkdir(mode=0o700,exist_ok=True)
for p in [archive,indexPath,root/'stage.md']:
 target=dest/p.name
 with target.open('wb') as f:f.write(p.read_bytes())
 target.chmod(0o600);assert target.read_bytes()==p.read_bytes()
doc=docroot/'OperationContract-recording-product-preflight-2026-10-26.md'
with doc.open('w') as f:f.write((root/'stage.md').read_text()+'\n证据快照：'+dest.name+'。仅保存文件，未建立应用文档列表索引。\n')
doc.chmod(0o600);assert doc.read_text().startswith('# U02')
assert store.read_bytes()==original
print(json.dumps({'files':len(files),'archive':str(archive),'projectDocument':str(doc),'storeUnchanged':True,'ledgerUnchanged':True},ensure_ascii=False))
