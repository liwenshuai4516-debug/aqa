import json, hashlib, tarfile, io, shutil, subprocess
from pathlib import Path
repo=Path.cwd(); files={}; refs=0
sha=lambda b:hashlib.sha256(b).hexdigest()
def add(p):
 p=Path(p); assert p.is_file() and not p.is_symlink()
 name=str(p.relative_to(repo)); assert not set(name.split('/')) & {'node_modules','private-reviews','private-evidence','auth.json','models.json','agent'}
 files[name]=p.read_bytes()
def tree(p):
 for f in sorted(p.rglob('*')):
  if f.is_file(): add(f)
scenarios=[]
for run in ['1792986016140','1792986016109']:
 out=repo/'tests/scratch/ui-private-evidence'/run
 result=json.loads((out/'result.json').read_text()); assert result['status']=='PASS' and not result['leaks'] and len(result['checks'])==6
 assert result['formal']['failedCounts']['failed']==1
 assert result['formal']['passedEvidenceComplete'] is False and result['formal']['failedEvidenceComplete'] is False
 public=out/'public'; public.mkdir(exist_ok=True)
 if not (public/'qa').exists(): shutil.copytree(Path(result['workspace'])/'qa',public/'qa')
 def walk(value):
  global refs
  if isinstance(value,dict):
   if isinstance(value.get('path'),str) and isinstance(value.get('sha256'),str):
    rel=Path(value['path']); assert not rel.is_absolute() and '..' not in rel.parts
    f=public/rel
    if not f.exists():
     source=Path(result['workspace'])/rel
     assert rel==Path('requirements.md') and sha(source.read_bytes())==value['sha256']
     shutil.copyfile(source,f)
    assert f.is_file() and sha(f.read_bytes())==value['sha256'],str(f); refs+=1
   for v in value.values():walk(v)
  elif isinstance(value,list):
   for v in value:walk(v)
 for f in (public/'qa').rglob('*.json'):walk(json.loads(f.read_text()))
 tree(out);scenarios.append({'evidence':str(out.relative_to(repo)),'storage':result['authenticationStorage'],'checks':result['checks'],'formal':result['formal']})
assert scenarios[0]['formal']['rotatedCaptures']==0 and scenarios[1]['formal']['rotatedCaptures']==3
failed=repo/'tests/scratch/ui-private-evidence/1792985759460/result.json';assert json.loads(failed.read_text())['status']=='FAIL';add(failed)
# Preserve the reproduction receipt only, excluding the known-leaking synthetic workspace.
desktop=repo/'tests/scratch/ui-workflow-visibility/1792986015590';desktop_result=json.loads((desktop/'result.json').read_text());assert desktop_result['status']=='PASS' and len(desktop_result['checks'])==7;tree(desktop)
for f in (repo/'tests/scratch/ui-optimization-u00').glob('u02-json-storage-*'):
 if f.is_dir() and f.name.endswith('-source'):tree(f)
 elif f.is_file() and f.suffix=='.log':add(f)
for name in ['tests/ui-private-evidence-test.mjs','tests/scratch/ui-optimization-u00/archive-u02-json-storage.py']:
 add(repo/name)
ledger='tests/scratch/ui-optimization-u00/u05-authorized-review-budget.json'
prior=json.loads((repo/'docs/ui-testing-evidence/optimization-u06-pms-native-drafts.json').read_text())
assert sha((repo/ledger).read_bytes())==prior['modelReviewLedgerSha256']
package=repo/'.pi/skills/ui-testing-workflow/assets/pi-ui-testing-0.1.10.tgz'
with tarfile.open(package) as t:
 installed=0
 for m in t:
  if m.isfile():assert t.extractfile(m).read()==(repo/'node_modules/pi-ui-testing'/Path(m.name).relative_to('package')).read_bytes();installed+=1
assert installed==95
archive=repo/'docs/ui-testing-evidence/optimization-u02-json-storage.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for n,b in sorted(files.items()):
  m=tarfile.TarInfo(n);m.size=len(b);m.mtime=0;t.addfile(m,io.BytesIO(b))
with tarfile.open(archive) as t:
 assert set(t.getnames())==set(files)
 for m in t:assert t.extractfile(m).read()==files[m.name]
index={'date':'2026-10-26','status':'JSON_STORAGE_STRING_LEAVES_ISOLATED_FULL_U02_PENDING','plan_complete':False,'native_version':'0.1.10','upstream_commit':subprocess.check_output(['git','-C','/Users/liyingjun/Desktop/SW-QA/13-pi/agent-client','rev-parse','HEAD'],text=True).strip(),'upstream_pushed':False,'model_calls':0,'fee_ledger_unchanged':True,'real_business_requests':0,'review':'Controlled engineering fixture only; no independent model review or real PMS execution','reproduction':{'version':'0.1.9','native':'6 pass / 1 new failing test','browser':'positive/negative diagnostics ran; unredacted nested token detected during public trace verification','receipt':str(failed.relative_to(repo)),'leaking_workspace_archived':False},'scenarios':scenarios,'public_refs_verified':refs,'desktop':desktop_result,'validation':{'native':'14 passed / 3 files','upstream_check':'passed','host_typecheck':'passed','host_vitest':'20 passed / 3 files','sdk_mcp':'19 passed','desktop':'7 checks passed','lint':'passed','protocol':'structure passed; history skipped-no-tag','size':'passed','clean':'preview only'},'package':{'path':str(package.relative_to(repo)),'sha256':sha(package.read_bytes()),'installed_equal_files':installed},'limits':['One JSON parse per cookie/localStorage value; nested object/array string leaves only','No recursive JSON decoding inside string leaves, numeric/boolean credentials, arbitrary encodings or unknown business secrets','Recording MCP and generic Data Space private execution bridge remain unsupported','Passed/failed outcomes preserved with explicitly incomplete public media evidence','Real PMS role/data/diagnostics, U00 continuous baseline/pairs, M1/M2 still pending'],'archive':{'path':str(archive.relative_to(repo)),'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'files':len(files),'roundtrip_verified':True},'files':[{'path':n,'sha256':sha(b),'bytes':len(b)} for n,b in sorted(files.items())]}
(repo/'docs/ui-testing-evidence/optimization-u02-json-storage.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'files':len(files),'refs':refs,'bytes':archive.stat().st_size,'installed':installed}))
