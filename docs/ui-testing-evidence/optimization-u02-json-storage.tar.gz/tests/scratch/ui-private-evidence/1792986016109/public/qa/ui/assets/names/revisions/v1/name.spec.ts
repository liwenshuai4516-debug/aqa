import {test,expect} from 'playwright/test';

test('C1 Name persists',async({page})=>{
 const key='qa-'+crypto.randomUUID();await page.goto('/');
 const cookie=(await page.context().cookies()).find(c=>c.name==='qa_private');
 expect(cookie).toBeTruthy();
 console.log(cookie.value,encodeURIComponent(cookie.value),Buffer.from(cookie.value).toString('base64'));
 console.log(process.env.PI_UI_U02_CAPTURE_AUTH,encodeURI(process.env.PI_UI_U02_CAPTURE_AUTH));
 await page.evaluate(value=>{const p=document.createElement('p');p.textContent=value;document.body.appendChild(p);},cookie.value);
 await page.getByRole('textbox',{name:'Name'}).fill(key);
 await page.getByRole('button',{name:'Save'}).click();await page.reload();await page.evaluate(value=>{const p=document.createElement('p');p.textContent=value;document.body.appendChild(p);},cookie.value);
 await test.step('A1 Name persists after reload',async()=>{await expect(page.getByRole('listitem')).toHaveText([key]);});
});