// Real Electron/SDK/MCP dispatch with a local control provider. No independent model evidence.
import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { once } from 'node:events';
import { readFile, writeFile, mkdir, mkdtemp, symlink, realpath, cp, rm, readdir } from 'node:fs/promises';
import { homedir, tmpdir } from 'node:os';
import { join } from 'node:path';
import electron from 'electron';
import { ArtifactStore, RecordingService, sha256 } from 'pi-ui-testing';
import { enableUiTesting } from '../../../scripts/enable-ui-testing.mjs';
import { enableDataSpace } from '../../../scripts/enable-data-space.mjs';
import { launchNativeApp } from '../../desktop/native-app.mjs';
import { ensureBuild } from '../../lib/ensure-build.mjs';
import { portUp } from '../../lib/port-utils.mjs';
import { CHROME_PATH } from '../../lib/chrome.mjs';

assert.ok(process.argv.includes('--record-selected-readonly-business'));
assert.equal(process.env.PI_WEB_SMOKE_PREBUILT, '1');
const repo = process.cwd();
ensureBuild(repo, 'pms-electron-business-record');
const output = join(repo, 'tests/scratch/ui-pms-business-closure', String(Date.now()));
const runKey = output.split('/').at(-1);
await mkdir(output, { recursive: true });
await cp(new URL(import.meta.url), join(output, 'harness.mjs'));
const sourceStorePath = join(homedir(), 'Library/Application Support/Pi Agent Desktop/data/data-space/store.json');
const sourceBytes = await readFile(sourceStorePath), sourceStore = JSON.parse(sourceBytes);
const systemId = 'e2f5d42d-2781-4e68-a452-4c87c7d1d346', envId = 'f46a32da-2eac-43ca-86b8-2fa5eca5385c';
const selected = sourceStore.envs.find(e => e.id === envId && e.systemId === systemId);
assert.ok(selected);
const target = new URL('/pms/OperationContract', selected.baseUrl);
const continuationIndex = process.argv.indexOf('--continue-from');
const previous = continuationIndex < 0 ? undefined : JSON.parse(await readFile(join(process.argv[continuationIndex + 1], 'result.json'), 'utf8'));
assert.ok(!previous || (previous.formalRuns === 0 && previous.businessWrites === 0 && (previous.proxyReadRequests === 0 || (process.argv.includes('--retry-verified-readonly-setup') && previous.failure.includes('原生录制工具返回错误')))), 'Read-only setup retry requires explicit reconciliation; never resume intermediate business clicks');
const privateRoot = previous?.privateRoot ?? await realpath(await mkdtemp(join(tmpdir(), 'pms-electron-business-')));
const workspace = join(privateRoot, 'workspace'), agentDir = join(privateRoot, 'agent'), dataDir = join(privateRoot, 'data');
const previousStart = previous?.stages.find(s => s.tool === 'ui_discover_record' && s.operation === 'start');
const attempt = previousStart ? Number(previousStart.artifact_refs[0].path.match(/-r(\d+)\//)?.[1] ?? 1) + 1 : 1;
const recordingId = 'pms-business-readonly-20261027' + (attempt > 1 ? '-r' + attempt : '');
const seedPath = attempt > 1 ? `tests/seed-r${attempt}.spec.ts` : 'tests/seed.spec.ts';
const result = {
  status: 'blocked', systemId, envId, target: target.href, privateRoot, workspace,
  realModelCalls: 0, controlProviderCalls: 0, formalRuns: 0, businessWrites: 0,
  proxyReadRequests: 0, proxyRejectedRequests: 0, stages: [],
  limitations: ['Local dispatch provider does not establish real model planning or independent approval', 'Only query/reset; no contract creation/approval or server mutation', 'Raw business observations remain in the private local workspace'],
};
await writeFile(join(output, 'plan.json'), JSON.stringify(result, null, 2));
const store = new ArtifactStore(workspace);
const envelope = (kind, id, data) => ({ schema_version: '1.0', kind, id, created_at: new Date().toISOString(), data });
const faultServers=[];
let app, page, provider, proxy, pending, sequence = 0, recordingRef, inventoryRef, scopeRef;
const requests = [];
async function until(check, label, timeout = 180000) {
  const deadline = Date.now() + timeout;
  while (Date.now() < deadline) {
    if (await check()) return;
    await new Promise(resolve => setTimeout(resolve, 150));
  }
  throw new Error('Timed out: ' + label);
}
const decode = value => JSON.parse(value.content.filter(c => c.type === 'text').map(c => c.text).join('\n'));
async function native(tool, request) {
  const id = ++sequence;
  pending = { tool, args: { request }, id, reply: undefined, sent: false };
  await page.locator('.inputbox textarea').fill(`执行本轮已冻结的只读业务检查 ${id}，保留原生门禁与证据。`);
  await page.locator('.inputbox textarea').press('Enter');
  await until(() => page.locator('.messages').getByText('PMS_STAGE_DONE_' + runKey + '_' + id, { exact: true }).count(), tool);
  assert.ok(pending.reply, 'Missing native tool response');
  let reply = pending.reply;
  if(reply.errors?.some(e=>e.message.startsWith('Non-JSON'))){
    const sessions=join(agentDir,'sessions');
    for(const dir of await readdir(sessions,{withFileTypes:true}))if(dir.isDirectory())for(const name of await readdir(join(sessions,dir.name)))if(name.endsWith('.jsonl')){
      const lines=(await readFile(join(sessions,dir.name,name),'utf8')).split('\n').filter(Boolean);
      for(const line of lines){const entry=JSON.parse(line),m=entry.message;if(m?.role==='toolResult'&&m.toolCallId===`pms_native_${runKey}_${id}`){reply=JSON.parse(m.content.filter(c=>c.type==='text').map(c=>c.text).join('\n'));result.nativeTranscriptVerified=true;}}
    }
  }
  assert.equal(reply.status, 'completed', JSON.stringify({ tool, errors: reply.errors }));
  result.stages.push({ tool, operation: request.operation, status: reply.status, artifact_refs: reply.artifact_refs });
  await writeFile(join(output, 'progress.json'), JSON.stringify(result, null, 2));
  return reply;
}
try {
  for (const directory of [workspace, agentDir, dataDir, join(dataDir, 'data-space'), join(workspace, 'tests'), join(workspace, 'node_modules/@playwright')])
    await mkdir(directory, { recursive: true, mode: 0o700 });
  for (const name of previous ? [] : ['@playwright/test', 'playwright', 'playwright-core', 'pi-ui-testing'])
    await symlink(join(repo, 'tools/e2e/node_modules', name), join(workspace, 'node_modules', name), 'dir');
  await writeFile(join(workspace, 'package.json'), '{"type":"module"}');
  if (previousStart) {
    const prior = previousStart.artifact_refs[0];
    const path = 'qa/ui/inventories/pms-business-initial/manifest.json';
    const oldInventory = { path, sha256: sha256(await readFile(join(workspace, path))) };
    const manifest=prior.path.replace('/session.json','/manifest.json');
    try { result.priorPartialRef={path:manifest,sha256:sha256(await readFile(join(workspace,manifest)))}; }
    catch(error) { if(error.code!=='ENOENT')throw error; result.priorPartialRef=await new RecordingService(workspace).finish(prior,{inventory_ref:oldInventory,initial_state:previous.proxyReadRequests?'Prior read-only recording; response/writer failed':'No browser setup occurred',goal_reached:false,gaps:[previous.failure??'Prior initialization failed'],completion:{initial_state_rebuildable:true,replaceable_data:true,stable_locators:false,assertion_sources:true,cleanup_owned:false}}); }
  }
  proxy = createServer(async (request, response) => {
    const url = new URL(request.url, target.origin);
    if (url.origin !== target.origin || !['GET', 'HEAD'].includes(request.method)) {
      result.proxyRejectedRequests++;
      response.writeHead(403); response.end(); return;
    }
    result.proxyReadRequests++;
    const path = url.pathname;
    if (path.includes('operation-contract')) requests.push({ path, query: Object.fromEntries(url.searchParams), method: request.method });
    try {
      const headers = { ...request.headers }; delete headers['proxy-connection']; delete headers.connection;
      const upstream = await fetch(url, { method: request.method, headers, redirect: 'manual', signal: AbortSignal.timeout(20000) });
      const outgoing = Object.fromEntries(upstream.headers);
      delete outgoing['content-encoding']; delete outgoing['content-length']; delete outgoing['transfer-encoding'];
      response.writeHead(upstream.status, outgoing);
      if (upstream.body) for await (const chunk of upstream.body) response.write(chunk);
      response.end();
    } catch { response.writeHead(502); response.end(); }
  });
  proxy.on('connect', (_request, socket) => { result.proxyRejectedRequests++; socket.end('HTTP/1.1 403 Forbidden\r\n\r\n'); });
  const previousConfig = previous ? await readFile(join(workspace, 'playwright.config.mjs'), 'utf8') : '';
  const proxyPort = Number(previousConfig.match(/server:"http:\/\/127\.0\.0\.1:(\d+)"/)?.[1] ?? 0);
  proxy.listen(proxyPort, '127.0.0.1'); await once(proxy, 'listening');
  const proxyUrl = `http://127.0.0.1:${proxy.address().port}`;
  provider = createServer(async (request, response) => {
    let bytes = ''; for await (const chunk of request) bytes += chunk;
    result.controlProviderCalls++;
    const payload = JSON.parse(bytes);
    let delta, finish;
    if (!pending) { response.writeHead(409); response.end(); return; }
    if (!pending.sent) {
      assert.ok(payload.tools.some(t => t.function.name === pending.tool), 'Native tool not exposed: ' + pending.tool);
      pending.sent = true;
      delta = { tool_calls: [{ index: 0, id: `pms_native_${runKey}_${pending.id}`, type: 'function', function: { name: pending.tool, arguments: JSON.stringify(pending.args) } }] };
      finish = 'tool_calls';
    } else {
      const message = payload.messages.findLast(m => m.role === 'tool' && m.tool_call_id === `pms_native_${runKey}_${pending.id}`);
      const content = typeof message?.content === 'string' ? message.content : message?.content?.filter(b => b.type === 'text').map(b => b.text).join('\n');
      try { pending.reply = JSON.parse(content); } catch { pending.reply = { status: 'blocked', errors: [{ message: 'Non-JSON native response; retained in private session only' }] }; }
      delta = { content: 'PMS_STAGE_DONE_' + runKey + '_' + pending.id }; finish = 'stop';
    }
    response.writeHead(200, { 'content-type': 'text/event-stream' });
    for (const [d, reason] of [[delta, null], [{}, finish]])
      response.write(`data: ${JSON.stringify({ id: 'pms-local-dispatch', object: 'chat.completion.chunk', model: 'control', choices: [{ index: 0, delta: d, finish_reason: reason }] })}\n\n`);
    response.end('data: [DONE]\n\n');
  });
  provider.listen(0, '127.0.0.1'); await once(provider, 'listening');
  await writeFile(join(agentDir, 'auth.json'), '{"fixture":{"type":"api_key","key":"local-only"}}', { mode: 0o600 });
  await writeFile(join(agentDir, 'models.json'), JSON.stringify({ providers: { fixture: { api: 'openai-completions', apiKey: 'local-only', baseUrl: `http://127.0.0.1:${provider.address().port}`, models: [{ id: 'control', name: 'Local controlled tool dispatch', contextWindow: 200000, maxTokens: 256 }] } } }), { mode: 0o600 });
  await enableUiTesting(repo, agentDir); await enableDataSpace(repo, { agentDir, dataDir });
  await writeFile(join(dataDir, 'data-space/store.json'), JSON.stringify({ version: 3, revision: sourceStore.revision, systems: sourceStore.systems.filter(s => s.id === systemId), envs: [selected], modules: [], features: [], cases: [] }), { mode: 0o600 });
  await writeFile(join(dataDir, 'plugin-permissions.json'), JSON.stringify({ v: 1, grants: [{ pluginId: 'data-space', family: 'net', hosts: [target.hostname], reason: 'Selected PMS test environment refresh', grantedAt: Date.now() }] }), { mode: 0o600 });
  const config = `export default {testDir:'./tests',workers:1,timeout:30000,outputDir:process.env.PI_UI_PRIVATE_EVIDENCE_DIR+'/output/runner',use:{trace:'off',headless:true,baseURL:${JSON.stringify(target.origin)},proxy:{server:${JSON.stringify(proxyUrl)}},launchOptions:${JSON.stringify(CHROME_PATH ? { executablePath: CHROME_PATH } : {})}},projects:[{name:'chromium'}]};`;
  await writeFile(join(workspace, 'playwright.config.mjs'), config);
  const port = 18986; assert.equal(await portUp(port), false);
  const env = { ...process.env };
  for (const key of Object.keys(env)) if (/(API_KEY|AUTH_TOKEN|ACCESS_TOKEN|SECRET_ACCESS_KEY|SESSION_TOKEN)$/.test(key) || /^(AWS_|GOOGLE_|GCLOUD_|AZURE_|PI_)/.test(key) || ['ELECTRON_RUN_AS_NODE', 'NODE_OPTIONS'].includes(key)) delete env[key];
  Object.assign(env, { PI_DESKTOP_USER_DATA: join(privateRoot, 'ui'), PI_CODING_AGENT_DIR: agentDir, PI_WEB_DATA_DIR: dataDir, PI_WEB_CWD: workspace, PI_WEB_PORT: String(port), PI_WEB_PLUGIN_CATALOG_URL: 'off', PI_WEB_SDK: 'bundled', PI_WEB_TOOL_LAZY_LOADING: '0' });
  app = await launchNativeApp({ executablePath: electron, packaged: false, env });
  page = await app.firstWindow(); await page.waitForSelector('.app');
  await app.context().addInitScript(() => {
    const Original = window.WebSocket;
    window.__pmsMessages = [];
    window.WebSocket = class extends Original { constructor(...args) { super(...args); window.__pmsSocket = this; this.addEventListener('message', e => { try { window.__pmsMessages.push(JSON.parse(e.data)); } catch {} }); } };
  });
  await page.reload();
  await until(() => page.evaluate(() => window.__pmsMessages.some(m => m.type === 'ready')), 'desktop ready');
  const close = page.locator('.setup-modal .modal-close'); if (await close.isVisible()) await close.click();
  await page.evaluate(() => window.__pmsSocket.send(JSON.stringify({ type: 'set_model', modelId: 'fixture/control' })));
  await until(() => page.evaluate(() => window.__pmsMessages.some(m => m.state?.model?.id === 'control')), 'local model selection');
  const mcpStatus = async () => {
    const after = await page.evaluate(() => window.__pmsMessages.length);
    await page.locator('.inputbox textarea').fill('/mcp');
    await page.locator('.inputbox textarea').press('Escape');
    await page.locator('button.btn.send').click();
    await until(() => page.evaluate(after => window.__pmsMessages.slice(after).some(m => m.type === 'notice' && m.text?.includes('ui-playwright-test:')), after), 'MCP status');
    return page.evaluate(after => window.__pmsMessages.slice(after).find(m => m.type === 'notice' && m.text?.includes('ui-playwright-test:')).text, after);
  };
  await until(async () => { result.initialMcpStatus = await mcpStatus(); return /ui-playwright-test: connected, \d+ tools/.test(result.initialMcpStatus); }, 'initial MCP connected', 45000);
  const plugin = (path, body) => page.evaluate(async ({ path, body }) => {
    const response = await fetch('/plugins-api/data-space' + path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    const value = await response.json(); if (!response.ok) throw new Error('Selected plugin operation rejected'); return value;
  }, { path, body });
  const refreshed = await plugin('/env/refresh', { envId, force: true });
  assert.equal(refreshed.scriptRun.ok, true); result.desktopRefreshPassed = true;
  const initialized = await plugin('/automation', { action: 'initialize', engine: 'ui', mode: 'execute', targetUrl: target.href, envId, workspace });
  assert.equal(initialized.status, 'configured');
  const managed = await plugin('/automation', { action: 'prepare-private', engine: 'ui', mode: 'execute', workspace, systemId, envId, targetUrl: target.href, privateBindings: [{ parameterKey: 'token', storageKey: 'token' }] });
  assert.equal(managed.status, 'prepared-private-execution');
  result.desktopReferencePrepared = true;
  const prepared=JSON.parse(await readFile(join(repo,'tests/scratch/ui-pms-business-closure/1793070111624/result.json')));
  const ledger=JSON.parse(await readFile(join(repo,'tests/scratch/ui-pms-business-closure/authorized-review-budget.json')));
  const nativeDesign=ledger.native_attempts.findLast(a=>a.purpose==='design'&&a.status==='completed');
  const reviewRef=nativeDesign.artifact_refs[0],review=await store.load(reviewRef);
  assert.equal(review.data.decision,'approved');assert.equal(review.data.subject_ref.sha256,prepared.assetRef.sha256);
  result.designReviewRef=reviewRef;
  const {pathToFileURL}=await import('node:url');
  const {startFaultServer}=await import(pathToFileURL(join(workspace,'qa/ui/assets/pms-contract-query-reset/revisions/v8/fault-server.mjs')));
  const spec=JSON.parse(await readFile(join(workspace,prepared.specRef.path)));
  for(const probe of spec.probes){const env=JSON.parse(await readFile(join(workspace,probe.environment_ref.path)));faultServers.push(await startFaultServer(probe.id,Number(new URL(env.base_url).port)));}
  const diagnostic=await native('ui_design_diagnose',{operation:'diagnose',asset_ref:prepared.assetRef,review_ref:reviewRef,spec_ref:prepared.specRef,request_id:'pms-business-diagnostic-1'});
  assert.equal(diagnostic.output.runtime_ready,true);result.diagnosticRef=diagnostic.artifact_refs[0];
  const taskPath='qa/ui/tasks/pms-business-readonly-20261027/manifest.json';
  const taskRef={path:taskPath,sha256:sha256(await readFile(join(workspace,taskPath)))};
  const designed=await native('ui_test_workflow',{operation:'checkpoint',task_ref:taskRef,stage:'design-review',output_refs:[prepared.assetRef,reviewRef]});
  result.designTaskRef=designed.artifact_refs[0];
  const execution=await native('ui_test_workflow',{operation:'start',input:{task_id:'pms-business-readonly-execute-20261027',mode:'execute',scope_ref:prepared.scopeRef,asset_ref:prepared.assetRef}});
  const run=await native('ui_test_run',{operation:'start',input:{task_id:'pms-business-readonly-execute-20261027',request_id:'pms-business-formal-1',asset_ref:prepared.assetRef,review_ref:reviewRef,environment_ref:prepared.environmentRef,config_ref:prepared.configRef,timeout_ms:120000}});
  result.formalRuns=1;result.runRef=run.artifact_refs[0];
  const currentExec={path:execution.artifact_refs[0].path,sha256:sha256(await readFile(join(workspace,execution.artifact_refs[0].path)))};
  const executed=await native('ui_test_workflow',{operation:'checkpoint',task_ref:currentExec,stage:'execute',output_refs:[result.runRef]});
  const parsed=await native('ui_result_analysis',{operation:'parse',run_ref:result.runRef,result_id:'pms-business-formal-1-results'});
  result.resultsRef=parsed.artifact_refs[0];const results=await store.load(result.resultsRef);result.counts=results.data.counts;
  const findings=results.data.instances.filter(i=>i.status!=='passed').map(i=>({instance_id:i.instance_id,classification:'insufficient-evidence',certainty:'unknown',facts:['Native instance status: '+i.status,...i.attempts.flatMap(a=>a.errors)],hypotheses:[],supporting_refs:i.attempts.flatMap(a=>a.evidence_refs),alternatives:['No server-side root cause established'],next_action:'Inspect this attempt and repair only supported causes before a separate approved rerun'}));
  const analysis=await native('ui_result_analysis',{operation:'save-analysis',analysis:envelope('analysis','pms-business-formal-1-analysis',{run_ref:result.runRef,results_ref:result.resultsRef,findings})});
  result.analysisRef=analysis.artifact_refs[0];
  const report=await native('ui_result_analysis',{operation:'draft-report',results_ref:result.resultsRef,analysis_ref:result.analysisRef,report_id:'pms-business-formal-1-report'});
  result.reportRef=report.artifact_refs[0];
  const analyzed=await native('ui_test_workflow',{operation:'checkpoint',task_ref:executed.artifact_refs[0],stage:'analyze',output_refs:[result.reportRef]});result.executionTaskRef=analyzed.artifact_refs[0];
  result.assetRef=prepared.assetRef;result.casesRef=prepared.casesRef;
  result.status='ELECTRON_REAL_PMS_FORMAL_COMPLETE_REPORT_UNREVIEWED';
  await plugin('/automation',{action:'disconnect',engine:'ui',workspace,envId});
} catch (error) {
  result.blockedAt = result.stages.at(-1)?.operation ?? 'desktop-setup';
  result.failure = String(error.message).slice(0, 1200);
  process.exitCode = 1;
} finally {
  for(const server of faultServers){server.closeAllConnections();await new Promise(ok=>server.close(ok));}
  if (app) { await writeFile(join(privateRoot, 'desktop.log'), app.getLogs(), { mode: 0o600 }); await app.close(); }
  provider?.closeAllConnections(); if (provider) await new Promise(resolve => provider.close(resolve));
  proxy?.closeAllConnections(); if (proxy) await new Promise(resolve => proxy.close(resolve));
  // Retain the private workspace and raw failures for explicit continuation; never publish business rows.
  result.originalStoreUnchanged = sourceBytes.equals(await readFile(sourceStorePath));
  await writeFile(join(output, 'result.json'), JSON.stringify(result, null, 2));
  console.log(JSON.stringify({ output, ...result }, null, 2));
  assert.equal(result.originalStoreUnchanged, true);
}
