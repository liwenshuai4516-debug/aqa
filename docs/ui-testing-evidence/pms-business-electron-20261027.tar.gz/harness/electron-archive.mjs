/** Connect the actual selected Data Space through Electron's normal authenticated renderer.
 * Temporary UI/agent profile; selected Data Space remains at its real location. No model calls.
 */
import assert from "node:assert/strict";
import { readFile, writeFile, mkdir, cp, readdir, lstat, access, mkdtemp, rm } from "node:fs/promises";
import { join } from "node:path";
import { homedir, tmpdir } from "node:os";
import { fileURLToPath } from "node:url";
import electron from "electron";
import { sha256, ArtifactStore } from "pi-ui-testing";
import { ensureBuild } from "../../lib/ensure-build.mjs";
import { portUp } from "../../lib/port-utils.mjs";
import { launchNativeApp } from "../../desktop/native-app.mjs";

assert.ok(process.argv.includes("--connect-selected-data"), "Explicit selected-data connection required");
assert.equal(process.env.PI_WEB_SMOKE_PREBUILT, "1", "Never rebuild inside this entry");
const repo = fileURLToPath(new URL("../../..", import.meta.url));
ensureBuild(repo, "pms-desktop-connection");
const output = join(repo, "tests/scratch/ui-pms-business-closure", String(Date.now()));
await mkdir(output, { recursive: true });
await cp(fileURLToPath(import.meta.url), join(output, "harness.mjs"));
const intakeIndex = process.argv.indexOf("--archive-business-result");
const intake = intakeIndex < 0 ? undefined : JSON.parse(await readFile(process.argv[intakeIndex + 1], "utf8"));
assert.ok(intake, 'Frozen business run required');
intake.root = intake.workspace;
assert.equal(intake.status, 'ELECTRON_REAL_PMS_FORMAL_COMPLETE_REPORT_UNREVIEWED');
assert.equal((await new ArtifactStore(intake.root).load(intake.assetRef)).data.revision, 'v8');
const dataDir = join(homedir(), "Library/Application Support/Pi Agent Desktop/data");
const storePath = join(dataDir, "data-space/store.json"),
	before = await readFile(storePath);
// A new UI profile must not resume unrelated tasks from the selected data directory.
await assert.rejects(access(join(dataDir, "scheduler-tasks.json")), { code: "ENOENT" });
const pluginVersions = [];
for (const id of await readdir(join(dataDir, "plugins"))) {
	const directory = join(dataDir, "plugins", id);
	let source, installed;
	try {
		source = JSON.parse(await readFile(join(repo, "plugins", id, "manifest.json")));
		installed = JSON.parse(await readFile(join(directory, "manifest.json")));
	} catch {
		throw new Error("Plugin manifests require explicit reconciliation");
	}
	const linked = (await lstat(directory)).isSymbolicLink();
	assert.ok(
		linked || source.version.localeCompare(installed.version, undefined, { numeric: true }) <= 0,
		"Preserve installed plugin versions",
	);
	try {
		const schedule = JSON.parse(await readFile(join(directory, "schedules.json")));
		assert.equal(
			Array.isArray(schedule) ? schedule.length : (schedule.tasks ?? schedule.schedules ?? []).length,
			0,
			"Do not start saved plugin schedules",
		);
	} catch (error) {
		if (error.code !== "ENOENT") throw error;
	}
	pluginVersions.push({ id, installed: installed.version, source: source.version, linked });
}
const port = 18979;
assert.equal(await portUp(port), false, "Preserve existing listener");
const privateProfile = await mkdtemp(join(tmpdir(), "pms-native-private-"));
const env = { ...process.env };
for (const key of Object.keys(env))
	if (
		/(API_KEY|AUTH_TOKEN|ACCESS_TOKEN|SECRET_ACCESS_KEY|SESSION_TOKEN)$/.test(key) ||
		/^(AWS_|GOOGLE_|GCLOUD_|AZURE_|PI_)/.test(key) ||
		["ELECTRON_RUN_AS_NODE", "NODE_OPTIONS"].includes(key)
	)
		delete env[key];
Object.assign(env, {
	PI_DESKTOP_USER_DATA: join(privateProfile, "ui-profile"),
	PI_CODING_AGENT_DIR: join(privateProfile, "agent"),
	PI_WEB_DATA_DIR: dataDir,
	PI_WEB_CWD: intake?.root ?? repo,
	PI_WEB_PORT: String(port),
	PI_WEB_PLUGIN_CATALOG_URL: "off",
	PI_WEB_SDK: "bundled",
});
const result = {
	status: "blocked",
	modelCalls: 0,
	nativeCaseImports: 0,
	selectedStoreModified: false,
	pluginVersions,
	actualDataDirectory: dataDir,
	temporaryUiAgentProfile: true,
	prebuiltServerSha256: sha256(await readFile(join(repo, "dist/server/index.js"))),
	prebuiltDesktopSha256: sha256(await readFile(join(repo, "dist/desktop/main.js"))),
};
await writeFile(join(output, "plan.json"), JSON.stringify(result, null, 2));
let app;
const beforeEnvs = sha256(JSON.stringify(JSON.parse(before).envs));
try {
	app = await launchNativeApp({ executablePath: electron, packaged: false, env });
	const page = await app.firstWindow();
	await page.waitForLoadState("domcontentloaded");

	result.nativeReadAttempts = [];
	for (let attempt = 0; attempt < 20; attempt++) {
		try {
			result.nativeState = await page.evaluate(async () => {
				const response = await fetch("/plugins-api/data-space/state", { credentials: "same-origin" });
				if (!response.ok || !response.headers.get("content-type")?.includes("application/json"))
					return {
						httpStatus: response.status,
						jsonResponse: response.headers.get("content-type")?.includes("application/json") ?? false,
						selectedProjectMatched: false,
					};
				const data = await response.json();
				const project = data.systems?.find((p) => p.id === "e2f5d42d-2781-4e68-a452-4c87c7d1d346");
				const environment = data.envs?.find(
					(e) => e.id === "f46a32da-2eac-43ca-86b8-2fa5eca5385c" && e.systemId === project?.id,
				);
				const moduleIds = new Set((data.modules ?? []).filter((m) => m.systemId === project?.id).map((m) => m.id));
				const featureIds = new Set((data.features ?? []).filter((f) => moduleIds.has(f.moduleId)).map((f) => f.id));
				return {
					httpStatus: response.status,
					ok: data.ok,
					selectedProjectMatched: project?.name === "项目管理系统",
					selectedEnvironmentMatched: !!environment,
					revision: data.revision,
					modules: moduleIds.size,
					features: featureIds.size,
					cases: (data.cases ?? []).filter((x) => featureIds.has(x.featureId)).length,
				};
			});
			result.nativeReadAttempts.push({ httpStatus: result.nativeState.httpStatus });
			if (result.nativeState.httpStatus === 200 && result.nativeState.selectedProjectMatched) break;
		} catch (error) {
			if (!/Execution context was destroyed|navigation/i.test(error.message)) throw error;
			result.nativeReadAttempts.push({ state: "renderer-navigation" });
		}
		await new Promise((resolve) => setTimeout(resolve, 250));
	}
	result.status =
		result.nativeState?.httpStatus === 200 &&
		result.nativeState.selectedProjectMatched &&
		result.nativeState.selectedEnvironmentMatched
			? "selected-desktop-native-connection-verified"
			: "native-connection-blocked";
	if (
		process.argv.includes("--probe-private-execution") &&
		result.status === "selected-desktop-native-connection-verified"
	) {
		assert.equal(intake, undefined);
		result.privateExecutionBoundary = await page.evaluate(async (workspace) => {
			const response = await fetch("/plugins-api/data-space/automation", {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({
					action: "prepare-private",
					engine: "ui",
					mode: "record",
					workspace,
					systemId: "e2f5d42d-2781-4e68-a452-4c87c7d1d346",
					envId: "f46a32da-2eac-43ca-86b8-2fa5eca5385c",
					targetUrl: "http://192.168.90.224:8238/pms/OperationContract",
					privateBindings: [{ parameterKey: "token", storageKey: "token" }],
				}),
			});
			const body = await response.json();
			return {
				httpStatus: response.status,
				installedPrivateRecordingRejected: body.ok === false && String(body.error).includes("私密浏览器准备未就绪"),
			};
		}, repo);
		assert.equal(result.privateExecutionBoundary.httpStatus, 400);
		assert.equal(result.privateExecutionBoundary.installedPrivateRecordingRejected, true);
	}
	assert.equal(result.status, 'selected-desktop-native-connection-verified');
	const call = async (path, body) => page.evaluate(async ({path,body})=>{
		const response=await fetch('/plugins-api/data-space'+path, body?{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}:{});
		const data=await response.json(); if(!response.ok)throw new Error(JSON.stringify({path,error:data.error}));return data;
	},{path,body});
	const systemId='e2f5d42d-2781-4e68-a452-4c87c7d1d346',envId='f46a32da-2eac-43ca-86b8-2fa5eca5385c';
	const automation = args=>call('/automation',{workspace:intake.root,engine:'ui',...args});
	const inspected=await automation({action:'inspect',assetRef:intake.assetRef});
	assert.equal(inspected.executable,true);assert.equal(inspected.cases.length,2);
	assert.ok(inspected.cases.every(c=>c.moduleId==='operation-contract'&&c.featureId==='query-reset'));
	let state=await call('/state');
	const module=state.modules.find(m=>m.id==='pms-contract-source-module'&&m.systemId===systemId);assert.ok(module);
	const featureId='pms-business-query-reset';
	if(!state.features.some(f=>f.id===featureId))await call('/save',{...state,baseRevision:state.revision,features:[...state.features,{id:featureId,moduleId:module.id,name:'合同查询与重置',note:'真实只读查询/重置；不覆盖发起审批、跨角色或租户'}]});
	state=await call('/state');
	assert.ok(state.features.some(f=>f.id===featureId&&f.moduleId===module.id));
	const args={assetRef:intake.assetRef,envId,featureMappings:[{nativeModuleId:'operation-contract',nativeFeatureId:'query-reset',featureId}]};
	result.beforeArchive=await automation({action:'archive-status',...args});
	result.imported=await automation({action:'import',...args});
	result.afterArchive=await automation({action:'archive-status',...args});
	assert.equal(result.afterArchive.classificationComplete,true);assert.equal(result.afterArchive.total,2);
	state=await call('/state');const rows=state.cases.filter(c=>c.nativeSource?.assetRef?.sha256===intake.assetRef.sha256&&c.nativeSource.envId===envId);assert.equal(rows.length,2);
	result.bindings=[];for(const row of rows)result.bindings.push(await automation({action:'bind',caseId:row.id,assetRef:intake.assetRef,nativeCaseId:row.nativeSource.nativeCaseId,envId}));
	result.synced=await automation({action:'sync',runRef:intake.runRef});
	result.syncStatus=await automation({action:'sync-status',runRef:intake.runRef});
	assert.equal(result.syncStatus.complete,true);assert.equal(result.syncStatus.nativeCaseCount,2);
	result.duplicateImport=await automation({action:'import',...args});assert.equal(result.duplicateImport.imported,0);assert.equal(result.duplicateImport.duplicate,2);
	result.duplicateSync=await automation({action:'sync',runRef:intake.runRef});assert.equal(result.duplicateSync.complete,true);
	result.finalSyncStatus=await automation({action:'sync-status',runRef:intake.runRef});
	state=await call('/state');result.nativeCaseImports=result.imported.imported;
	result.caseRows=state.cases.filter(c=>rows.some(r=>r.id===c.id)).map(c=>({id:c.id,code:c.code,title:c.title,featureId:c.featureId,status:c.status,nativeSource:c.nativeSource,automation:c.automation}));
	assert.ok(result.caseRows.every(c=>c.automation?.assetRef.sha256===intake.assetRef.sha256&&c.automation.envId===envId));
	const close=page.locator('.setup-modal .modal-close');if(await close.isVisible())await close.click();
	await page.locator('header button, .topbar button, nav button').filter({hasText:'数据空间'}).first().click();
	await page.locator('.dsp-nav button[data-tab="cases"]').click();
	for(const row of result.caseRows)await page.locator('.case-table tbody tr').filter({hasText:row.title}).waitFor({state:'visible'});
	result.visibleBusinessCases=2;await page.screenshot({path:join(output,'cases.png')});
	result.status='ELECTRON_SELECTED_PMS_CASES_BOUND_AND_NATIVE_RUN_SYNCED';
} catch (error) {
	result.failure=String(error.message).slice(0,900);
	result.errorCategory = /Execution context was destroyed|navigation/i.test(error.message)
		? "renderer-navigation"
		: /closed|disposed/i.test(error.message)
			? "renderer-closed"
			: /Timeout/i.test(error.message)
				? "readiness-timeout"
				: /JSON|Unexpected token/i.test(error.message)
					? "response-not-json"
					: "other-runtime-error";
	result.runtimeDiagnostic = app
		? Object.fromEntries(
				[
					"Cannot find module",
					"ERR_MODULE_NOT_FOUND",
					"EADDRINUSE",
					"Failed to load",
					"401",
					"permission denied",
					"window loaded",
				].map((marker) => [marker, app.getLogs().includes(marker)]),
			)
		: undefined;
	result.blocker = "native-app-or-authenticated-renderer-unavailable";
} finally {
	if (app) {
		await app.close();
		result.ownedAppClosed = true;
	}
	await rm(privateProfile, { recursive: true, force: true });
	result.privateProfileRemoved = true;
	const after = await readFile(storePath);
	result.selectedStoreModified = sha256(before) !== sha256(after);
	result.environmentsUnchanged = beforeEnvs === sha256(JSON.stringify(JSON.parse(after).envs));
	await writeFile(join(output, "result.json"), JSON.stringify(result, null, 2));
}
console.log(JSON.stringify({ output, ...result }, null, 2));
assert.equal(result.environmentsUnchanged, true, "Environment changes require reconciliation");
if (!intake) assert.equal(result.selectedStoreModified, false, "Reconcile changes before any selected-store write");
assert.equal(result.status,'ELECTRON_SELECTED_PMS_CASES_BOUND_AND_NATIVE_RUN_SYNCED');
