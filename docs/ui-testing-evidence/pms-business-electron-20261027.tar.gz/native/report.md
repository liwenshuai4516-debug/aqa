# UI 测试结果

范围：Record real PMS contract query/reset in Electron without server mutations

批次：run-c55f8ba697f6ccf99d346e7d238f9ba7；部署：public-bundle-25c2aa0930810ec4；角色：selected-account-readonly-contract-query

冻结计划：2；实际启动：2；稳定通过率：100.00%

| 状态 | 实例数 |
|---|---:|
| passed | 2 |
| failed | 0 |
| blocked | 0 |
| skipped | 0 |
| cancelled | 0 |
| not-run | 0 |
| flaky | 0 |
| unknown | 0 |

原始结果：[qa/ui/runs/run-c55f8ba697f6ccf99d346e7d238f9ba7/report.json](../../report.json)

确定性对账与证据状态：[qa/ui/runs/run-c55f8ba697f6ccf99d346e7d238f9ba7/results/pms-business-formal-1-results/reconciliation.json](../../results/pms-business-formal-1-results/reconciliation.json)

设计评估（仅本批次资产修订）：候选用例 2；通过 2；待修订 0；阻塞 0；结论 approved。

已登记功能清单：1；清单内尚无用例的功能点：无。

未探索范围（不计入上述清单分母）：Contract creation/approval；Other roles；Existing draft/state source cases。

功能覆盖：冻结用例涉及 1 个功能点，其中 1 个获得执行结论；不代表全产品覆盖。

## 模块、功能与优先级统计

```json
{
  "by_module": {
    "operation-contract": {
      "passed": 2,
      "failed": 0,
      "blocked": 0,
      "skipped": 0,
      "cancelled": 0,
      "not-run": 0,
      "flaky": 0,
      "unknown": 0
    }
  },
  "by_feature": {
    "operation-contract/query-reset": {
      "passed": 2,
      "failed": 0,
      "blocked": 0,
      "skipped": 0,
      "cancelled": 0,
      "not-run": 0,
      "flaky": 0,
      "unknown": 0
    }
  },
  "by_priority": {
    "P0": {
      "passed": 2,
      "failed": 0,
      "blocked": 0,
      "skipped": 0,
      "cancelled": 0,
      "not-run": 0,
      "flaky": 0,
      "unknown": 0
    }
  },
  "by_oracle": {
    "requirement": [],
    "declaration": [
      "instance-c347b6a62af4834d2d307ae87bb91670",
      "instance-9cacc3865290e0134ac6933199080c3f"
    ],
    "baseline": [
      "instance-c347b6a62af4834d2d307ae87bb91670",
      "instance-9cacc3865290e0134ac6933199080c3f"
    ]
  }
}
```

## 观察、解释与下一动作

## 数据清理与残留

```json
[
  {
    "instance_id": "instance-c347b6a62af4834d2d307ae87bb91670",
    "cleanup": [
      {
        "namespace": "qa-c39f5bb2-040c-407f-b8d2-6e4825758775",
        "records": [],
        "residual": []
      }
    ],
    "evidence_gaps": [
      "认证执行的公开证据已脱敏，图片或二进制资源仅保留在私有目录"
    ]
  },
  {
    "instance_id": "instance-9cacc3865290e0134ac6933199080c3f",
    "cleanup": [
      {
        "namespace": "qa-12008cf8-8822-429a-bbbd-bb1f317515c9",
        "records": [],
        "residual": []
      }
    ],
    "evidence_gaps": [
      "认证执行的公开证据已脱敏，图片或二进制资源仅保留在私有目录"
    ]
  }
]
```

## 限制与待处理事项

- 范围仅限冻结计划，不代表全产品或代码覆盖率；attempt 与 case 分开统计
- 候选与设计评估数量仅统计本批次资产修订；不推断其他候选或历史轮次。未登记的信息为不可用，不填零
- 未探索：Contract creation/approval
- 未探索：Other roles
- 未探索：Existing draft/state source cases
- HTTP 2xx is transport only, not proof of response body or row filtering
- Contract initiation/approval and cross-role/tenant permissions remain outside this limited candidate
- Independent review and all frozen diagnostics remain unexecuted
- Product token-only recording does not establish selected tenant; no tenant isolation or cross-tenant claim.
- HTTP 2xx is transport only, not proof of response body or row filtering
- Contract initiation/approval and cross-role/tenant permissions remain outside this limited candidate
- Independent review and all frozen diagnostics remain unexecuted
- Complete native Electron recording r6 is linked; independent review/diagnostics/formal results remain pending.
- R3: 公开证据不包含全部原始私密附件，不能声明完整视觉证据
- R3: 该实例证据存在缺口，状态和证据完整性分别记录
- R3: 公开证据不包含全部原始私密附件，不能声明完整视觉证据
- R3: 该实例证据存在缺口，状态和证据完整性分别记录

失败处理：产品问题仅形成待确认缺陷草稿；脚本问题新建修订并重审；环境/数据恢复后新批次执行；证据不足先补证据，不修改历史结果。

后续处理草稿：[缺陷与回归建议](follow-up.json)；未向外部系统提交。
