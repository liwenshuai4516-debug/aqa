/** Synthetic privacy reproduction through the actual SDK nested MCP pipeline. Never uses real identity or model. */
import assert from 'node:assert/strict';
import {randomBytes} from 'node:crypto';
import {createServer} from 'node:http';
import {readFile,writeFile,mkdir,mkdtemp,rm,readdir,realpath,symlink,cp} from 'node:fs/promises';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
import {createAgentSessionFromServices,createAgentSessionServices,ModelRuntime,SessionManager,SettingsManager} from '@earendil-works/pi-coding-agent';
import {enableUiTesting} from '../../../scripts/enable-ui-testing.mjs';
import {CHROME_PATH} from '../../lib/chrome.mjs';
const repo=process.cwd(),output=join(repo,'tests/scratch/ui-private-recording-boundary',String(Date.now()));await mkdir(output,{recursive:true});
const root=await realpath(await mkdtemp(join(tmpdir(),'private-recording-probe-'))),workspace=join(root,'work'),agentDir=join(root,'agent'),statePath=join(root,'state.json');
for(const p of [workspace,agentDir,join(workspace,'tests')])await mkdir(p,{recursive:true,mode:0o700});
const secret='synthetic-recording+/'+randomBytes(24).toString('base64');const variants=[secret,encodeURI(secret),encodeURIComponent(secret),Buffer.from(secret).toString('base64')];
const contains=b=>variants.some(v=>b.includes(v));
const result={status:'blocked',modelCalls:0,formalRuns:0,businessWrites:0,fixtureRequests:0,tools:[],findings:[],limits:['Synthetic fixture only; not a PMS business recording or generic privacy proof','Existing runtime reproduction; no recording gate or approval is bypassed for real data']};
let session,server;const tempFiles=new Set();
try{
 await symlink(join(repo,'node_modules'),join(workspace,'node_modules'),'dir');await writeFile(join(workspace,'package.json'),'{"type":"module"}');await writeFile(join(agentDir,'auth.json'),'{}');
 server=createServer((req,res)=>{result.fixtureRequests++;res.setHeader('Content-Type','text/html');res.end('<html><body><h1>Privacy fixture</h1>'+Array.from({length:1800},(_,i)=>'<p>marker '+i+' '+secret+'</p>').join('')+'</body></html>');});await new Promise(r=>server.listen(18983,'127.0.0.1',r));
 await writeFile(statePath,JSON.stringify({cookies:[{name:'fixture-auth',value:secret,domain:'127.0.0.1',path:'/',expires:-1,httpOnly:true,secure:false,sameSite:'Lax'}],origins:[]}),{mode:0o600});
 process.env.PI_UI_PRIVATE_RECORDING_PROBE=statePath;
 await writeFile(join(workspace,'playwright.config.mjs'),`export default {testDir:'./tests',timeout:30000,workers:1,use:{headless:true,storageState:process.env.PI_UI_PRIVATE_RECORDING_PROBE,baseURL:'http://127.0.0.1:18983',launchOptions:${JSON.stringify(CHROME_PATH?{executablePath:CHROME_PATH}:{})}},projects:[{name:'chromium'}]};`);
 await writeFile(join(workspace,'tests/seed.spec.ts'),`import {test,expect} from '@playwright/test';test('privacy seed',async({page,context})=>{expect((await context.cookies()).find(c=>c.name==='fixture-auth')).toBeTruthy();await page.goto('/');});`);
 await enableUiTesting(repo,agentDir);
 const probePath=join(root,'probe-extension.mjs');await writeFile(probePath,`export default function(pi){pi.registerTool({name:'private_recording_probe',label:'Privacy probe',description:'Synthetic privacy regression only.',parameters:{type:'object',properties:{name:{type:'string'},input:{type:'object'}},required:['name','input']},async execute(id,args,signal,onUpdate,ctx){const r=await ctx.executeTool(args.name,args.input,{signal});return r;}});}`);
 const settingsPath=join(agentDir,'settings.json'),settings=JSON.parse(await readFile(settingsPath,'utf8'));settings.extensions.push(probePath);await writeFile(settingsPath,JSON.stringify(settings));
 const runtime=await ModelRuntime.create({authPath:join(agentDir,'auth.json'),modelsPath:null,modelsStorePath:join(agentDir,'models-cache.json'),refreshOnCreate:false});for(const method of ['stream','streamSimple','complete','completeSimple'])runtime[method]=()=>{result.modelCalls++;throw Error('No model calls permitted');};
 const services=await createAgentSessionServices({cwd:workspace,agentDir,modelRuntime:runtime,settingsManager:SettingsManager.create(workspace,agentDir,{projectTrusted:true})});assert.deepEqual(services.resourceLoader.getExtensions().errors,[]);
 ({session}=await createAgentSessionFromServices({services,sessionManager:SessionManager.create(workspace,join(agentDir,'sessions'))}));await session.bindExtensions({});
 let prefix;for(let i=0;i<500;i++){prefix=session.getAllTools().find(t=>t.name.endsWith('__generator_setup_page'))?.name.replace(/generator_setup_page$/,'');if(prefix)break;await new Promise(r=>setTimeout(r,50));}assert.ok(prefix);
 const probe=session.agent.state.tools.find(t=>t.name==='private_recording_probe');assert.ok(probe);let seq=0;
 const findPaths=async(v)=>{if(!v||typeof v!=='object')return;for(const [k,x] of Object.entries(v)){if(k==='fullOutputPath'&&typeof x==='string'){tempFiles.add(x);const b=await readFile(x,'utf8');result.findings.push({surface:'sdk-full-output-file',containsSyntheticSecret:contains(b),bytes:Buffer.byteLength(b)});}else if(typeof x==='object')await findPaths(x);}};
 for(const [name,input] of [['generator_setup_page',{project:'chromium',seedFile:'tests/seed.spec.ts',plan:'Observe synthetic private boundary only'}],['browser_snapshot',{filename:'private-snapshot.md'}],['browser_take_screenshot',{type:'png',fullPage:false,scale:'css'}],['generator_read_log',{}],['browser_close',{}]]){
  if(!session.getAllTools().some(t=>t.name===prefix+name)){result.tools.push({name,available:false});continue;}
  const id='privacy-'+seq++,args={name:prefix+name,input: name==='browser_close'?{...input,intent:'Synthetic privacy boundary observation'}:input};session.agent.state.messages=[{role:'assistant',content:[{type:'toolCall',id,name:probe.name,arguments:args}]}];
  const outcome=await probe.execute(id,args,new AbortController().signal);const b=JSON.stringify(outcome);result.tools.push({name,available:true,containsSyntheticSecret:contains(b),error:outcome.isError??false,bytes:Buffer.byteLength(b),...(outcome.isError?{errorSummary: variants.reduce((s,v)=>s.replaceAll(v,'[SYNTHETIC]'),b).slice(0,650)}:{})});await findPaths(outcome);
 }
 async function inspect(path,label){for(const e of await readdir(path,{withFileTypes:true})){if(e.isSymbolicLink())continue;const p=join(path,e.name),rel=label+'/'+e.name;if(e.isDirectory())await inspect(p,rel);else{const b=await readFile(p);if(contains(b.toString()))result.findings.push({surface:'workspace-file',path:rel,containsSyntheticSecret:true,bytes:b.length});if(/\.(png|jpeg)$/.test(e.name))result.findings.push({surface:'workspace-media',path:rel,bytes:b.length});}}}
 await inspect(workspace,'work');
 assert.ok(result.tools.some(t=>t.containsSyntheticSecret),'Expected actual secret reflection through current MCP path');
 assert.ok(result.findings.some(f=>f.surface==='sdk-full-output-file'&&f.containsSyntheticSecret),'Expected SDK pre-hook temporary-output leak');
 assert.ok(result.findings.some(f=>f.surface==='workspace-file'&&f.containsSyntheticSecret),'Expected raw MCP file in public workspace');
 result.status='SYNTHETIC_PRIVATE_RECORDING_LEAK_REPRODUCED';
}catch(error){result.errorClass=error.name;result.errorSummary=String(error.message).replaceAll(secret,'[SYNTHETIC]');process.exitCode=1;}
finally{
 if(session){await session.extensionRunner?.emit({type:'session_shutdown',reason:'shutdown'}).catch(()=>{});session.dispose();}
 if(server)await new Promise(r=>server.close(r));delete process.env.PI_UI_PRIVATE_RECORDING_PROBE;
 for(const path of tempFiles)await rm(path,{force:true});await rm(root,{recursive:true,force:true});result.ownedRawOutputsRemoved=true;
 await cp(new URL(import.meta.url),join(output,'harness.mjs'));await writeFile(join(output,'result.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({output,...result},null,2));
}
