from pathlib import Path
import json,hashlib,tarfile,io,os
repo=Path.cwd();root=repo/'tests/scratch/ui-private-recording-boundary';sha=lambda b:hashlib.sha256(b).hexdigest()
base=json.loads((root/'1792992656512/result.json').read_text());probe=json.loads((root/'1792993037758/result.json').read_text())
assert base['status']=='SYNTHETIC_PRIVATE_RECORDING_LEAK_REPRODUCED'
assert any(f['surface']=='sdk-full-output-file' and f['containsSyntheticSecret'] for f in base['findings'])
assert any(f['surface']=='workspace-file' and f['containsSyntheticSecret'] for f in base['findings'])
assert any(f['surface']=='workspace-media' for f in base['findings'])
assert probe['status']=='EARLY_TRANSPORT_AND_RAW_ROOT_ISOLATION_OBSERVED_DRAFT_PUBLICATION_BLOCKED'
assert all(not t['containsSyntheticSecret'] and t['mediaBlocks']==0 for t in probe['tools'])
assert probe['tools'][4]['name']=='generator_write_test' and probe['tools'][4]['error']
assert probe['rawProtocolRetainedPrivately'] and probe['rawSnapshotRetainedPrivately']
ledger=repo/'tests/scratch/ui-optimization-u00/u05-authorized-review-budget.json';assert sha(ledger.read_bytes())==json.loads((repo/'docs/ui-testing-evidence/optimization-pms-desktop-refresh.json').read_text())['modelReviewLedgerSha256']
for p in root.iterdir():
 if p.is_dir():(p/'.cleanup-keep').write_text('Synthetic privacy experiment summaries and exact harness; retain failures. No raw private payload archived.\n')
text='''# UI 私密录制边界：合成复现与未交付原型

日期：2026-10-26。属于项目管理系统后续测试的工程准备，不是该系统的业务录制或验收。

仅访问本机合成页面，未使用真实账号、目标服务、个人模型认证或付费模型。通过真实 Pi SDK 的 ctx.executeTool 嵌套调用现有 Playwright 1.62.1 测试 MCP；随机合成 cookie 对应的值被页面反射。

现用路径已复现：generator_setup_page 返回的长文本及 structuredContent 含合成秘密；SDK在结果钩子之前写入的165612字节长输出文件含该值；browser_snapshot(filename)写出的165266字节快照含该值；默认截图写入工作区 .playwright-mcp，且图像由MCP返回。图像未做OCR，不能用文本字节扫描未命中推断图像安全。

隔离原型：使用公开 createMcpExtension.createTransport 和 StdioTransport，在SDK转换前脱敏已知cookie及私有路径的原文/JSON/URL/Base64形式，递归处理消息及structuredContent，屏蔽媒体/资源。只在隔离会话把MCP roots回复改为私有原始输出根，不改SDK/Playwright源码。最终原型保留既有seed静态收集钩子。

观察：setup/snapshot/screenshot/read_log/close正常完成，所有公开返回没有合成秘密或媒体块；SDK仍写入86412字节长输出文件，但该文件检查不含已知秘密；公开工作区扫描未发现相同秘密或图片。私有目录保留原始协议与文本快照，检查其仍包含原文，证明不是通过删除浏览器内容制造通过。

未解决的失败：generator_write_test使用同一root约束草稿位置。直接迁移roots使其拒绝生成，错误为 Test file did not match any of the test dirs: ../work/tests。原型只证明早期脱敏/原始路径隔离两个环节可行，不能作为完整录制交付；没有放宽原生writer边界、手工生成替代批准或修改产品配置。

历史：两次准备脚本分别遗漏快照filename、给只读工具添加不支持的intent，导致原始文件断言不满足；保留失败结果，不计通过。基线修正参数后成功复现。首轮隔离原型没有保留辅助模块当时快照，仅保留当时harness/result；最终隔离轮补回既有seed钩子并保存全部原型源码，作为当前证据。

范围限制：尚未覆盖嵌套JSON存储、运行中新增凭据、所有编码、进度/错误/取消/重连、任意文件链接或Electron接入。截图不代表完整视觉证据；没有通用隐私安全证明。实验完成后清理仅本轮的原始合成payload、SDK临时输出、浏览器/会话/服务及临时根；公开摘要、源码、失败日志保留，原始payload不在归档中。

模型调用0，正式批次0，真实业务写入0。产品私密录制继续unsupported。下一步需解决原始捕获根与原生草稿发布的耦合，并保留源引用、工作区作用域和写入守卫，再扩展泄露/生命周期测试及Electron验收。

公开快照：private-recording-boundary-1792993037758/。文件保存不代表应用文档列表可见或测试结果入库。
'''
docdir=Path.home()/'Library/Application Support/Pi Agent Desktop/data/data-space/project-documents/e2f5d42d-2781-4e68-a452-4c87c7d1d346';store=docdir.parent.parent/'store.json';before=store.read_bytes();snapshot=docdir/'private-recording-boundary-1792993037758';snapshot.mkdir(mode=0o700)
items=[]
for name,p in [('baseline-result.json',root/'1792992656512/result.json'),('prototype-result.json',root/'1792993037758/result.json'),('prototype-harness.mjs',root/'1792993037758/harness.mjs'),('transport-prototype.mjs',root/'1792993037758/transport-prototype.mjs')]:
 b=p.read_bytes();target=snapshot/name
 with target.open('xb') as f:f.write(b)
 os.chmod(target,0o600);assert target.read_bytes()==b;items.append({'path':name,'sha256':sha(b),'bytes':len(b)})
doc=docdir/'OperationContract-private-recording-boundary-2026-10-26.md'
with doc.open('x') as f:f.write(text)
os.chmod(doc,0o600);assert doc.read_text()==text;assert store.read_bytes()==before
receipt={'document':{'path':str(doc),'sha256':sha(doc.read_bytes()),'bytes':doc.stat().st_size},'snapshot':{'path':str(snapshot),'files':items},'storeUnchangedDuringDocumentSave':True,'application_document_index':'unsupported'}
(root/'1792993037758/data-space-documents.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
files={}
for p in sorted(root.rglob('*')):
 if p.is_file():assert not p.is_symlink();files[str(p.relative_to(repo))]=p.read_bytes()
for name in ['private-recording-boundary.log','private-recording-boundary-v2.log','private-recording-boundary-v3.log','private-recording-boundary-prototype.log','private-recording-boundary-prototype-v2.log','probe-private-recording-boundary.mjs','private-recording-transport-prototype.mjs','archive-private-recording-boundary.py']:
 p=repo/'tests/scratch/ui-optimization-u00'/name;files[str(p.relative_to(repo))]=p.read_bytes()
archive=repo/'docs/ui-testing-evidence/optimization-u02-private-recording-boundary.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for n,b in sorted(files.items()):
  m=tarfile.TarInfo(n);m.size=len(b);m.mtime=0;t.addfile(m,io.BytesIO(b))
with tarfile.open(archive) as t:
 assert set(t.getnames())==set(files)
 for m in t:assert t.extractfile(m).read()==files[m.name]
index={'date':'2026-10-26','status':'REAL_SDK_MCP_LEAK_REPRODUCED_EARLY_FILTER_PROTOTYPE_DRAFT_PUBLICATION_BLOCKED','plan_complete':False,'product_private_recording':'unsupported','modelCalls':0,'formalRuns':0,'modelReviewLedgerSha256':sha(ledger.read_bytes()),'ledger_unchanged':True,'baseline':base,'prototype':probe,'historical_failures':['1792992497662','1792992549189'],'prototype_v1_source_limitation':'Helper module was not snapshotted in 1792992936244; use fully snapshotted 1792993037758 for current conclusion','durable_project_documents':receipt,'limits':['No product implementation or configuration changed','No real PMS recording or Electron privacy acceptance','Only known synthetic cookie variants; no arbitrary-encoding or rotating-credential proof','No protocol progress/error/cancellation/reconnect coverage','Only public summaries/source archived; owned raw synthetic payloads removed after observation'],'archive':{'path':str(archive.relative_to(repo)),'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'files':len(files),'roundtrip_verified':True},'files':[{'path':n,'sha256':sha(b),'bytes':len(b)}for n,b in sorted(files.items())]}
(repo/'docs/ui-testing-evidence/optimization-u02-private-recording-boundary.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'files':len(files),'bytes':archive.stat().st_size,'persistent_files':len(items),'ledger_unchanged':True}))
