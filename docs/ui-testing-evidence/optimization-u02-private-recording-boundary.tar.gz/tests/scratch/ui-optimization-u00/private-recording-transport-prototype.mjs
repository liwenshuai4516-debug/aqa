/** Private synthetic experiment only. Not registered in the product; draft publication remains unimplemented. */
import {appendFileSync,readFileSync} from 'node:fs';
import {pathToFileURL} from 'node:url';
import {join} from 'node:path';
import {StdioTransport} from '@earendil-works/pi-mcp';
import {createMcpExtension} from '@earendil-works/pi-coding-agent';
import {validateRecordingSeed} from '../../../.pi/skills/ui-testing-workflow/assets/recording-preflight.mjs';
import {resolvePlaywrightRuntime} from '../../../.pi/skills/ui-testing-workflow/assets/playwright-runtime.mjs';
export function probeExtension({rawRoot,statePath}){
 const state=JSON.parse(readFileSync(statePath,'utf8'));
 const values=[rawRoot,statePath,...state.cookies.map(c=>c.value)];
 const secrets=[...new Set(values.flatMap(v=>[v,encodeURI(v),encodeURIComponent(v),JSON.stringify(v).slice(1,-1),Buffer.from(v).toString('base64'),Buffer.from(v).toString('base64url')]))].sort((a,b)=>b.length-a.length);
 const text=value=>secrets.reduce((s,v)=>s.split(v).join('[PRIVATE]'),value);
 const sanitize=value=>{
  if(typeof value==='string')return text(value);
  if(Array.isArray(value))return value.map(sanitize);
  if(value&&typeof value==='object'){
   if(['image','audio','resource_link'].includes(value.type)||value.type==='resource'&&value.resource?.blob)return{type:'text',text:'[Private media/resource withheld; reduced evidence only]'};
   return Object.fromEntries(Object.entries(value).map(([k,v])=>[text(k),sanitize(v)]));
  }
  return value;
 };
 const mcp=createMcpExtension({
  loadConfig:ctx=>{const runtime=resolvePlaywrightRuntime(ctx.cwd);return{servers:[{name:'ui-playwright-test',scope:'extension',source:import.meta.url,config:{command:process.execPath,args:[runtime.cli,'run-test-mcp-server','--headless','-c',runtime.config],cwd:ctx.cwd,exposure:'direct',timeout:45}}],errors:[]};},
  createTransport:entry=>{
   const inner=new StdioTransport({command:entry.config.command,args:entry.config.args,cwd:entry.config.cwd,stderr:'pipe'});
   return{
    start:()=>inner.start(),close:()=>inner.close(),
    send:message=>inner.send(message.result?.roots?{...message,result:{...message.result,roots:[{uri:pathToFileURL(rawRoot).href,name:'private-recording'}]}}:message),
    onMessage:listener=>inner.onMessage(message=>{appendFileSync(join(rawRoot,'protocol.ndjson'),JSON.stringify(message)+'\n',{mode:0o600});listener(sanitize(message));}),
    onError:listener=>inner.onError(error=>listener(new Error(text(error.message)))),
    onClose:listener=>inner.onClose(listener),
    get stderr(){return text(inner.stderr);}
   };
  }
 });
 return async pi=>{
  pi.on('tool_call',async(event,ctx)=>{if(event.toolName!=='mcp__ui_playwright_test__generator_setup_page')return;try{await validateRecordingSeed(ctx.cwd,event.input);}catch(error){return{block:true,reason:error.message};}});
  return mcp(pi);
 };
}
