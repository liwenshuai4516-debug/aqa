from pathlib import Path
import hashlib,json,subprocess,tarfile
repo=Path.cwd()
scratch=repo/'tests/scratch/ui-optimization-u00/recording-product-connection'
sha=lambda b: hashlib.sha256(b).hexdigest()
sources=[
'.pi/skills/ui-testing-workflow/SKILL.md',
'.pi/skills/ui-testing-workflow/assets/mcp-extension.mjs',
'.pi/skills/ui-testing-workflow/assets/private-recording-connection.mjs',
'.pi/skills/ui-testing-workflow/assets/private-recording-session.mjs',
'.pi/skills/ui-testing-workflow/assets/private-recording-transport.mjs',
'.pi/skills/ui-testing-workflow/assets/private-recording-workspace.mjs',
'.pi/skills/ui-testing-workflow/assets/playwright-runtime.mjs',
'.pi/skills/ui-testing-workflow/references/maintenance.md',
'docs/directory-reference.md','docs/project-map.md',
'docs/ui-testing-optimization-plan.md','docs/ui-testing-optimization-execution.md',
 'tests/ui-testing-integration-test.mjs','tests/ui-testing-visibility-test.mjs',
 'tests/unit/ui-private-recording-connection.test.ts','tests/unit/ui-private-recording-extension.test.ts',
 'tests/unit/ui-private-recording-workspace.test.ts','tests/unit/ui-private-recording-transport.test.ts',
 'tests/unit/ui-private-recording-storage-events.test.ts','tests/unit/ui-recording-preflight.test.ts',
 'tests/unit/ui-testing-registration.test.ts','tests/unit/skill-capability-settings.test.ts',
 'node_modules/@earendil-works/pi-coding-agent/dist/extensions/mcp/runtime.js',
 'node_modules/@earendil-works/pi-coding-agent/dist/extensions/mcp/index.js',
 'tools/e2e/node_modules/pi-ui-testing/dist/private-evidence.js',
 'tools/e2e/node_modules/pi-ui-testing/dist/extension.js',
]
files={}
for name in sources:
    p=repo/name
    assert p.is_file(),name
    files['sources/'+name]=p
for p in scratch.iterdir():
    if p.is_file() and p.suffix in ['.log','.mjs','.ts','.md','.py']:
        files['stage/'+p.name]=p
for p in (repo/'tests/scratch/ui-workflow-visibility/1793008705747').iterdir():
    if p.is_file() and p.suffix in ['.png','.log','.json']:
        files['electron/'+p.name]=p
index={name:{'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size} for name,p in files.items()}
archive=repo/'docs/ui-testing-evidence/optimization-u02-recording-product-connection.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
    for name,p in sorted(files.items()):
        tar.add(p,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz') as tar:
    assert len(tar.getmembers())==len(index)
    for member in tar.getmembers():
        assert member.isfile()
        b=tar.extractfile(member).read()
        assert len(b)==index[member.name]['bytes'] and sha(b)==index[member.name]['sha256']
previous=json.loads((repo/'docs/ui-testing-evidence/optimization-u02-recording-session-binding.json').read_text())
for name,expected in previous['ledgerSha256'].items():
    assert sha((repo/'tests/scratch/ui-optimization-u00'/name).read_bytes())==expected
manifest={
 'schema_version':'1.0','date':'2026-10-26',
 'stage':'U02 product private MCP preparation, handshake and lifecycle',
 'status':'PRODUCT_PRIVATE_HANDSHAKE_PASSED_BROWSER_RECORDING_BLOCKED',
 'baseCommit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 'planComplete':False,'nativeVersion':'0.1.15','sdkVersion':'1.2.0','playwrightVersion':'1.62.1',
 'nativePackageSha256':sha((repo/'.pi/skills/ui-testing-workflow/assets/pi-ui-testing-0.1.15.tgz').read_bytes()),
 'modelCalls':0,'formalRuns':0,'businessWrites':0,
 'unit':{'files':8,'passed':54,'newConnectionTests':5,'newExtensionTests':4},
 'oldGuardControl':{'passed':4,'failed':1,'failure':'late protocol response after cancellation'},
 'sdk':{'status':'passed','checks':21,'automaticPreparation':True,'privateHandshake':True,'privateBrowserDispatch':'blocked','finish':'partial','derivedAuthenticationRevoked':True,'anonymousBrowser':'passed'},
 'electron':{'status':'PASS','checks':7,'mcpTools':87,'isolatedDirectories':True,'realPmsPrivateRecording':False},
 'validation':{'typecheck':'PASS: all five configurations','lint':'PASS','protocol':'PASS: structure; history heuristic SKIP (no tag)','layout':'PASS','diff':'PASS','size':'PASS: before and after archive','clean':'preview only, no deletion'},
 'ledgerSha256':previous['ledgerSha256'],
 'archive':{'path':str(archive.relative_to(repo)),'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'files':len(index),'roundtripVerified':True},
 'members':index,
 'limits':[
 'Only protocol handshake is connected; browser capture, dynamic secret observation and native writer publication are not integrated',
 'Preparation receipt does not promise asynchronous connection readiness',
 'Explicit inputs do not prove an arbitrary dependency closure',
 'No full reconnect/resume, real frame/target or PMS role/data acceptance',
 'SDK default transport uses an internal module of locked SDK 1.2.0; verify on upgrades',
 'Early failure logs are preserved; not every intermediate source revision was separately retained',
 'Raw synthetic authentication and protocol captures were cleaned with their owned test fixtures; private retention was asserted during their lifecycle',
 'Document files are stored in the project directory without an application document index',
 ],
}
path=archive.with_suffix('').with_suffix('.json')
path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(manifest['archive'],ensure_ascii=False))
