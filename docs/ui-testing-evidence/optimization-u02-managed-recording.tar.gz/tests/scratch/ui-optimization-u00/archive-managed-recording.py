from pathlib import Path
import hashlib,json,tarfile,io,os,shutil
repo=Path.cwd();root=repo/'tests/scratch/ui-managed-recording-handoff';sha=lambda b:hashlib.sha256(b).hexdigest()
logs=repo/'tests/scratch/ui-optimization-u00'
ids={n:Path(json.loads((logs/('managed-recording-'+l+'.log')).read_text())['output']).name for n,l in [('complete','complete'),('renewal','renewal')]}
results={n:json.loads((root/i/'result.json').read_text()) for n,i in ids.items()}
assert results['complete']['recordingStatus']=='complete' and results['complete']['publicScriptEqualsNative'] and results['complete']['finishGaps']==[]
assert results['renewal']['recordingStatus']=='partial' and results['renewal']['parentRenewalRevokedBeforeWriter'] and 'parent-authentication-changed' in results['renewal']['finishGaps']
for r in results.values():
 assert r['modelCalls']==r['formalRuns']==r['businessWrites']==0 and r['hostParentReferenceUnchanged'] and r['ownedRawOutputsRemoved']
 assert all(not t['containsSyntheticSecret'] and t['mediaBlocks']==0 for t in r['tools'])
ledger=logs/'u05-authorized-review-budget.json';ledger_sha=sha(ledger.read_bytes());assert ledger_sha==json.loads((repo/'docs/ui-testing-evidence/optimization-u02-private-recording-mirror.json').read_text())['modelReviewLedgerSha256']
verified=0
for d in root.iterdir():
 if not d.is_dir():continue
 (d/'.cleanup-keep').write_text('Retain synthetic managed recording evidence, no private raw state.\n')
 (d/'tests').mkdir(exist_ok=True);(d/'tests/seed.spec.ts').write_bytes((d/'seed.spec.ts').read_bytes());(d/'package.json').write_bytes(b'{"type":"module"}')
 def walk(v):
  global verified
  if isinstance(v,dict):
   if isinstance(v.get('path'),str) and isinstance(v.get('sha256'),str):
    p=Path(v['path']);assert not p.is_absolute() and '..' not in p.parts;assert sha((d/p).read_bytes())==v['sha256'],str(d/p);verified+=1
   for x in v.values():walk(x)
  elif isinstance(v,list):
   for x in v:walk(x)
 for p in (d/'qa').rglob('*.json'):walk(json.loads(p.read_text()))
 walk(json.loads((d/'result.json').read_text()))
text='''# 受管身份与私有录制副本：内部模块验证

日期：2026-10-26。范围为项目管理系统后续验收的合成工程证据，仅访问本机18983页面；没有真实PMS请求、业务写入、正式批次或模型调用。

新增内部private-recording-workspace模块：以原生authState验证已有受管引用，只复制明确path/SHA-256输入，拒绝路径逃逸、符号链接、敏感配置及摘要变化。宿主私有目录0700，输入和派生state为0600。派生state仅调整workspace与不延长的有效期（至多5分钟），子进程环境覆盖原引用，宿主引用和原state保持不变。assertCurrent检查父认证、两侧冻结输入及目录/文件权限；失效时撤销派生认证，保留原始捕获。receipt仍将业务authentication/role/data标unknown，不泄露state或私有路径。

完整类型检查通过；4个相关Vitest文件23项通过，其中新模块7项覆盖子进程原生消费、两侧输入同时篡改、父认证更新/引用缺失/过期、撤销保留证据、路径/权限/非受管拒绝、派生篡改和远期期限上限。

真实SDK/MCP验证复用原ui_discover_record inventory/start/action/finish：由真实createPrivateBrowserStates生成仅含合成localStorage token的父受管state。父引用直接用于副本会被原生authState拒绝；新模块派生引用仅传StdioTransport子进程。seed在实际MCP进程调用原生authState并检查localStorage token存在。正常轮完成5步、原生complete、gaps为空、1份原生草稿，公开草稿与原生writer字节一致。宿主引用及父state字节不变。

反例在snapshot/read_log后修改父state：harness调用assertCurrent拒绝并确认派生文件删除，未调用writer，随后正常关闭并finish；原生partial、0脚本，保留parent-authentication-changed/missing-generated-script/goal-not-reached。此阻断来自验证harness对内部模块的显式调用，不是已部署到产品的执行门禁。原生工具步骤4条，不伪造writer失败事件。

公开响应、SDK长输出和工作区未检出本轮已知合成秘密及编码变体，媒体块0；私有协议含原文证明没有删改页面来获得通过。实验结束清理自有会话/浏览器/MCP/服务及仅本轮合成原始payload，公开归档保留原生complete/partial、源码和摘要，公开raw-log已经过滤，不能当完整私密原文。

模块尚未被产品mcp-extension导入，data-space prepare-private mode=record仍unsupported，未修改个人安装或SDK。仅明确三文件输入，不证明任意项目依赖闭包、运行中新凭据/嵌套JSON存储、所有协议分支、并发发布、取消晚响应/重连、Electron完整接入、真实角色/租户/隔离数据；整计划保持进行中。

文件已保存到Electron项目文档目录，未建立应用文档列表索引，不表示界面列表可见或正式结果入库。
'''
docdir=Path.home()/'Library/Application Support/Pi Agent Desktop/data/data-space/project-documents/e2f5d42d-2781-4e68-a452-4c87c7d1d346';store=docdir.parent.parent/'store.json';before=store.read_bytes();snapshot=docdir/('managed-recording-'+ids['complete']);snapshot.mkdir(mode=0o700)
for n,i in ids.items():shutil.copytree(root/i,snapshot/n)
persisted=[]
for p in snapshot.rglob('*'):
 if p.is_dir():os.chmod(p,0o700)
 elif p.is_file():
  assert not p.is_symlink();os.chmod(p,0o600);n,*parts=p.relative_to(snapshot).parts;assert p.read_bytes()==(root/ids[n]/Path(*parts)).read_bytes();persisted.append({'path':str(p.relative_to(snapshot)),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size})
doc=docdir/'OperationContract-managed-recording-workspace-2026-10-26.md'
with doc.open('x') as f:f.write(text)
os.chmod(doc,0o600);assert doc.read_text()==text and store.read_bytes()==before
files={}
for p in sorted(root.rglob('*')):
 if p.is_file():assert not p.is_symlink();files[str(p.relative_to(repo))]=p.read_bytes()
for n in ['probe-managed-recording-handoff.mjs','managed-recording-mirror-prototype.mjs','archive-managed-recording.py','managed-recording-complete.log','managed-recording-renewal.log','managed-recording-unit.log']:
 p=logs/n;files[str(p.relative_to(repo))]=p.read_bytes()
for n in ['.pi/skills/ui-testing-workflow/assets/private-recording-workspace.mjs','tests/unit/ui-private-recording-workspace.test.ts']:files[n]=(repo/n).read_bytes()
archive=repo/'docs/ui-testing-evidence/optimization-u02-managed-recording.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for n,b in sorted(files.items()):
  m=tarfile.TarInfo(n);m.size=len(b);m.mtime=0;t.addfile(m,io.BytesIO(b))
with tarfile.open(archive) as t:
 assert set(t.getnames())==set(files)
 for m in t:assert t.extractfile(m).read()==files[m.name]
index={'date':'2026-10-26','status':'INTERNAL_MANAGED_MIRROR_COMPLETE_AND_PARENT_RENEWAL_PARTIAL_PRODUCT_NOT_CONNECTED','plan_complete':False,'product_private_recording':'unsupported','modelCalls':0,'formalRuns':0,'modelReviewLedgerSha256':ledger_sha,'ledger_unchanged':True,'current_runs':{n:{'directory':str((root/i).relative_to(repo)),'result':results[n]} for n,i in ids.items()},'refsVerified':verified,'verification':{'typecheck':'passed (all five configurations)','vitest':'4 files, 23 tests passed','newModule':'7 tests passed','lint':'passed','protocol':'passed; tag heuristic unavailable','size':'passed'},'document':{'path':str(doc),'sha256':sha(doc.read_bytes()),'bytes':doc.stat().st_size,'storeUnchanged':True},'snapshot':{'path':str(snapshot),'files':persisted},'limits':['Internal module only, no product registration or Electron integration','Explicit three-file fixture only; no generic input closure','Lifecycle assertCurrent called by harness, not product MCP guard','No new credentials/JSON/protocol/race/reconnect coverage','Real PMS roles/tenant/data still unverified','Original synthetic raw payloads removed; public logs reduced'],'archive':{'path':str(archive.relative_to(repo)),'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'files':len(files),'roundtrip_verified':True},'files':[{'path':n,'sha256':sha(b),'bytes':len(b)} for n,b in sorted(files.items())]}
(repo/'docs/ui-testing-evidence/optimization-u02-managed-recording.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'files':len(files),'refs':verified,'snapshotFiles':len(persisted),'bytes':archive.stat().st_size,'ledgerUnchanged':True}))
