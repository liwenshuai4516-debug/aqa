# API test run 2003ca76-3d46-48db-9a2c-de26baf437da

- Verdict: failed
- Suite hash: 7a8113f71b44bba430b1034724907ad0aa3a05973360c2e27504b3a001287bcd
- Retest of: none
- Cleanup: failed
- Analysis: deterministic evidence classification; root cause unconfirmed

| Finding | Case | Category | Status | Evidence |
| --- | --- | --- | --- | --- |
| d23cab5de25e2e64cdd8bb0c | record-normal | cleanup_failure | open | 2003ca76-3d46-48db-9a2c-de26baf437da |
