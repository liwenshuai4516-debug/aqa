# API test run 90486f70-2af7-4155-a066-6252b2384cbd

- Verdict: failed
- Suite hash: 7f201b3a8c8537eb763fda693f0ab5152aa75ba00e788100ed110212d1bf0997
- Retest of: 2003ca76-3d46-48db-9a2c-de26baf437da
- Cleanup: failed
- Analysis: deterministic evidence classification; root cause unconfirmed

| Finding | Case | Category | Status | Evidence |
| --- | --- | --- | --- | --- |
| eedae246d098cd8349a749f0 | record-normal | cleanup_failure | open | 90486f70-2af7-4155-a066-6252b2384cbd |
| d23cab5de25e2e64cdd8bb0c | record-normal | cleanup_failure | open | 2003ca76-3d46-48db-9a2c-de26baf437da |
