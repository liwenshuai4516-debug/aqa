# API test run 5d4a7765-64d3-46ab-a7ed-4d433bbfc901

- Verdict: failed
- Suite hash: c293631e9eca7595780ab3f8d0c6750bc20aee1cfdfe436983206c7e0ad48ad0
- Retest of: 15c3ead4-d1ec-4390-97fe-5f7babd578b2
- Cleanup: not-required
- Analysis: deterministic evidence classification; root cause unconfirmed

| Finding | Case | Category | Status | Evidence |
| --- | --- | --- | --- | --- |
| 00ecaebdd55db7709bc11543 | record-normal | suspected_api_defect | open | 5d4a7765-64d3-46ab-a7ed-4d433bbfc901 |
