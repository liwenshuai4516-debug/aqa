# API test run d7e5f2f2-9ef0-4f1f-b047-ee45c38e5c7e

- Verdict: error
- Suite hash: d6355f2b5e38bc11b027a17f08199cb85f868404f7eeeb09fc60a8125f8159bd
- Retest of: none
- Cleanup: not-required
- Analysis: deterministic evidence classification; root cause unconfirmed

| Finding | Case | Category | Status | Evidence |
| --- | --- | --- | --- | --- |
| 8912ccaf194732dbe0e315c2 | record-normal | environment_fault | open | d7e5f2f2-9ef0-4f1f-b047-ee45c38e5c7e |
| 2d2a53dd0c5d1c693a250e3d | record-normal | suspected_api_defect | open | d7e5f2f2-9ef0-4f1f-b047-ee45c38e5c7e |
