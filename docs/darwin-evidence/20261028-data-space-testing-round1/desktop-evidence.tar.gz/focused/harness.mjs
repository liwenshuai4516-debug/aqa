// Focused native Electron skill lifecycle regression derived from the existing full harness.
// Excludes native business flows; the original full-suite failures remain recorded separately.
import assert from "node:assert/strict";
import { mkdtemp, mkdir, readFile, writeFile, cp } from "node:fs/promises";
import { join } from "node:path";
import { tmpdir } from "node:os";
import electron from "electron";
import { ensureBuild } from "../../tests/lib/ensure-build.mjs";
import { portUp } from "../../tests/lib/port-utils.mjs";
import { launchNativeApp } from "../../tests/desktop/native-app.mjs";
import { waitUntil } from "../../qa/ui/project-environment.mjs";
import { enableDataSpace } from "../../scripts/enable-data-space.mjs";
const repo = process.cwd();
ensureBuild(repo,"darwin-data-space-skill-lifecycle");
const temporary = await mkdtemp(join(tmpdir(),"darwin-skill-"));
const workspace=join(temporary,"project");
const userData=join(temporary,"desktop");
const agentDir=join(userData,"agent");
const dataDir=join(userData,"data");
const output=join(repo,"tests/scratch/darwin-data-space-lifecycle",String(Date.now()));
for(const p of [workspace,agentDir,output]) await mkdir(p,{recursive:true});
await cp(new URL(import.meta.url),join(output,"harness.mjs"));
await writeFile(join(agentDir,"auth.json"),"{}");
await writeFile(join(agentDir,"models.json"),'{"providers":{}}');
await enableDataSpace(repo,{agentDir,dataDir});
const installed=JSON.parse(await readFile(join(dataDir,"plugins/data-space/manifest.json"),"utf8"));
const expected=JSON.parse(await readFile(join(repo,"plugins/data-space/manifest.json"),"utf8"));
assert.equal(installed.version,expected.version);
const first=await readFile(join(agentDir,"settings.json"),"utf8");
await enableDataSpace(repo,{agentDir,dataDir});
assert.equal(await readFile(join(agentDir,"settings.json"),"utf8"),first);
const port=18983;
assert.equal(await portUp(port),false,"Isolated port must be free");
const env={...process.env};
for(const key of Object.keys(env))if(/(API_KEY|AUTH_TOKEN|ACCESS_TOKEN|SECRET_ACCESS_KEY|SESSION_TOKEN)$/.test(key)||/^(AWS_|GOOGLE_|GCLOUD_|AZURE_|PI_)/.test(key)||["ELECTRON_RUN_AS_NODE","NODE_OPTIONS"].includes(key))delete env[key];
Object.assign(env,{PI_DESKTOP_USER_DATA:userData,PI_WEB_CWD:workspace,PI_WEB_PORT:String(port),PI_WEB_PLUGIN_CATALOG_URL:"off",PI_WEB_SDK:"bundled"});
const result={status:"FAIL",checks:[],scope:"Skill discovery, ownership and lifecycle only; original full-suite failures are not cleared",actualModelCalls:0,businessRequests:0,pluginVersion:installed.version,temporary};
let app,page;
try{
app=await launchNativeApp({executablePath:electron,packaged:false,env});
page=await app.firstWindow();
	const notices = [];
	page.on("websocket", (s) =>
		s.on("framereceived", ({ payload }) => {
			try {
				const frame = JSON.parse(String(payload));
				if (frame.type === "notice") notices.push(frame.text);
			} catch {}
		}),
	);
	await page.waitForSelector(".app");
	await page.waitForSelector(".app");
	const setup = page.locator(".setup-modal .modal-close");
	if (await setup.isVisible()) await setup.click();
	const input = page.locator("textarea").first();
	await input.waitFor({ state: "visible" });
	const reload = async () => {
		const after = notices.length;
		await input.fill("/reload");
		await input.press("Escape");
		await input.press("Enter");
		await waitUntil(
			() => notices.slice(after).some((s) => /已重新加载|Reloaded extensions/.test(s)),
			"desktop reload",
			60000,
		);
	};
	const settings = async (tab) => {
		await page.getByRole("button", { name: /^(设置|Settings)$/ }).click();
		await page.locator(`.settings-tab[data-tab="${tab}"]`).click();
	};
	const close = () => page.locator(".set-close-btn").click();
	const skill = () =>
		page.locator(".settings-modal .set-row").filter({
			has: page.locator('.set-row-name [title="data-space-testing"]'),
		});
	const candidate = () =>
		page.locator(".slash-item").filter({ has: page.locator('.slash-name[title="/skill:data-space-testing"]') });
	const plugin = () =>
		page.locator(".settings-modal .set-row").filter({
			has: page.locator(".set-row-name", { hasText: /数据空间|Data Space/ }),
		});
	await settings("skills");
	await skill().waitFor();
	assert.match(await skill().innerText(), /数据空间测试数据规范/);
	assert.equal(await skill().getByRole("switch").getAttribute("aria-checked"), "true");
	await page.screenshot({ path: join(output, "skill.png") });
	await close();
	await input.fill("/data");
	await candidate().waitFor();
	await candidate().click();
	assert.equal(await input.inputValue(), "/skill:data-space-testing ");
	await input.fill("");
	result.checks.push(
		"app-level registration is idempotent; desktop discovers the skill in another workspace and completes /data",
	);
	await settings("skills");
	await skill().getByRole("switch").click();
	await close();
	await reload();
	await settings("skills");
	assert.equal(await skill().getByRole("switch").getAttribute("aria-checked"), "false");
	await close();
	await input.fill("/data");
	assert.equal(await candidate().count(), 0);
	await input.fill("");
	await settings("skills");
	await skill().getByRole("switch").click();
	await close();
	await reload();
	result.checks.push("individual skill disabling survives reload, hides the shortcut, and can be restored");
	await settings("plugins");
	await page.getByRole("tab", { name: /插件列表|Plugin list/ }).click();
	await plugin().getByRole("switch").click();
	await waitUntil(
		async () => (await plugin().getByRole("switch").getAttribute("aria-checked")) === "false",
		"plugin off",
	);
	await close();
	await reload();
	await settings("skills");
	assert.equal(await skill().getByRole("switch").getAttribute("aria-checked"), "false");
	await page.screenshot({ path: join(output, "plugin-blocked.png") });
	await close();
	await input.fill("/data");
	assert.equal(await candidate().count(), 0);
	await input.fill("");
	await settings("plugins");
	await page.getByRole("tab", { name: /插件列表|Plugin list/ }).click();
	assert.equal(await plugin().getByRole("switch").getAttribute("aria-checked"), "false");
	await plugin().getByRole("switch").click();
	await waitUntil(
		async () => (await plugin().getByRole("switch").getAttribute("aria-checked")) === "true",
		"plugin on",
	);
	await close();
	await reload();
	await settings("skills");
	assert.equal(await skill().getByRole("switch").getAttribute("aria-checked"), "true");
	await close();
	await input.fill("/data");
	await candidate().waitFor();
	await input.fill("");
	result.checks.push(
		"plugin disabling gates its skill across reload; enabling restores discovery without changing the skill preference",
	);
	await settings("tools");
	for (const name of ["data_space_cases", "data_space_env", "data_space_record_result", "data_space_automation"]) {
		const row = page
			.locator(".settings-modal .set-row")
			.filter({ has: page.locator(".set-row-name", { hasText: name }) });
		await row.waitFor();
		assert.equal(await row.getByRole("switch").getAttribute("aria-checked"), "true");
		await row.scrollIntoViewIfNeeded();
	}
	await page.screenshot({ path: join(output, "tools.png") });
	await close();
	result.checks.push("desktop tool management exposes all four existing Data Space tools");

result.status="PASS";
}catch(error){
result.error=error.stack;
await writeFile(join(output,"desktop.log"),app?.getLogs()??"");
await page?.screenshot({path:join(output,"failure.png")}).catch(()=>{});
process.exitCode=1;
}finally{
await app?.close();
await writeFile(join(output,"result.json"),JSON.stringify({...result,evidence:output},null,2)+"\n");
console.log(JSON.stringify({...result,evidence:output},null,2));
}
