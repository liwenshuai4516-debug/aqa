# API test run 519d321f-1f2a-4ce8-93e4-1c858b26185b

- Verdict: failed
- Suite hash: c293631e9eca7595780ab3f8d0c6750bc20aee1cfdfe436983206c7e0ad48ad0
- Retest of: none
- Cleanup: not-required
- Analysis: deterministic evidence classification; root cause unconfirmed

| Finding | Case | Category | Status | Evidence |
| --- | --- | --- | --- | --- |
| 00ecaebdd55db7709bc11543 | record-normal | suspected_api_defect | open | 519d321f-1f2a-4ce8-93e4-1c858b26185b |
