# API test run 0d12410a-4e05-4e7e-8658-6d23175f4193

- Verdict: failed
- Suite hash: 7a8113f71b44bba430b1034724907ad0aa3a05973360c2e27504b3a001287bcd
- Retest of: none
- Cleanup: failed
- Analysis: deterministic evidence classification; root cause unconfirmed

| Finding | Case | Category | Status | Evidence |
| --- | --- | --- | --- | --- |
| d23cab5de25e2e64cdd8bb0c | record-normal | cleanup_failure | open | 0d12410a-4e05-4e7e-8658-6d23175f4193 |
