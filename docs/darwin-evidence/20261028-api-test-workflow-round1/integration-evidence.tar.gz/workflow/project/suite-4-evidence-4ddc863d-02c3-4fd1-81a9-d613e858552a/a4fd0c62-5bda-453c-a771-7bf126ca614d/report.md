# API test run a4fd0c62-5bda-453c-a771-7bf126ca614d

- Verdict: failed
- Suite hash: 7f201b3a8c8537eb763fda693f0ab5152aa75ba00e788100ed110212d1bf0997
- Retest of: 0d12410a-4e05-4e7e-8658-6d23175f4193
- Cleanup: failed
- Analysis: deterministic evidence classification; root cause unconfirmed

| Finding | Case | Category | Status | Evidence |
| --- | --- | --- | --- | --- |
| eedae246d098cd8349a749f0 | record-normal | cleanup_failure | open | a4fd0c62-5bda-453c-a771-7bf126ca614d |
| d23cab5de25e2e64cdd8bb0c | record-normal | cleanup_failure | open | 0d12410a-4e05-4e7e-8658-6d23175f4193 |
