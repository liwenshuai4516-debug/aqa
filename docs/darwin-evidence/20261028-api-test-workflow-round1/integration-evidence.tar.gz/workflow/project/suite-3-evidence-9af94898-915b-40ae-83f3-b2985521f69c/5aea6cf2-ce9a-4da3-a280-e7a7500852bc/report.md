# API test run 5aea6cf2-ce9a-4da3-a280-e7a7500852bc

- Verdict: error
- Suite hash: d6355f2b5e38bc11b027a17f08199cb85f868404f7eeeb09fc60a8125f8159bd
- Retest of: none
- Cleanup: not-required
- Analysis: deterministic evidence classification; root cause unconfirmed

| Finding | Case | Category | Status | Evidence |
| --- | --- | --- | --- | --- |
| 8912ccaf194732dbe0e315c2 | record-normal | environment_fault | open | 5aea6cf2-ce9a-4da3-a280-e7a7500852bc |
| 2d2a53dd0c5d1c693a250e3d | record-normal | suspected_api_defect | open | 5aea6cf2-ce9a-4da3-a280-e7a7500852bc |
