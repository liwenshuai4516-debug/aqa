# API test run 0f687aaf-5a55-406c-a07c-5ed0cff93edb

- Verdict: failed
- Suite hash: c293631e9eca7595780ab3f8d0c6750bc20aee1cfdfe436983206c7e0ad48ad0
- Retest of: 2ffb2838-bea0-4184-b879-73115c5fc367
- Cleanup: not-required
- Analysis: deterministic evidence classification; root cause unconfirmed

| Finding | Case | Category | Status | Evidence |
| --- | --- | --- | --- | --- |
| 00ecaebdd55db7709bc11543 | record-normal | suspected_api_defect | open | 0f687aaf-5a55-406c-a07c-5ed0cff93edb |
