# API test run c0dd82dc-5b21-4564-bbbb-216785e6ae9f

- Verdict: failed
- Suite hash: 7f201b3a8c8537eb763fda693f0ab5152aa75ba00e788100ed110212d1bf0997
- Retest of: cb0d1aab-4df3-4623-854b-ea188d9f30d0
- Cleanup: failed
- Analysis: deterministic evidence classification; root cause unconfirmed

| Finding | Case | Category | Status | Evidence |
| --- | --- | --- | --- | --- |
| eedae246d098cd8349a749f0 | record-normal | cleanup_failure | open | c0dd82dc-5b21-4564-bbbb-216785e6ae9f |
| d23cab5de25e2e64cdd8bb0c | record-normal | cleanup_failure | open | cb0d1aab-4df3-4623-854b-ea188d9f30d0 |
