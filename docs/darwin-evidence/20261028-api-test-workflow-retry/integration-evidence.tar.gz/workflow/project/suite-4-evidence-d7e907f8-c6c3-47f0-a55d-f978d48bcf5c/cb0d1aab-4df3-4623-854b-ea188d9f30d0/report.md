# API test run cb0d1aab-4df3-4623-854b-ea188d9f30d0

- Verdict: failed
- Suite hash: 7a8113f71b44bba430b1034724907ad0aa3a05973360c2e27504b3a001287bcd
- Retest of: none
- Cleanup: failed
- Analysis: deterministic evidence classification; root cause unconfirmed

| Finding | Case | Category | Status | Evidence |
| --- | --- | --- | --- | --- |
| d23cab5de25e2e64cdd8bb0c | record-normal | cleanup_failure | open | cb0d1aab-4df3-4623-854b-ea188d9f30d0 |
