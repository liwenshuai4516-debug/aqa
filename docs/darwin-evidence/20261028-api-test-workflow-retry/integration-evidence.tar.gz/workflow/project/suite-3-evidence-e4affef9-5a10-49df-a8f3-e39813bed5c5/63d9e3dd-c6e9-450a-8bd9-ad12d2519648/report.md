# API test run 63d9e3dd-c6e9-450a-8bd9-ad12d2519648

- Verdict: error
- Suite hash: d6355f2b5e38bc11b027a17f08199cb85f868404f7eeeb09fc60a8125f8159bd
- Retest of: none
- Cleanup: not-required
- Analysis: deterministic evidence classification; root cause unconfirmed

| Finding | Case | Category | Status | Evidence |
| --- | --- | --- | --- | --- |
| 8912ccaf194732dbe0e315c2 | record-normal | environment_fault | open | 63d9e3dd-c6e9-450a-8bd9-ad12d2519648 |
| 2d2a53dd0c5d1c693a250e3d | record-normal | suspected_api_defect | open | 63d9e3dd-c6e9-450a-8bd9-ad12d2519648 |
