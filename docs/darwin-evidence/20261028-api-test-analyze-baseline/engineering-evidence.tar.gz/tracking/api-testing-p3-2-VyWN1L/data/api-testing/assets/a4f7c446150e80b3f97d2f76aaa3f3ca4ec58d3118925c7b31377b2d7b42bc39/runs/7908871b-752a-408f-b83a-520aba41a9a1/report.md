# API test run 7908871b-752a-408f-b83a-520aba41a9a1

- Verdict: failed
- Suite hash: 58e3774d2e8ad0a8a1bc3e6f378846e4feac9aea7461d8d559bb22c4857a5934
- Retest of: 0f8ba5aa-a367-4b53-bcce-55946761a2e4
- Cleanup: not-required
- Analysis: deterministic evidence classification; root cause unconfirmed

| Finding | Case | Category | Status | Evidence |
| --- | --- | --- | --- | --- |
| 23ef0d5420a6ce03585b15cd | record | suspected_api_defect | open | 7908871b-752a-408f-b83a-520aba41a9a1 |
