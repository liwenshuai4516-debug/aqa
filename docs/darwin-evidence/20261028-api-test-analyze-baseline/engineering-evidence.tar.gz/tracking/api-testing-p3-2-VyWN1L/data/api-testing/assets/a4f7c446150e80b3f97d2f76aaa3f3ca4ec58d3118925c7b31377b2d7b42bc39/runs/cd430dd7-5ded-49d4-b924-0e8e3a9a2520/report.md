# API test run cd430dd7-5ded-49d4-b924-0e8e3a9a2520

- Verdict: failed
- Suite hash: 58e3774d2e8ad0a8a1bc3e6f378846e4feac9aea7461d8d559bb22c4857a5934
- Retest of: 7908871b-752a-408f-b83a-520aba41a9a1
- Cleanup: not-required
- Analysis: deterministic evidence classification; root cause unconfirmed

| Finding | Case | Category | Status | Evidence |
| --- | --- | --- | --- | --- |
| 5c774fb0090979498585cb92 | record | suspected_api_defect | open | cd430dd7-5ded-49d4-b924-0e8e3a9a2520 |
| 23ef0d5420a6ce03585b15cd | record | suspected_api_defect | open | cd430dd7-5ded-49d4-b924-0e8e3a9a2520 |
