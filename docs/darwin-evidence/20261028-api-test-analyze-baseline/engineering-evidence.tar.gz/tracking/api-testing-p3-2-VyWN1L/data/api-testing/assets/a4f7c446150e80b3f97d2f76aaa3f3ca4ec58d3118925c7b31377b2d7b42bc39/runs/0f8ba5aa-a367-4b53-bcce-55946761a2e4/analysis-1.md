# API test run 0f8ba5aa-a367-4b53-bcce-55946761a2e4

- Verdict: failed
- Suite hash: 58e3774d2e8ad0a8a1bc3e6f378846e4feac9aea7461d8d559bb22c4857a5934
- Retest of: 60bbbc9e-b6cd-41ff-a8cc-3ff0e3ca8b31
- Cleanup: not-required
- Analysis: deterministic evidence classification; root cause unconfirmed

| Finding | Case | Category | Status | Evidence |
| --- | --- | --- | --- | --- |
| 23ef0d5420a6ce03585b15cd | record | suspected_api_defect | open | 0f8ba5aa-a367-4b53-bcce-55946761a2e4 |

## Analysis revision 1

Status: failed; root cause unconfirmed; model calls: 1.


