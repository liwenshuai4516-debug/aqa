# API test run 743ac9b2-88f3-4078-a30e-68a76d192997

- Verdict: failed
- Suite hash: 58e3774d2e8ad0a8a1bc3e6f378846e4feac9aea7461d8d559bb22c4857a5934
- Retest of: 6be7e356-1f26-4a27-8184-d56d99bdbad7
- Cleanup: not-required
- Analysis: deterministic evidence classification; root cause unconfirmed

| Finding | Case | Category | Status | Evidence |
| --- | --- | --- | --- | --- |
| 23ef0d5420a6ce03585b15cd | record | suspected_api_defect | open | 743ac9b2-88f3-4078-a30e-68a76d192997 |
